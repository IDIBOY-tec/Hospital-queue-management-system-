<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/settings.php';

require_staff();

$page_title = 'Reports & Analytics - ' . ($app_name ?? 'Hospital Queue System');

// Get date range from URL parameters
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$range = $_GET['range'] ?? 'last_7_days';

// Calculate date range based on selection
$date_range = calculateDateRange($range, $start_date, $end_date);

function calculateDateRange($range, $start_date, $end_date) {
    $today = date('Y-m-d');
    
    switch ($range) {
        case 'today':
            return ['start' => $today, 'end' => $today];
        case 'yesterday':
            return ['start' => date('Y-m-d', strtotime('-1 day')), 'end' => date('Y-m-d', strtotime('-1 day'))];
        case 'last_7_days':
            return ['start' => date('Y-m-d', strtotime('-6 days')), 'end' => $today];
        case 'last_30_days':
            return ['start' => date('Y-m-d', strtotime('-29 days')), 'end' => $today];
        case 'this_week':
            return ['start' => date('Y-m-d', strtotime('monday this week')), 'end' => $today];
        case 'last_week':
            return ['start' => date('Y-m-d', strtotime('monday last week')), 'end' => date('Y-m-d', strtotime('sunday last week'))];
        case 'this_month':
            return ['start' => date('Y-m-01'), 'end' => $today];
        case 'last_month':
            return ['start' => date('Y-m-01', strtotime('-1 month')), 'end' => date('Y-m-t', strtotime('-1 month'))];
        case 'this_year':
            return ['start' => date('Y-01-01'), 'end' => $today];
        case 'last_year':
            return ['start' => date('Y-01-01', strtotime('-1 year')), 'end' => date('Y-12-31', strtotime('-1 year'))];
        case 'all_time':
            return ['start' => '1970-01-01', 'end' => $today];
        case 'custom':
            return ['start' => $start_date, 'end' => $end_date];
        default:
            return ['start' => date('Y-m-d', strtotime('-6 days')), 'end' => $today];
    }
}
?>
<?php include '../includes/header.php'; ?>

<div class="main-content">
    <div class="p-4 md:p-8">
        <!-- Header -->
        <div class="mb-8 fade-in-up">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h1 class="text-3xl md:text-4xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                        Reports & Analytics
                    </h1>
                    <p class="text-gray-500 mt-2">Comprehensive insights into your queue performance</p>
                </div>
                <button onclick="window.print()" class="bg-gray-100 text-gray-700 px-5 py-2.5 rounded-xl font-medium hover:bg-gray-200 transition-all flex items-center gap-2">
                    <i class="fas fa-print"></i> Export Report
                </button>
            </div>
        </div>

        <!-- Date Range Filter -->
        <div class="chart-card p-5 mb-8">
            <div class="flex flex-col lg:flex-row gap-4">
                <!-- Quick Range Buttons -->
                <div class="flex flex-wrap gap-2 flex-1">
                    <button onclick="setRange('today')" class="range-btn px-4 py-2 rounded-lg text-sm font-medium transition-all" data-range="today">Today</button>
                    <button onclick="setRange('yesterday')" class="range-btn px-4 py-2 rounded-lg text-sm font-medium transition-all" data-range="yesterday">Yesterday</button>
                    <button onclick="setRange('this_week')" class="range-btn px-4 py-2 rounded-lg text-sm font-medium transition-all" data-range="this_week">This Week</button>
                    <button onclick="setRange('last_week')" class="range-btn px-4 py-2 rounded-lg text-sm font-medium transition-all" data-range="last_week">Last Week</button>
                    <button onclick="setRange('last_7_days')" class="range-btn px-4 py-2 rounded-lg text-sm font-medium transition-all" data-range="last_7_days">Last 7 Days</button>
                    <button onclick="setRange('last_30_days')" class="range-btn px-4 py-2 rounded-lg text-sm font-medium transition-all" data-range="last_30_days">Last 30 Days</button>
                    <button onclick="setRange('this_month')" class="range-btn px-4 py-2 rounded-lg text-sm font-medium transition-all" data-range="this_month">This Month</button>
                    <button onclick="setRange('last_month')" class="range-btn px-4 py-2 rounded-lg text-sm font-medium transition-all" data-range="last_month">Last Month</button>
                    <button onclick="setRange('this_year')" class="range-btn px-4 py-2 rounded-lg text-sm font-medium transition-all" data-range="this_year">This Year</button>
                    <button onclick="setRange('last_year')" class="range-btn px-4 py-2 rounded-lg text-sm font-medium transition-all" data-range="last_year">Last Year</button>
                    <button onclick="setRange('all_time')" class="range-btn px-4 py-2 rounded-lg text-sm font-medium transition-all" data-range="all_time">All Time</button>
                </div>
                
                <!-- Custom Date Range -->
                <div class="flex gap-2 items-center">
                    <div class="relative">
                        <i class="fas fa-calendar absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-sm"></i>
                        <input type="date" id="customStartDate" class="pl-9 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-blue-400">
                    </div>
                    <span class="text-gray-400">to</span>
                    <div class="relative">
                        <i class="fas fa-calendar absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-sm"></i>
                        <input type="date" id="customEndDate" class="pl-9 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-blue-400">
                    </div>
                    <button onclick="applyCustomRange()" class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition">
                        Apply
                    </button>
                </div>
            </div>
            <div class="mt-3 text-xs text-gray-500" id="dateRangeDisplay">
                Loading...
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-xs font-medium">Total Visits</p>
                        <p class="text-2xl font-bold text-blue-600 mt-1" id="totalVisits">-</p>
                    </div>
                    <div class="bg-blue-100 rounded-xl p-3"><i class="fas fa-chart-line text-blue-600"></i></div>
                </div>
            </div>
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-xs font-medium">Served</p>
                        <p class="text-2xl font-bold text-green-600 mt-1" id="servedVisits">-</p>
                    </div>
                    <div class="bg-green-100 rounded-xl p-3"><i class="fas fa-check-circle text-green-600"></i></div>
                </div>
            </div>
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-xs font-medium">Visited</p>
                        <p class="text-2xl font-bold text-purple-600 mt-1" id="visitedVisits">-</p>
                    </div>
                    <div class="bg-purple-100 rounded-xl p-3"><i class="fas fa-stethoscope text-purple-600"></i></div>
                </div>
            </div>
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-xs font-medium">Cancelled</p>
                        <p class="text-2xl font-bold text-red-600 mt-1" id="cancelledVisits">-</p>
                    </div>
                    <div class="bg-red-100 rounded-xl p-3"><i class="fas fa-times-circle text-red-600"></i></div>
                </div>
            </div>
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-xs font-medium">Completion Rate</p>
                        <p class="text-2xl font-bold text-emerald-600 mt-1" id="completionRate">-</p>
                    </div>
                    <div class="bg-emerald-100 rounded-xl p-3"><i class="fas fa-percent text-emerald-600"></i></div>
                </div>
            </div>
        </div>

        <!-- Charts Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <!-- Line Chart - Visits Trend -->
            <div class="chart-card p-5">
                <h3 class="font-bold text-gray-800 mb-4 flex items-center gap-2">
                    <i class="fas fa-chart-line text-blue-500"></i> Visits Trend
                </h3>
                <div style="position: relative; height: 250px;">
                    <canvas id="visitsLineChart"></canvas>
                </div>
            </div>
            
            <!-- Bar Chart - Daily Comparison -->
            <div class="chart-card p-5">
                <h3 class="font-bold text-gray-800 mb-4 flex items-center gap-2">
                    <i class="fas fa-chart-bar text-green-500"></i> Daily Performance
                </h3>
                <div style="position: relative; height: 250px;">
                    <canvas id="visitsBarChart"></canvas>
                </div>
            </div>
            
            <!-- Doughnut Chart - Status Distribution -->
            <div class="chart-card p-5">
                <h3 class="font-bold text-gray-800 mb-4 flex items-center gap-2">
                    <i class="fas fa-chart-pie text-purple-500"></i> Status Distribution
                </h3>
                <div style="position: relative; height: 250px;">
                    <canvas id="statusDoughnutChart"></canvas>
                </div>
            </div>
            
            <!-- Bar Chart - Staff Performance -->
            <div class="chart-card p-5">
                <h3 class="font-bold text-gray-800 mb-4 flex items-center gap-2">
                    <i class="fas fa-users text-orange-500"></i> Staff Performance
                </h3>
                <div style="position: relative; height: 250px;">
                    <canvas id="staffBarChart"></canvas>
                </div>
            </div>
            
            <!-- Line Chart - Wait Time Trend -->
            <div class="chart-card p-5">
                <h3 class="font-bold text-gray-800 mb-4 flex items-center gap-2">
                    <i class="fas fa-hourglass-half text-yellow-500"></i> Average Wait Time Trend
                </h3>
                <div style="position: relative; height: 250px;">
                    <canvas id="waitTimeChart"></canvas>
                </div>
            </div>
            
            <!-- Doughnut Chart - Top Medicines -->
            <div class="chart-card p-5">
                <h3 class="font-bold text-gray-800 mb-4 flex items-center gap-2">
                    <i class="fas fa-capsules text-indigo-500"></i> Top Medicines Dispensed
                </h3>
                <div style="position: relative; height: 250px;">
                    <canvas id="medicinesChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Wait Time Statistics Card -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="chart-card p-5">
                <div class="flex items-center gap-3 mb-3">
                    <div class="bg-blue-100 rounded-lg p-2"><i class="fas fa-clock text-blue-600"></i></div>
                    <h3 class="font-bold text-gray-800">Average Wait Time</h3>
                </div>
                <p class="text-3xl font-bold text-blue-600" id="avgWaitTime">-- min</p>
                <p class="text-sm text-gray-500 mt-1">Average time from registration to service</p>
            </div>
            <div class="chart-card p-5">
                <div class="flex items-center gap-3 mb-3">
                    <div class="bg-green-100 rounded-lg p-2"><i class="fas fa-arrow-down text-green-600"></i></div>
                    <h3 class="font-bold text-gray-800">Minimum Wait Time</h3>
                </div>
                <p class="text-3xl font-bold text-green-600" id="minWaitTime">-- min</p>
                <p class="text-sm text-gray-500 mt-1">Fastest service time</p>
            </div>
            <div class="chart-card p-5">
                <div class="flex items-center gap-3 mb-3">
                    <div class="bg-red-100 rounded-lg p-2"><i class="fas fa-arrow-up text-red-600"></i></div>
                    <h3 class="font-bold text-gray-800">Maximum Wait Time</h3>
                </div>
                <p class="text-3xl font-bold text-red-600" id="maxWaitTime">-- min</p>
                <p class="text-sm text-gray-500 mt-1">Longest service time</p>
            </div>
        </div>

        <!-- Data Tables Section -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <!-- Recent Visits Table -->
            <div class="chart-card overflow-hidden">
                <div class="p-5 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
                    <h3 class="font-bold text-gray-800 flex items-center gap-2">
                        <i class="fas fa-history text-gray-500"></i> Recent Visits
                    </h3>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Date</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Record #</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Patient</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Status</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Wait Time</th>
                            </tr>
                        </thead>
                        <tbody id="recentVisitsTable">
                            <tr><td colspan="5" class="text-center py-4"><div class="spinner mx-auto"></div></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Top Patients Table -->
            <div class="chart-card overflow-hidden">
                <div class="p-5 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
                    <h3 class="font-bold text-gray-800 flex items-center gap-2">
                        <i class="fas fa-trophy text-yellow-500"></i> Most Frequent Patients
                    </h3>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Patient Name</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Phone</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Visits</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Last Visit</th>
                            </tr>
                        </thead>
                        <tbody id="topPatientsTable">
                            <tr><td colspan="4" class="text-center py-4"><div class="spinner mx-auto"></div></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Daily Breakdown Table -->
        <div class="chart-card overflow-hidden">
            <div class="p-5 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
                <h3 class="font-bold text-gray-800 flex items-center gap-2">
                    <i class="fas fa-calendar-day text-blue-500"></i> Daily Breakdown
                </h3>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50 border-b">
                        <tr>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Date</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Total Visits</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Served</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Visited</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Cancelled</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600">Completion Rate</th>
                        </tr>
                    </thead>
                    <tbody id="dailyBreakdownTable">
                        <tr><td colspan="6" class="text-center py-4"><div class="spinner mx-auto"></div></td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
let currentRange = '<?php echo $range; ?>';
let startDate = '<?php echo $date_range['start']; ?>';
let endDate = '<?php echo $date_range['end']; ?>';

// Chart instances
let visitsLineChart = null;
let visitsBarChart = null;
let statusDoughnutChart = null;
let staffBarChart = null;
let waitTimeChart = null;
let medicinesChart = null;

// Set range function with real-time update
function setRange(range) {
    currentRange = range;
    
    // Calculate dates based on range
    const today = new Date();
    let start, end;
    
    switch(range) {
        case 'today':
            start = formatDateForInput(today);
            end = formatDateForInput(today);
            break;
        case 'yesterday':
            const yesterday = new Date(today);
            yesterday.setDate(today.getDate() - 1);
            start = formatDateForInput(yesterday);
            end = formatDateForInput(yesterday);
            break;
        case 'this_week':
            const monday = new Date(today);
            monday.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1));
            start = formatDateForInput(monday);
            end = formatDateForInput(today);
            break;
        case 'last_week':
            const lastWeekStart = new Date(today);
            lastWeekStart.setDate(today.getDate() - today.getDay() - 6);
            const lastWeekEnd = new Date(lastWeekStart);
            lastWeekEnd.setDate(lastWeekStart.getDate() + 6);
            start = formatDateForInput(lastWeekStart);
            end = formatDateForInput(lastWeekEnd);
            break;
        case 'last_7_days':
            const weekAgo = new Date(today);
            weekAgo.setDate(today.getDate() - 6);
            start = formatDateForInput(weekAgo);
            end = formatDateForInput(today);
            break;
        case 'last_30_days':
            const monthAgo = new Date(today);
            monthAgo.setDate(today.getDate() - 29);
            start = formatDateForInput(monthAgo);
            end = formatDateForInput(today);
            break;
        case 'this_month':
            start = formatDateForInput(new Date(today.getFullYear(), today.getMonth(), 1));
            end = formatDateForInput(today);
            break;
        case 'last_month':
            const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
            const lastMonthEnd = new Date(today.getFullYear(), today.getMonth(), 0);
            start = formatDateForInput(lastMonth);
            end = formatDateForInput(lastMonthEnd);
            break;
        case 'this_year':
            start = formatDateForInput(new Date(today.getFullYear(), 0, 1));
            end = formatDateForInput(today);
            break;
        case 'last_year':
            start = formatDateForInput(new Date(today.getFullYear() - 1, 0, 1));
            end = formatDateForInput(new Date(today.getFullYear() - 1, 11, 31));
            break;
        case 'all_time':
            start = '1970-01-01';
            end = formatDateForInput(today);
            break;
    }
    
    startDate = start;
    endDate = end;
    
    // Update custom date inputs
    document.getElementById('customStartDate').value = startDate;
    document.getElementById('customEndDate').value = endDate;
    
    // Update URL without reload
    updateURL();
    
    // Load data
    loadReports();
}

function formatDateForInput(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

function applyCustomRange() {
    const start = document.getElementById('customStartDate').value;
    const end = document.getElementById('customEndDate').value;
    if (start && end) {
        currentRange = 'custom';
        startDate = start;
        endDate = end;
        updateURL();
        loadReports();
    } else {
        alert('Please select both start and end dates');
    }
}

function updateURL() {
    let url = window.location.pathname + '?range=' + currentRange;
    if (currentRange === 'custom') {
        url += '&start_date=' + startDate + '&end_date=' + endDate;
    }
    window.history.pushState({}, '', url);
}

// Highlight active range button
function highlightActiveButton() {
    document.querySelectorAll('.range-btn').forEach(btn => {
        btn.classList.remove('bg-blue-600', 'text-white');
        btn.classList.add('bg-gray-100', 'text-gray-700');
    });
    const activeBtn = document.querySelector(`.range-btn[data-range="${currentRange}"]`);
    if (activeBtn) {
        activeBtn.classList.remove('bg-gray-100', 'text-gray-700');
        activeBtn.classList.add('bg-blue-600', 'text-white');
    }
}

async function loadReports() {
    try {
        // Show loading spinners
        showLoading(true);
        
        const baseUrl = '/api/reports_api_data.php';
        
        // Load Summary Stats
        const summaryRes = await fetch(`${baseUrl}?type=daily_summary&start_date=${startDate}&end_date=${endDate}`);
        const summaryData = await summaryRes.json();
        if (summaryData.success && summaryData.data) {
            document.getElementById('totalVisits').textContent = summaryData.data.total_visits || 0;
            document.getElementById('servedVisits').textContent = summaryData.data.served || 0;
            document.getElementById('visitedVisits').textContent = summaryData.data.visited || 0;
            document.getElementById('cancelledVisits').textContent = summaryData.data.cancelled || 0;
            const total = summaryData.data.total_visits || 1;
            const rate = Math.round((summaryData.data.served / total) * 100);
            document.getElementById('completionRate').textContent = `${rate}%`;
        }
        
        // Update date range display
        document.getElementById('dateRangeDisplay').innerHTML = `<i class="fas fa-calendar-alt mr-1"></i> Showing data from ${formatDisplayDate(startDate)} to ${formatDisplayDate(endDate)}`;
        
        // Load Visits by Day
        const visitsRes = await fetch(`${baseUrl}?type=visits_by_day&start_date=${startDate}&end_date=${endDate}`);
        const visitsData = await visitsRes.json();
        
        if (visitsData.success && visitsData.data && visitsData.data.length > 0) {
            const labels = visitsData.data.map(d => formatDisplayDate(d.day));
            const visits = visitsData.data.map(d => parseInt(d.visits));
            const served = visitsData.data.map(d => parseInt(d.served));
            
            // Line Chart
            const ctx = document.getElementById('visitsLineChart').getContext('2d');
            if (visitsLineChart) visitsLineChart.destroy();
            visitsLineChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [
                        {
                            label: 'Total Visits',
                            data: visits,
                            borderColor: '#3b82f6',
                            backgroundColor: 'rgba(59, 130, 246, 0.1)',
                            fill: true,
                            tension: 0.4
                        },
                        {
                            label: 'Served',
                            data: served,
                            borderColor: '#10b981',
                            backgroundColor: 'rgba(16, 185, 129, 0.1)',
                            fill: true,
                            tension: 0.4
                        }
                    ]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: true,
                    plugins: {
                        legend: { position: 'top' }
                    },
                    scales: { y: { beginAtZero: true, stepSize: 1 } }
                }
            });
            
            // Bar Chart
            const barCtx = document.getElementById('visitsBarChart').getContext('2d');
            if (visitsBarChart) visitsBarChart.destroy();
            visitsBarChart = new Chart(barCtx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Total Visits',
                        data: visits,
                        backgroundColor: '#3b82f6',
                        borderRadius: 8
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: true,
                    plugins: {
                        legend: { position: 'top' }
                    },
                    scales: { y: { beginAtZero: true, stepSize: 1 } }
                }
            });
        } else {
            showEmptyChart('visitsLineChart', 'No data available');
            showEmptyChart('visitsBarChart', 'No data available');
        }
        
        // Load Status Distribution
        const statusRes = await fetch(`${baseUrl}?type=status_distribution&start_date=${startDate}&end_date=${endDate}`);
        const statusData = await statusRes.json();
        
        if (statusData.success && statusData.data && statusData.data.length > 0) {
            const ctx = document.getElementById('statusDoughnutChart').getContext('2d');
            if (statusDoughnutChart) statusDoughnutChart.destroy();
            statusDoughnutChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: statusData.data.map(s => s.status),
                    datasets: [{
                        data: statusData.data.map(s => parseInt(s.count)),
                        backgroundColor: ['#f59e0b', '#3b82f6', '#10b981', '#8b5cf6', '#ef4444']
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: true, 
                    plugins: { legend: { position: 'bottom' } }
                }
            });
        } else {
            showEmptyChart('statusDoughnutChart', 'No data available');
        }
        
        // Load Staff Performance
        const staffRes = await fetch(`${baseUrl}?type=staff_performance&start_date=${startDate}&end_date=${endDate}`);
        const staffData = await staffRes.json();
        
        if (staffData.success && staffData.data && staffData.data.length > 0) {
            const ctx = document.getElementById('staffBarChart').getContext('2d');
            if (staffBarChart) staffBarChart.destroy();
            staffBarChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: staffData.data.map(d => d.name),
                    datasets: [{
                        label: 'Visits Handled',
                        data: staffData.data.map(d => parseInt(d.visits)),
                        backgroundColor: '#f59e0b',
                        borderRadius: 8
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: true,
                    indexAxis: 'y',
                    plugins: {
                        legend: { position: 'top' }
                    },
                    scales: { x: { beginAtZero: true, stepSize: 1 } }
                }
            });
        } else {
            showEmptyChart('staffBarChart', 'No data available');
        }
        
        // Load Wait Time Trend
        const waitTrendRes = await fetch(`${baseUrl}?type=wait_time_trend&start_date=${startDate}&end_date=${endDate}`);
        const waitTrendData = await waitTrendRes.json();
        
        if (waitTrendData.success && waitTrendData.data && waitTrendData.data.length > 0) {
            const ctx = document.getElementById('waitTimeChart').getContext('2d');
            if (waitTimeChart) waitTimeChart.destroy();
            waitTimeChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: waitTrendData.data.map(d => formatDisplayDate(d.day)),
                    datasets: [{
                        label: 'Avg Wait Time (minutes)',
                        data: waitTrendData.data.map(d => parseFloat(d.avg_wait)),
                        borderColor: '#ef4444',
                        backgroundColor: 'rgba(239, 68, 68, 0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: true,
                    plugins: {
                        legend: { position: 'top' }
                    },
                    scales: { 
                        y: { 
                            beginAtZero: true, 
                            title: { display: true, text: 'Minutes' },
                            stepSize: 1
                        } 
                    }
                }
            });
        } else {
            showEmptyChart('waitTimeChart', 'No wait time data available');
        }
        
        // Load Top Medicines
        const medRes = await fetch(`${baseUrl}?type=top_medicines&start_date=${startDate}&end_date=${endDate}&limit=5`);
        const medData = await medRes.json();
        
        if (medData.success && medData.data && medData.data.length > 0) {
            const ctx = document.getElementById('medicinesChart').getContext('2d');
            if (medicinesChart) medicinesChart.destroy();
            medicinesChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: medData.data.map(m => m.name),
                    datasets: [{
                        data: medData.data.map(m => parseInt(m.total_qty)),
                        backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6']
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: true, 
                    plugins: { legend: { position: 'bottom' } }
                }
            });
        } else {
            showEmptyChart('medicinesChart', 'No medicine data available');
        }
        
        // Load Wait Time Stats
        const waitRes = await fetch(`${baseUrl}?type=wait_time_stats&start_date=${startDate}&end_date=${endDate}`);
        const waitData = await waitRes.json();
        
        if (waitData.success && waitData.data) {
            document.getElementById('avgWaitTime').textContent = `${Math.round(waitData.data.avg_wait_minutes || 0)} min`;
            document.getElementById('minWaitTime').textContent = `${Math.round(waitData.data.min_wait_minutes || 0)} min`;
            document.getElementById('maxWaitTime').textContent = `${Math.round(waitData.data.max_wait_minutes || 0)} min`;
        }
        
        // Load Recent Visits Table
        const recentRes = await fetch(`${baseUrl}?type=recent_visits&start_date=${startDate}&end_date=${endDate}&limit=10`);
        const recentData = await recentRes.json();
        
        if (recentData.success && recentData.data && recentData.data.length > 0) {
            document.getElementById('recentVisitsTable').innerHTML = recentData.data.map(v => `
                <tr class="border-b hover:bg-gray-50">
                    <td class="px-4 py-3 text-sm">${formatDateTime(v.created_at)}</td>
                    <td class="px-4 py-3 font-mono text-sm">${escapeHtml(v.record_number)}</td>
                    <td class="px-4 py-3">${escapeHtml(v.patient_name)}</td>
                    <td class="px-4 py-3"><span class="px-2 py-1 rounded-full text-xs ${getStatusClass(v.status)}">${v.status}</span></td>
                    <td class="px-4 py-3 text-sm">${v.wait_time_minutes || '-'} min</td>
                </tr>
            `).join('');
        } else {
            document.getElementById('recentVisitsTable').innerHTML = '<tr><td colspan="5" class="text-center py-4 text-gray-400">No recent visits found</td></tr>';
        }
        
        // Load Top Patients Table
        const topPatientsRes = await fetch(`${baseUrl}?type=top_patients&start_date=${startDate}&end_date=${endDate}&limit=10`);
        const topPatientsData = await topPatientsRes.json();
        
        if (topPatientsData.success && topPatientsData.data && topPatientsData.data.length > 0) {
            document.getElementById('topPatientsTable').innerHTML = topPatientsData.data.map(p => `
                <tr class="border-b hover:bg-gray-50">
                    <td class="px-4 py-3 font-medium">${escapeHtml(p.full_name)}</td>
                    <td class="px-4 py-3 text-sm">${escapeHtml(p.phone || '-')}</td>
                    <td class="px-4 py-3"><span class="font-bold text-blue-600">${p.visit_count}</span></td>
                    <td class="px-4 py-3 text-sm">${formatDate(p.last_visit)}</td>
                </tr>
            `).join('');
        } else {
            document.getElementById('topPatientsTable').innerHTML = '<tr><td colspan="4" class="text-center py-4 text-gray-400">No patient data found</td></tr>';
        }
        
        // Load Daily Breakdown Table
        const dailyRes = await fetch(`${baseUrl}?type=daily_breakdown&start_date=${startDate}&end_date=${endDate}`);
        const dailyData = await dailyRes.json();
        
        if (dailyData.success && dailyData.data && dailyData.data.length > 0) {
            document.getElementById('dailyBreakdownTable').innerHTML = dailyData.data.map(d => {
                const rate = d.total > 0 ? Math.round((d.served / d.total) * 100) : 0;
                return `
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-4 py-3">${d.date}</td>
                        <td class="px-4 py-3 text-center">${d.total}</td>
                        <td class="px-4 py-3 text-center text-green-600">${d.served}</td>
                        <td class="px-4 py-3 text-center text-purple-600">${d.visited || 0}</td>
                        <td class="px-4 py-3 text-center text-red-600">${d.cancelled || 0}</td>
                        <td class="px-4 py-3 text-center"><span class="px-2 py-1 rounded-full text-xs ${rate >= 80 ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}">${rate}%</span></td>
                    </tr>
                `;
            }).join('');
        } else {
            document.getElementById('dailyBreakdownTable').innerHTML = '<tr><td colspan="6" class="text-center py-4 text-gray-400">No daily data found</td></tr>';
        }
        
        // Hide loading spinners
        showLoading(false);
        
    } catch (err) {
        console.error('Error loading reports:', err);
        showLoading(false);
        alert('Error loading report data. Please check the console for details.');
    }
}

function showLoading(show) {
    if (show) {
        document.getElementById('recentVisitsTable').innerHTML = '<tr><td colspan="5" class="text-center py-4"><div class="spinner mx-auto"></div></td></tr>';
        document.getElementById('topPatientsTable').innerHTML = '<tr><td colspan="4" class="text-center py-4"><div class="spinner mx-auto"></div></td></tr>';
        document.getElementById('dailyBreakdownTable').innerHTML = '<tr><td colspan="6" class="text-center py-4"><div class="spinner mx-auto"></div></td></tr>';
    }
}

function showEmptyChart(canvasId, message) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const existingChart = eval(canvasId);
    if (existingChart) existingChart.destroy();
    
    // Clear canvas and show message
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.font = '14px Arial';
    ctx.fillStyle = '#999';
    ctx.textAlign = 'center';
    ctx.fillText(message, canvas.width / 2, canvas.height / 2);
}

function formatDisplayDate(date) {
    if (!date) return '-';
    const d = new Date(date);
    return `${d.getMonth() + 1}/${d.getDate()}`;
}

function formatDate(date) {
    if (!date) return '-';
    const d = new Date(date);
    return `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()}`;
}

function formatDateTime(dateTime) {
    if (!dateTime) return '-';
    const d = new Date(dateTime);
    return `${d.getMonth() + 1}/${d.getDate()} ${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
}

function getStatusClass(status) {
    const classes = {
        waiting: 'bg-yellow-100 text-yellow-800',
        called: 'bg-blue-100 text-blue-800',
        arrived: 'bg-green-100 text-green-800',
        visited: 'bg-purple-100 text-purple-800',
        served: 'bg-emerald-100 text-emerald-800',
        cancelled: 'bg-red-100 text-red-800'
    };
    return classes[status] || 'bg-gray-100 text-gray-800';
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Set initial values and load
document.getElementById('customStartDate').value = startDate;
document.getElementById('customEndDate').value = endDate;
highlightActiveButton();
loadReports();
</script>

<style>
.stat-card {
    background: white;
    border-radius: 1rem;
    box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
    transition: all 0.3s ease;
}
.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px -5px rgb(0 0 0 / 0.1);
}
.chart-card {
    background: white;
    border-radius: 1rem;
    box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
    transition: all 0.3s ease;
}
.chart-card:hover {
    box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
}
.spinner {
    border: 3px solid #f3f3f3;
    border-top: 3px solid #3498db;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    animation: spin 1s linear infinite;
    margin: 0 auto;
}
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
.fade-in-up {
    animation: fadeInUp 0.5s ease-out;
}
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
.range-btn {
    transition: all 0.2s ease;
    cursor: pointer;
}
.range-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}
</style>

<?php include '../includes/footer.php'; ?>