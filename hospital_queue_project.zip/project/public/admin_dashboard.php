<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/settings.php';

require_admin();

$page_title = 'Dashboard - ' . ($app_name ?? 'Hospital Queue System');
$user = get_user_by_id($mysqli, get_current_user_id());

// ========== STATISTICS QUERIES ==========

// Staff Count
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM users WHERE role='staff' AND is_active=1");
$staff_count = mysqli_fetch_assoc($result)['cnt'];

// Patient Count
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM patients WHERE deleted_at IS NULL");
$patient_count = mysqli_fetch_assoc($result)['cnt'];

// Today's Statistics
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE DATE(created_at)=CURDATE()");
$today_visits = mysqli_fetch_assoc($result)['cnt'];

$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE status='waiting' AND DATE(created_at)=CURDATE()");
$waiting_count = mysqli_fetch_assoc($result)['cnt'];

$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE status='served' AND DATE(served_at)=CURDATE()");
$served_today = mysqli_fetch_assoc($result)['cnt'];

// Medicine Statistics
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM medicines");
$medicine_count = mysqli_fetch_assoc($result)['cnt'];

$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM medicines WHERE quantity < 10");
$low_stock_medicines = mysqli_fetch_assoc($result)['cnt'];

$result = mysqli_query($mysqli, "SELECT COALESCE(SUM(qty), 0) as total FROM medicine_given WHERE DATE(given_at)=CURDATE()");
$medicines_given_today = mysqli_fetch_assoc($result)['total'];

// ========== AI-POWERED INSIGHTS ==========
$ai_insights = [];

// 1. Peak Hours Analysis
$peak_hours = mysqli_query($mysqli, "
    SELECT HOUR(created_at) as hour, COUNT(*) as count 
    FROM visits WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY HOUR(created_at) ORDER BY count DESC LIMIT 3
");
$peak_list = [];
while ($row = mysqli_fetch_assoc($peak_hours)) {
    $hour = $row['hour'];
    $ampm = $hour >= 12 ? 'PM' : 'AM';
    $display = $hour > 12 ? $hour-12 : ($hour == 0 ? 12 : $hour);
    $peak_list[] = "$display:00 $ampm";
}
if (!empty($peak_list)) {
    $ai_insights[] = ['icon' => 'fa-chart-line', 'title' => 'Peak Hours', 'message' => 'Busiest: ' . implode(', ', array_slice($peak_list, 0, 2)), 'type' => 'info'];
}

// 2. Low Stock Alert
if ($low_stock_medicines > 0) {
    $low_items = mysqli_query($mysqli, "SELECT name, quantity FROM medicines WHERE quantity < 10 ORDER BY quantity ASC LIMIT 3");
    $items = [];
    while ($row = mysqli_fetch_assoc($low_items)) {
        $items[] = $row['name'] . " ({$row['quantity']})";
    }
    $ai_insights[] = ['icon' => 'fa-exclamation-triangle', 'title' => 'Low Stock Alert', 'message' => "$low_stock_medicines medicines low: " . implode(', ', $items), 'type' => 'warning'];
}

// 3. Completion Rate
$comp_result = mysqli_query($mysqli, "
    SELECT COUNT(*) as total, SUM(CASE WHEN status='served' THEN 1 ELSE 0 END) as served 
    FROM visits WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
");
$comp = mysqli_fetch_assoc($comp_result);
$completion_rate = $comp['total'] > 0 ? round(($comp['served'] / $comp['total']) * 100) : 0;
$ai_insights[] = ['icon' => 'fa-check-circle', 'title' => 'Completion Rate', 'message' => "{$completion_rate}% of visits completed this week", 'type' => $completion_rate >= 80 ? 'success' : 'warning'];

// 4. Growth Trend
$growth = mysqli_query($mysqli, "
    SELECT DATE_FORMAT(created_at, '%M') as month, COUNT(*) as new_patients 
    FROM patients WHERE created_at >= DATE_SUB(NOW(), INTERVAL 3 MONTH) AND deleted_at IS NULL
    GROUP BY MONTH(created_at) ORDER BY created_at DESC LIMIT 2
");
$growth_data = [];
while ($row = mysqli_fetch_assoc($growth)) $growth_data[] = $row;
if (count($growth_data) >= 2 && $growth_data[0]['new_patients'] > $growth_data[1]['new_patients']) {
    $increase = round((($growth_data[0]['new_patients'] - $growth_data[1]['new_patients']) / $growth_data[1]['new_patients']) * 100);
    $ai_insights[] = ['icon' => 'fa-chart-line', 'title' => 'Patient Growth', 'message' => "Patient registrations up {$increase}% this month", 'type' => 'success'];
}

// 5. Average Wait Time
$wait = mysqli_query($mysqli, "SELECT AVG(TIMESTAMPDIFF(MINUTE, created_at, served_at)) as avg FROM visits WHERE served_at IS NOT NULL AND served_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$avg_wait = round(mysqli_fetch_assoc($wait)['avg'] ?? 0);
$ai_insights[] = ['icon' => 'fa-hourglass-half', 'title' => 'Avg Wait Time', 'message' => "{$avg_wait} minutes average wait time", 'type' => $avg_wait > 20 ? 'warning' : 'success'];

// 6. Top Medicines
$top_meds = mysqli_query($mysqli, "
    SELECT m.name, SUM(mg.qty) as total 
    FROM medicines m JOIN medicine_given mg ON mg.medicine_id = m.id 
    WHERE mg.given_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY m.id ORDER BY total DESC LIMIT 3
");
$med_list = [];
while ($row = mysqli_fetch_assoc($top_meds)) $med_list[] = $row['name'];
if (!empty($med_list)) {
    $ai_insights[] = ['icon' => 'fa-pills', 'title' => 'Top Medicines', 'message' => 'Most prescribed: ' . implode(', ', $med_list), 'type' => 'info'];
}
?>
<?php include '../includes/header.php'; ?>

<div class="main-content">
    <div class="p-4 md:p-8">
        <!-- Header -->
        <div class="mb-8 fade-in-up">
            <h1 class="text-3xl md:text-4xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">Dashboard</h1>
            <p class="text-gray-500 mt-2">Welcome back, <?php echo htmlspecialchars($user['full_name']); ?>! Here's your system overview.</p>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Total Staff</p>
                        <p class="text-3xl font-bold text-indigo-600 mt-1"><?php echo $staff_count; ?></p>
                    </div>
                    <div class="bg-indigo-100 rounded-xl p-3">
                        <i class="fas fa-users text-indigo-600 text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Total Patients</p>
                        <p class="text-3xl font-bold text-emerald-600 mt-1"><?php echo $patient_count; ?></p>
                    </div>
                    <div class="bg-emerald-100 rounded-xl p-3">
                        <i class="fas fa-user-injured text-emerald-600 text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Today's Visits</p>
                        <p class="text-3xl font-bold text-amber-600 mt-1"><?php echo $today_visits; ?></p>
                    </div>
                    <div class="bg-amber-100 rounded-xl p-3">
                        <i class="fas fa-calendar-day text-amber-600 text-xl"></i>
                    </div>
                </div>
                <div class="mt-2 text-xs flex gap-3">
                    <span class="text-green-600"><i class="fas fa-check-circle"></i> <?php echo $served_today; ?> served</span>
                    <span class="text-yellow-600"><i class="fas fa-clock"></i> <?php echo $waiting_count; ?> waiting</span>
                </div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Medicines</p>
                        <p class="text-3xl font-bold text-purple-600 mt-1"><?php echo $medicine_count; ?></p>
                    </div>
                    <div class="bg-purple-100 rounded-xl p-3">
                        <i class="fas fa-capsules text-purple-600 text-xl"></i>
                    </div>
                </div>
                <?php if ($low_stock_medicines > 0): ?>
                    <div class="mt-2 text-xs text-red-500">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $low_stock_medicines; ?> low stock
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- AI Insights Row -->
        <div class="mb-8">
            <div class="flex items-center gap-2 mb-4">
                <div class="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg p-2">
                    <i class="fas fa-brain text-white text-sm"></i>
                </div>
                <h2 class="text-xl font-bold text-gray-800">AI Intelligence Insights</h2>
                <span class="text-xs bg-purple-100 text-purple-600 px-2 py-1 rounded-full">Real-time</span>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <?php foreach ($ai_insights as $insight): ?>
                    <div class="ai-insight p-4">
                        <div class="flex items-start gap-3">
                            <div class="bg-white/20 rounded-lg p-2">
                                <i class="fas <?php echo $insight['icon']; ?> text-white text-sm"></i>
                            </div>
                            <div class="flex-1">
                                <h3 class="font-semibold text-white text-sm mb-1"><?php echo htmlspecialchars($insight['title']); ?></h3>
                                <p class="text-white/80 text-xs"><?php echo htmlspecialchars($insight['message']); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Charts Grid - Comprehensive Analytics -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <!-- Chart 1: Visits Trend Line Chart -->
            <div class="chart-card p-5">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="font-bold text-gray-800"><i class="fas fa-chart-line text-blue-500 mr-2"></i>Visits Trend</h3>
                    <select id="trendDays" class="text-xs border rounded-lg px-2 py-1">
                        <option value="7">Last 7 Days</option>
                        <option value="14">Last 14 Days</option>
                        <option value="30">Last 30 Days</option>
                    </select>
                </div>
                <canvas id="visitsTrendChart" height="250"></canvas>
            </div>
            
            <!-- Chart 2: Patient Registration Trend -->
            <div class="chart-card p-5">
                <h3 class="font-bold text-gray-800 mb-4"><i class="fas fa-user-plus text-emerald-500 mr-2"></i>Patient Registrations</h3>
                <canvas id="patientRegChart" height="250"></canvas>
            </div>
            
            <!-- Chart 3: Medicines vs Given Comparison -->
            <div class="chart-card p-5">
                <h3 class="font-bold text-gray-800 mb-4"><i class="fas fa-chart-bar text-purple-500 mr-2"></i>Medicines: Stock vs Dispensed</h3>
                <canvas id="medicineComparisonChart" height="250"></canvas>
            </div>
            
            <!-- Chart 4: Staff Performance -->
            <div class="chart-card p-5">
                <h3 class="font-bold text-gray-800 mb-4"><i class="fas fa-trophy text-yellow-500 mr-2"></i>Staff Performance (Top 5)</h3>
                <canvas id="staffPerformanceChart" height="250"></canvas>
            </div>
            
            <!-- Chart 5: Status Distribution Doughnut -->
            <div class="chart-card p-5">
                <h3 class="font-bold text-gray-800 mb-4"><i class="fas fa-chart-pie text-pink-500 mr-2"></i>Visit Status Distribution</h3>
                <canvas id="statusChart" height="250"></canvas>
            </div>
            
            <!-- Chart 6: Hourly Activity Heatmap Style -->
            <div class="chart-card p-5">
                <h3 class="font-bold text-gray-800 mb-4"><i class="fas fa-clock text-orange-500 mr-2"></i>Hourly Activity Pattern</h3>
                <canvas id="hourlyChart" height="250"></canvas>
            </div>
        </div>

        <!-- Recent Activity Table -->
        <div class="chart-card p-5">
            <div class="flex items-center justify-between mb-4">
                <h3 class="font-bold text-gray-800"><i class="fas fa-history text-gray-500 mr-2"></i>Recent Activity</h3>
                <button onclick="refreshRecentActivity()" class="text-sm text-blue-600 hover:text-blue-700">
                    <i class="fas fa-sync-alt"></i> Refresh
                </button>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 border-b">
                        <tr>
                            <th class="px-4 py-3 text-left text-gray-600">Time</th>
                            <th class="px-4 py-3 text-left text-gray-600">Record #</th>
                            <th class="px-4 py-3 text-left text-gray-600">Patient</th>
                            <th class="px-4 py-3 text-left text-gray-600">Status</th>
                            <th class="px-4 py-3 text-left text-gray-600">Staff</th>
                        </tr>
                    </thead>
                    <tbody id="recentActivityTable">
                        <tr><td colspan="5" class="text-center py-8"><div class="spinner mx-auto"></div></td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
let visitsChart, patientChart, medicineChart, staffChart, statusChart, hourlyChart;

async function loadAllData() {
    const days = document.getElementById('trendDays')?.value || 7;
    await Promise.all([
        loadVisitsTrend(days),
        loadPatientRegistrations(),
        loadMedicineComparison(),
        loadStaffPerformance(),
        loadStatusDistribution(),
        loadHourlyActivity(),
        loadRecentActivity()
    ]);
}

async function loadVisitsTrend(days) {
    try {
        const response = await fetch(`/api/api_reports.php?type=visits_by_day&range=last_${days}_days`);
        const data = await response.json();
        
        if (data.success && data.data) {
            if (visitsChart) visitsChart.destroy();
            const ctx = document.getElementById('visitsTrendChart').getContext('2d');
            visitsChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.data.map(d => d.day),
                    datasets: [
                        {
                            label: 'Total Visits',
                            data: data.data.map(d => parseInt(d.visits)),
                            borderColor: '#3b82f6',
                            backgroundColor: 'rgba(59, 130, 246, 0.1)',
                            fill: true,
                            tension: 0.4
                        },
                        {
                            label: 'Served',
                            data: data.data.map(d => parseInt(d.served)),
                            borderColor: '#10b981',
                            backgroundColor: 'rgba(16, 185, 129, 0.1)',
                            fill: true,
                            tension: 0.4
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: { legend: { position: 'top' } }
                }
            });
        }
    } catch (err) {
        console.error('Error loading visits trend:', err);
    }
}

async function loadPatientRegistrations() {
    try {
        const response = await fetch('/api/api_reports.php?type=patient_registration_trend&months=6');
        const data = await response.json();
        
        if (data.success && data.data) {
            if (patientChart) patientChart.destroy();
            const ctx = document.getElementById('patientRegChart').getContext('2d');
            patientChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.data.map(d => d.month),
                    datasets: [{
                        label: 'New Patients',
                        data: data.data.map(d => parseInt(d.count)),
                        backgroundColor: '#10b981',
                        borderRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: { legend: { display: false } }
                }
            });
        }
    } catch (err) {
        console.error('Error loading patient registrations:', err);
    }
}

async function loadMedicineComparison() {
    try {
        const response = await fetch('/api/api_reports.php?type=medicine_stock_vs_given&limit=10');
        const data = await response.json();
        
        if (data.success && data.data && data.data.length > 0) {
            if (medicineChart) medicineChart.destroy();
            const ctx = document.getElementById('medicineComparisonChart').getContext('2d');
            medicineChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.data.map(d => d.name.substring(0, 15)),
                    datasets: [
                        {
                            label: 'Current Stock',
                            data: data.data.map(d => parseInt(d.stock)),
                            backgroundColor: '#3b82f6'
                        },
                        {
                            label: 'Dispensed (30d)',
                            data: data.data.map(d => parseInt(d.dispensed)),
                            backgroundColor: '#ef4444'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    indexAxis: 'y',
                    plugins: { legend: { position: 'top' } }
                }
            });
        }
    } catch (err) {
        console.error('Error loading medicine comparison:', err);
    }
}

async function loadStaffPerformance() {
    try {
        const response = await fetch('/api/api_reports.php?type=staff_performance&limit=5');
        const data = await response.json();
        
        if (data.success && data.data) {
            if (staffChart) staffChart.destroy();
            const ctx = document.getElementById('staffPerformanceChart').getContext('2d');
            staffChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.data.map(d => d.name),
                    datasets: [{
                        label: 'Visits Handled (30d)',
                        data: data.data.map(d => parseInt(d.visits)),
                        backgroundColor: '#f59e0b',
                        borderRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: { legend: { position: 'top' } }
                }
            });
        }
    } catch (err) {
        console.error('Error loading staff performance:', err);
    }
}

async function loadStatusDistribution() {
    try {
        const response = await fetch('/api/api_reports.php?type=visit_status_distribution');
        const data = await response.json();
        
        if (data.success && data.data) {
            if (statusChart) statusChart.destroy();
            const ctx = document.getElementById('statusChart').getContext('2d');
            statusChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: data.data.map(d => d.status),
                    datasets: [{
                        data: data.data.map(d => parseInt(d.count)),
                        backgroundColor: ['#f59e0b', '#3b82f6', '#8b5cf6', '#10b981', '#ef4444']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: { legend: { position: 'bottom' } }
                }
            });
        }
    } catch (err) {
        console.error('Error loading status distribution:', err);
    }
}

async function loadHourlyActivity() {
    try {
        const response = await fetch('/api/api_reports.php?type=hourly_activity');
        const data = await response.json();
        
        if (data.success && data.data) {
            if (hourlyChart) hourlyChart.destroy();
            const ctx = document.getElementById('hourlyChart').getContext('2d');
            const hours = data.data.map(d => {
                const hour = d.hour;
                const ampm = hour >= 12 ? 'PM' : 'AM';
                const display = hour > 12 ? hour-12 : (hour === 0 ? 12 : hour);
                return `${display}${ampm}`;
            });
            hourlyChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: hours,
                    datasets: [{
                        label: 'Visits',
                        data: data.data.map(d => parseInt(d.count)),
                        borderColor: '#8b5cf6',
                        backgroundColor: 'rgba(139, 92, 246, 0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: { legend: { display: false } }
                }
            });
        }
    } catch (err) {
        console.error('Error loading hourly activity:', err);
    }
}

async function loadRecentActivity() {
    try {
        const response = await fetch('/api/api_reports.php?type=recent_visits&limit=10');
        const data = await response.json();
        const tbody = document.getElementById('recentActivityTable');
        
        if (data.success && data.data && data.data.length > 0) {
            tbody.innerHTML = data.data.map(visit => `
                <tr class="border-b hover:bg-gray-50">
                    <td class="px-4 py-3 text-xs text-gray-500">${escapeHtml(visit.created_at)}</td>
                    <td class="px-4 py-3 font-mono text-xs">${escapeHtml(visit.record_number)}</td>
                    <td class="px-4 py-3 font-medium">${escapeHtml(visit.patient_name)}</td>
                    <td class="px-4 py-3">
                        <span class="px-2 py-1 rounded-full text-xs ${getStatusClass(visit.status)}">
                            ${visit.status}
                        </span>
                    </td>
                    <td class="px-4 py-3 text-sm">${escapeHtml(visit.staff_name || '-')}</td>
                </tr>
            `).join('');
        } else {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center py-8 text-gray-500">No recent activity</td></tr>';
        }
    } catch (err) {
        console.error('Error loading recent activity:', err);
        document.getElementById('recentActivityTable').innerHTML = '<tr><td colspan="5" class="text-center py-8 text-red-500">Error loading data</td></tr>';
    }
}

function getStatusClass(status) {
    const classes = {
        waiting: 'bg-yellow-100 text-yellow-800',
        called: 'bg-blue-100 text-blue-800',
        arrived: 'bg-purple-100 text-purple-800',
        visited: 'bg-indigo-100 text-indigo-800',
        served: 'bg-green-100 text-green-800',
        cancelled: 'bg-red-100 text-red-800'
    };
    return classes[status] || 'bg-gray-100 text-gray-800';
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

function refreshRecentActivity() {
    loadRecentActivity();
}

document.addEventListener('DOMContentLoaded', function() {
    loadAllData();
    
    const trendDays = document.getElementById('trendDays');
    if (trendDays) {
        trendDays.addEventListener('change', function() {
            loadVisitsTrend(this.value);
        });
    }
    
    // Auto-refresh every 60 seconds
    setInterval(function() {
        loadRecentActivity();
    }, 60000);
});
</script>

<style>
.stat-card {
    background: white;
    border-radius: 1rem;
    box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
    transition: all 0.3s ease;
}
.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px -5px rgb(0 0 0 / 0.1);
}
.chart-card {
    background: white;
    border-radius: 1rem;
    box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
    transition: all 0.3s ease;
}
.ai-insight {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 0.75rem;
    transition: all 0.3s ease;
}
.ai-insight:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.2);
}
.spinner {
    border: 3px solid #f3f3f3;
    border-top: 3px solid #3498db;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    animation: spin 1s linear infinite;
}
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
.fade-in-up {
    animation: fadeInUp 0.5s ease-out;
}
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>

<?php include '../includes/footer.php'; ?>