<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/settings.php';

require_staff();

$page_title = 'Register Patient - ' . ($app_name ?? 'Hospital Queue System');
$success_message = '';
$record_number = '';
$error_message = '';

// Handle direct form submission (alternative to AJAX)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['direct_submit'])) {
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $dob = !empty($_POST['dob']) ? $_POST['dob'] : null;
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $reason = trim($_POST['reason'] ?? '');
    $gender = $_POST['gender'] ?? '';
    $email = trim($_POST['email'] ?? '');
    $emergency_contact = trim($_POST['emergency_contact'] ?? '');
    $blood_group = $_POST['blood_group'] ?? '';

    if (!$first_name || !$reason) {
        $error_message = 'First Name and Visit Reason are required';
    } else {
        // Generate unique record number
        $record_number = 'PAT-' . strtoupper(uniqid());
        
        // Insert patient
        $stmt = mysqli_prepare($mysqli, "INSERT INTO patients (first_name, last_name, dob, phone, address, gender, email, emergency_contact, blood_group, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        mysqli_stmt_bind_param($stmt, 'sssssssss', $first_name, $last_name, $dob, $phone, $address, $gender, $email, $emergency_contact, $blood_group);
        
        if (mysqli_stmt_execute($stmt)) {
            $patient_id = mysqli_insert_id($mysqli);
            
            // Create visit record
            $stmt2 = mysqli_prepare($mysqli, "INSERT INTO visits (patient_id, record_number, reason, status, created_at) VALUES (?, ?, ?, 'waiting', NOW())");
            mysqli_stmt_bind_param($stmt2, 'iss', $patient_id, $record_number, $reason);
            
            if (mysqli_stmt_execute($stmt2)) {
                $success_message = 'Patient registered successfully!';
            } else {
                $error_message = 'Patient added but visit creation failed';
            }
        } else {
            $error_message = 'Error registering patient: ' . mysqli_error($mysqli);
        }
    }
}

// Get today's stats
$today = date('Y-m-d');
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM patients WHERE DATE(created_at) = '$today'");
$today_registrations = mysqli_fetch_assoc($result)['cnt'];

$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE DATE(created_at) = '$today' AND status = 'waiting'");
$today_waiting = mysqli_fetch_assoc($result)['cnt'];
?>
<?php include '../includes/header.php'; ?>

<div class="main-content">
    <div class="p-4 md:p-8">
        <!-- Header -->
        <div class="mb-8 fade-in-up">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h1 class="text-3xl md:text-4xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                        Patient Registration
                    </h1>
                    <p class="text-gray-500 mt-2">Register new patients and create visit records</p>
                </div>
                <div class="flex gap-3">
                    <a href="/queue.php" class="bg-gray-100 text-gray-700 px-5 py-2.5 rounded-xl font-medium hover:bg-gray-200 transition-all flex items-center gap-2">
                        <i class="fas fa-clock"></i>
                        View Queue
                    </a>
                    <a href="/patient_list.php" class="bg-indigo-100 text-indigo-700 px-5 py-2.5 rounded-xl font-medium hover:bg-indigo-200 transition-all flex items-center gap-2">
                        <i class="fas fa-users"></i>
                        Patient List
                    </a>
                </div>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Today's Registrations</p>
                        <p class="text-2xl font-bold text-blue-600 mt-1"><?php echo $today_registrations; ?></p>
                    </div>
                    <div class="bg-blue-100 rounded-xl p-3">
                        <i class="fas fa-user-plus text-blue-600 text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Currently Waiting</p>
                        <p class="text-2xl font-bold text-amber-600 mt-1"><?php echo $today_waiting; ?></p>
                    </div>
                    <div class="bg-amber-100 rounded-xl p-3">
                        <i class="fas fa-hourglass-half text-amber-600 text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Total Patients</p>
                        <p class="text-2xl font-bold text-emerald-600 mt-1">
                            <?php 
                                $result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM patients");
                                echo mysqli_fetch_assoc($result)['cnt'];
                            ?>
                        </p>
                    </div>
                    <div class="bg-emerald-100 rounded-xl p-3">
                        <i class="fas fa-hospital-user text-emerald-600 text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Quick Registration</p>
                        <p class="text-sm font-bold text-purple-600 mt-1">Instant Queue Entry</p>
                    </div>
                    <div class="bg-purple-100 rounded-xl p-3">
                        <i class="fas fa-bolt text-purple-600 text-xl"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Registration Form Card -->
        <div class="chart-card overflow-hidden">
            <div class="p-6 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
                <div class="flex items-center gap-3">
                    <div class="bg-blue-600 rounded-xl p-2">
                        <i class="fas fa-notes-medical text-white text-lg"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-bold text-gray-800">New Patient Registration</h3>
                        <p class="text-sm text-gray-500">Fill in the details below to register a new patient</p>
                    </div>
                </div>
            </div>
            
            <div class="p-6">
                <!-- Success/Error Messages -->
                <?php if ($success_message): ?>
                    <div class="mb-6 p-4 bg-green-50 border-l-4 border-green-500 text-green-700 rounded-xl">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-check-circle text-green-500 text-xl"></i>
                            <div>
                                <p class="font-semibold"><?php echo htmlspecialchars($success_message); ?></p>
                                <?php if ($record_number): ?>
                                    <p class="text-sm mt-1">Record Number: <span class="font-mono font-bold text-green-600"><?php echo htmlspecialchars($record_number); ?></span></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($error_message): ?>
                    <div class="mb-6 p-4 bg-red-50 border-l-4 border-red-500 text-red-700 rounded-xl">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-exclamation-circle text-red-500 text-xl"></i>
                            <p><?php echo htmlspecialchars($error_message); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <form id="patientForm" method="POST" class="space-y-6">
                    <input type="hidden" name="direct_submit" value="1">
                    
                    <!-- Personal Information Section -->
                    <div>
                        <h4 class="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                            <i class="fas fa-user-circle text-blue-500"></i>
                            Personal Information
                        </h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    First Name <span class="text-red-500">*</span>
                                </label>
                                <input type="text" name="first_name" required 
                                       class="form-input w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                                       placeholder="Enter first name">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                                <input type="text" name="last_name" 
                                       class="form-input w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                                       placeholder="Enter last name">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Gender</label>
                                <select name="gender" class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Date of Birth</label>
                                <input type="date" name="dob" 
                                       class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                                       max="<?php echo date('Y-m-d'); ?>">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                                <input type="tel" name="phone" 
                                       class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                                       placeholder="+1234567890">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                                <input type="email" name="email" 
                                       class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                                       placeholder="patient@example.com">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Blood Group</label>
                                <select name="blood_group" class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                                    <option value="">Select Blood Group</option>
                                    <option value="A+">A+</option>
                                    <option value="A-">A-</option>
                                    <option value="B+">B+</option>
                                    <option value="B-">B-</option>
                                    <option value="AB+">AB+</option>
                                    <option value="AB-">AB-</option>
                                    <option value="O+">O+</option>
                                    <option value="O-">O-</option>
                                </select>
                            </div>
                            
                            <div class="md:col-span-2">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Address</label>
                                <textarea name="address" rows="2" 
                                          class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                                          placeholder="Enter full address"></textarea>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Emergency Contact</label>
                                <input type="tel" name="emergency_contact" 
                                       class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                                       placeholder="Emergency contact number">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Visit Information Section -->
                    <div class="pt-4 border-t border-gray-100">
                        <h4 class="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                            <i class="fas fa-stethoscope text-green-500"></i>
                            Visit Information
                        </h4>
                        <div class="grid grid-cols-1 gap-5">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Reason for Visit <span class="text-red-500">*</span>
                                </label>
                                <textarea name="reason" rows="3" required 
                                          class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                                          placeholder="Describe the reason for visit, symptoms, or concerns..."></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Form Actions -->
                    <div class="pt-4 border-t border-gray-100">
                        <div class="flex flex-col sm:flex-row gap-3">
                            <button type="submit" class="flex-1 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold py-3 px-6 rounded-xl hover:shadow-lg transition-all flex items-center justify-center gap-2">
                                <i class="fas fa-save"></i>
                                Register Patient & Add to Queue
                            </button>
                            <button type="reset" class="px-6 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition font-medium flex items-center justify-center gap-2">
                                <i class="fas fa-undo-alt"></i>
                                Reset Form
                            </button>
                        </div>
                        <p class="text-xs text-gray-400 text-center mt-4">
                            <i class="fas fa-info-circle"></i> 
                            Patient will be automatically added to the waiting queue after registration
                        </p>
                    </div>
                </form>
            </div>
        </div>

        <!-- Recent Registrations -->
        <div class="mt-8 chart-card overflow-hidden">
            <div class="p-5 border-b border-gray-100">
                <h3 class="font-bold text-gray-800 flex items-center gap-2">
                    <i class="fas fa-history text-gray-500"></i>
                    Recent Registrations
                </h3>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600">Name</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600">Phone</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600">Registered</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600">Status</th>
                        </tr>
                    </thead>
                    <tbody id="recentPatients">
                        <tr>
                            <td colspan="4" class="text-center py-8">
                                <div class="spinner mx-auto"></div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
// Load recent registrations
async function loadRecentPatients() {
    try {
        const response = await fetch('/api/api_reports.php?type=recent_patients&limit=5');
        const data = await response.json();
        const tbody = document.getElementById('recentPatients');
        
        if (data.success && data.data && data.data.length > 0) {
            tbody.innerHTML = data.data.map(patient => `
                <tr class="border-b hover:bg-gray-50">
                    <td class="px-5 py-3">
                        <div class="font-medium text-gray-800">${escapeHtml(patient.first_name)} ${escapeHtml(patient.last_name || '')}</div>
                    </td>
                    <td class="px-5 py-3 text-sm text-gray-600">${escapeHtml(patient.phone || '-')}</td>
                    <td class="px-5 py-3 text-sm text-gray-500">${patient.created_at}</td>
                    <td class="px-5 py-3">
                        <span class="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs">Waiting</span>
                    </td>
                </tr>
            `).join('');
        } else {
            tbody.innerHTML = '<tr><td colspan="4" class="text-center py-8 text-gray-500">No recent registrations</td></tr>';
        }
    } catch (err) {
        console.error('Error loading recent patients:', err);
        document.getElementById('recentPatients').innerHTML = '<tr><td colspan="4" class="text-center py-8 text-red-500">Error loading data</td></tr>';
    }
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

// Auto-calculate age from DOB
document.querySelector('input[name="dob"]')?.addEventListener('change', function() {
    const dob = new Date(this.value);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const monthDiff = today.getMonth() - dob.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
        age--;
    }
    if (age > 0 && age < 120) {
        // Optional: Show age hint
        console.log(`Patient age: ${age} years`);
    }
});

// Form validation before submit
document.getElementById('patientForm')?.addEventListener('submit', function(e) {
    const firstName = this.querySelector('input[name="first_name"]').value.trim();
    const reason = this.querySelector('textarea[name="reason"]').value.trim();
    
    if (!firstName) {
        e.preventDefault();
        alert('Please enter patient\'s first name');
        return false;
    }
    
    if (!reason) {
        e.preventDefault();
        alert('Please enter the reason for visit');
        return false;
    }
    
    // Show loading state
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Registering...';
    submitBtn.disabled = true;
    
    setTimeout(() => {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }, 3000);
    
    return true;
});

// Load data on page load
document.addEventListener('DOMContentLoaded', function() {
    loadRecentPatients();
    
    // Auto-refresh recent patients every 30 seconds
    setInterval(loadRecentPatients, 30000);
});
</script>

<style>
/* Additional styles for form inputs */
.form-input:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

/* Smooth transitions */
.stat-card, .chart-card {
    transition: all 0.3s ease;
}

/* Custom select styling */
select.form-input {
    appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%236b7280'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 1rem center;
    background-size: 1rem;
    padding-right: 2.5rem;
}

/* Animation for fade-in */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.fade-in-up {
    animation: fadeInUp 0.5s ease-out;
}

/* Loading spinner */
.spinner {
    border: 3px solid #f3f3f3;
    border-top: 3px solid #3b82f6;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
</style>

<?php include '../includes/footer.php'; ?>