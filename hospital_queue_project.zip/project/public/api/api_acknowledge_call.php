<?php
require_once '../../includes/db.php';
require_once '../../includes/auth.php';

header('Content-Type: application/json');
require_staff();

$data = json_decode(file_get_contents('php://input'), true);
$visit_id = $data['visit_id'] ?? null;

if (!$visit_id) {
    echo json_encode(['success' => false, 'message' => 'Visit ID required']);
    exit;
}

$stmt = mysqli_prepare($mysqli, "UPDATE visits SET status = 'arrived', acknowledged_at = NOW() WHERE id = ?");
mysqli_stmt_bind_param($stmt, 'i', $visit_id);

if (mysqli_stmt_execute($stmt)) {
    echo json_encode(['success' => true, 'message' => 'Patient acknowledged']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error acknowledging']);
}
