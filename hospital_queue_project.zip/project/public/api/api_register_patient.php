<?php
require_once '../../includes/db.php';
require_once '../../includes/auth.php';

header('Content-Type: application/json');
require_staff();

$first_name = trim($_POST['first_name'] ?? '');
$last_name = trim($_POST['last_name'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$dob = trim($_POST['dob'] ?? '');
$address = trim($_POST['address'] ?? '');
$reason = trim($_POST['reason'] ?? '');

if (!$first_name) {
    echo json_encode(['success' => false, 'message' => 'First name is required']);
    exit;
}

if (!$reason) {
    echo json_encode(['success' => false, 'message' => 'Visit reason is required']);
    exit;
}

$stmt = mysqli_prepare($mysqli, "INSERT INTO patients (first_name, last_name, phone, dob, address) VALUES (?, ?, ?, ?, ?)");
mysqli_stmt_bind_param($stmt, 'sssss', $first_name, $last_name, $phone, $dob, $address);

if (!mysqli_stmt_execute($stmt)) {
    echo json_encode(['success' => false, 'message' => 'Error registering patient']);
    exit;
}

$patient_id = mysqli_insert_id($mysqli);

$prefix = 'REC-' . date('Ymd') . '-';
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE record_number LIKE '" . mysqli_real_escape_string($mysqli, $prefix) . "%'");
$row = mysqli_fetch_assoc($result);
$seq = intval($row['cnt']) + 1;
$record_number = $prefix . sprintf('%04d', $seq);

$stmt2 = mysqli_prepare($mysqli, "INSERT INTO visits (patient_id, record_number, reason, status) VALUES (?, ?, ?, 'waiting')");
mysqli_stmt_bind_param($stmt2, 'iss', $patient_id, $record_number, $reason);

if (!mysqli_stmt_execute($stmt2)) {
    echo json_encode(['success' => false, 'message' => 'Error creating visit']);
    exit;
}

$visit_id = mysqli_insert_id($mysqli);

echo json_encode([
    'success' => true,
    'record_number' => $record_number,
    'visit_id' => $visit_id,
    'patient_id' => $patient_id
]);
