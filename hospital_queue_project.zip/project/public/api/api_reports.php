<?php
require_once '../../includes/db.php';
require_once '../../includes/auth.php';

header('Content-Type: application/json');
require_staff();

$type = $_GET['type'] ?? 'visits_by_day';
$range = $_GET['range'] ?? 'today';
$from = $_GET['from'] ?? '';
$to = $_GET['to'] ?? '';
$limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
$months = isset($_GET['months']) ? intval($_GET['months']) : 6;

$dates = getDateRange($range, $from, $to);
$from_date = $dates['from'];
$to_date = $dates['to'];

$result = [];

switch ($type) {
    case 'visits_by_day':
        $result = getVisitsByDay($mysqli, $from_date, $to_date);
        break;
    case 'visits_by_staff':
        $result = getVisitsByStaff($mysqli, $from_date, $to_date);
        break;
    case 'avg_wait_time':
        $result = getAvgWaitTime($mysqli, $from_date, $to_date);
        break;
    case 'medicines_dispensed':
        $result = getMedicinesDispensed($mysqli, $from_date, $to_date, $limit);
        break;
    case 'daily_summary':
        $result = getDailySummary($mysqli, $from_date, $to_date);
        break;
    case 'patient_registration_trend':
        $result = getPatientRegistrationTrend($mysqli, $months);
        break;
    case 'medicine_stock_vs_given':
        $result = getMedicineStockVsGiven($mysqli, $limit);
        break;
    case 'staff_performance':
        $result = getStaffPerformance($mysqli, $limit);
        break;
    case 'visit_status_distribution':
        $result = getVisitStatusDistribution($mysqli);
        break;
    case 'hourly_activity':
        $result = getHourlyActivity($mysqli);
        break;
    case 'recent_visits':
        $result = getRecentVisits($mysqli, $limit);
        break;
    default:
        $result = ['error' => 'Invalid report type'];
}

echo json_encode([
    'success' => true,
    'type' => $type,
    'from' => $from_date,
    'to' => $to_date,
    'data' => $result
]);

function getDateRange($range, $from, $to) {
    $today = date('Y-m-d');
    
    switch ($range) {
        case 'today':
            return ['from' => $today, 'to' => $today];
        case 'yesterday':
            return ['from' => date('Y-m-d', strtotime('-1 day')), 'to' => date('Y-m-d', strtotime('-1 day'))];
        case 'last_7_days':
            return ['from' => date('Y-m-d', strtotime('-7 days')), 'to' => $today];
        case 'last_14_days':
            return ['from' => date('Y-m-d', strtotime('-14 days')), 'to' => $today];
        case 'last_30_days':
            return ['from' => date('Y-m-d', strtotime('-30 days')), 'to' => $today];
        case 'this_month':
            return ['from' => date('Y-m-01'), 'to' => $today];
        case 'last_month':
            $lastMonth = date('Y-m-01', strtotime('-1 month'));
            $lastMonthEnd = date('Y-m-t', strtotime('-1 month'));
            return ['from' => $lastMonth, 'to' => $lastMonthEnd];
        case 'ytd':
            return ['from' => date('Y-01-01'), 'to' => $today];
        case 'custom':
            return ['from' => $from, 'to' => $to];
        default:
            // Handle patterns like "last_X_days"
            if (preg_match('/last_(\d+)_days/', $range, $matches)) {
                $days = intval($matches[1]);
                return ['from' => date('Y-m-d', strtotime("-$days days")), 'to' => $today];
            }
            return ['from' => $today, 'to' => $today];
    }
}

function getVisitsByDay($mysqli, $from, $to) {
    $query = "
        SELECT 
            DATE(created_at) as day, 
            COUNT(*) as visits, 
            COUNT(CASE WHEN status='served' THEN 1 END) as served
        FROM visits
        WHERE DATE(created_at) BETWEEN ? AND ?
        GROUP BY DATE(created_at)
        ORDER BY day ASC
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ss', $from, $to);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'day' => $row['day'],
            'visits' => intval($row['visits']),
            'served' => intval($row['served'])
        ];
    }
    return $data;
}

function getVisitsByStaff($mysqli, $from, $to) {
    $query = "
        SELECT 
            u.full_name as name, 
            COUNT(v.id) as visits
        FROM visits v
        LEFT JOIN users u ON u.id = v.assigned_staff_id
        WHERE DATE(v.acknowledged_at) BETWEEN ? AND ?
        GROUP BY u.id
        ORDER BY visits DESC
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ss', $from, $to);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'name' => $row['name'] ?? 'Unassigned',
            'visits' => intval($row['visits'])
        ];
    }
    return $data;
}

function getAvgWaitTime($mysqli, $from, $to) {
    $query = "
        SELECT
            AVG(TIMESTAMPDIFF(MINUTE, v.created_at, v.served_at)) as avg_wait_minutes,
            MIN(TIMESTAMPDIFF(MINUTE, v.created_at, v.served_at)) as min_wait_minutes,
            MAX(TIMESTAMPDIFF(MINUTE, v.created_at, v.served_at)) as max_wait_minutes
        FROM visits v
        WHERE v.served_at IS NOT NULL
        AND DATE(v.served_at) BETWEEN ? AND ?
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ss', $from, $to);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    
    return [
        'avg_wait_minutes' => round($row['avg_wait_minutes'] ?? 0),
        'min_wait_minutes' => round($row['min_wait_minutes'] ?? 0),
        'max_wait_minutes' => round($row['max_wait_minutes'] ?? 0)
    ];
}

function getMedicinesDispensed($mysqli, $from, $to, $limit) {
    $query = "
        SELECT 
            m.name, 
            SUM(mg.qty) as total_qty, 
            COUNT(mg.id) as times_given
        FROM medicine_given mg
        JOIN medicines m ON m.id = mg.medicine_id
        WHERE DATE(mg.given_at) BETWEEN ? AND ?
        GROUP BY m.id
        ORDER BY total_qty DESC
        LIMIT ?
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ssi', $from, $to, $limit);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'name' => $row['name'],
            'total_qty' => intval($row['total_qty']),
            'times_given' => intval($row['times_given'])
        ];
    }
    return $data;
}

function getDailySummary($mysqli, $from, $to) {
    $query = "
        SELECT
            COUNT(*) as total_visits,
            COUNT(CASE WHEN status='served' THEN 1 END) as served,
            COUNT(CASE WHEN status='waiting' THEN 1 END) as waiting,
            COUNT(CASE WHEN status='called' THEN 1 END) as called,
            COUNT(CASE WHEN status='arrived' THEN 1 END) as arrived,
            COUNT(CASE WHEN status='visited' THEN 1 END) as visited,
            COUNT(CASE WHEN status='cancelled' THEN 1 END) as cancelled
        FROM visits
        WHERE DATE(created_at) BETWEEN ? AND ?
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ss', $from, $to);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    
    return [
        'total_visits' => intval($row['total_visits']),
        'served' => intval($row['served']),
        'waiting' => intval($row['waiting']),
        'called' => intval($row['called']),
        'arrived' => intval($row['arrived']),
        'visited' => intval($row['visited']),
        'cancelled' => intval($row['cancelled'])
    ];
}

function getPatientRegistrationTrend($mysqli, $months) {
    $query = "
        SELECT 
            DATE_FORMAT(created_at, '%b %Y') as month,
            COUNT(*) as count
        FROM patients 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? MONTH)
        AND deleted_at IS NULL
        GROUP BY YEAR(created_at), MONTH(created_at)
        ORDER BY created_at ASC
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'i', $months);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'month' => $row['month'],
            'count' => intval($row['count'])
        ];
    }
    return $data;
}

function getMedicineStockVsGiven($mysqli, $limit) {
    $query = "
        SELECT 
            m.id,
            m.name,
            m.quantity as stock,
            COALESCE(SUM(mg.qty), 0) as dispensed
        FROM medicines m
        LEFT JOIN medicine_given mg ON mg.medicine_id = m.id 
            AND mg.given_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY m.id
        ORDER BY dispensed DESC
        LIMIT ?
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'i', $limit);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'id' => $row['id'],
            'name' => $row['name'],
            'stock' => intval($row['stock']),
            'dispensed' => intval($row['dispensed'])
        ];
    }
    return $data;
}

function getStaffPerformance($mysqli, $limit) {
    $query = "
        SELECT 
            u.full_name as name,
            COUNT(v.id) as visits
        FROM users u
        LEFT JOIN visits v ON v.assigned_staff_id = u.id 
            AND v.acknowledged_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        WHERE u.role = 'staff' AND u.is_active = 1
        GROUP BY u.id
        ORDER BY visits DESC
        LIMIT ?
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'i', $limit);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'name' => $row['name'],
            'visits' => intval($row['visits'])
        ];
    }
    return $data;
}

function getVisitStatusDistribution($mysqli) {
    $query = "
        SELECT 
            status,
            COUNT(*) as count
        FROM visits
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY status
        ORDER BY count DESC
    ";
    
    $result = mysqli_query($mysqli, $query);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'status' => $row['status'],
            'count' => intval($row['count'])
        ];
    }
    return $data;
}

function getHourlyActivity($mysqli) {
    $query = "
        SELECT 
            HOUR(created_at) as hour,
            COUNT(*) as count
        FROM visits 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY HOUR(created_at)
        ORDER BY hour ASC
    ";
    
    $result = mysqli_query($mysqli, $query);
    
    // Initialize all 24 hours with 0
    $hourly_data = [];
    for ($i = 0; $i < 24; $i++) {
        $hourly_data[$i] = ['hour' => $i, 'count' => 0];
    }
    
    while ($row = mysqli_fetch_assoc($result)) {
        $hourly_data[$row['hour']]['count'] = intval($row['count']);
    }
    
    return array_values($hourly_data);
}

function getRecentVisits($mysqli, $limit) {
    $query = "
        SELECT 
            v.id,
            v.record_number,
            v.status,
            DATE_FORMAT(v.created_at, '%Y-%m-%d %H:%i') as created_at,
            CONCAT(p.first_name, ' ', p.last_name) as patient_name,
            u.full_name as staff_name
        FROM visits v
        LEFT JOIN patients p ON p.id = v.patient_id
        LEFT JOIN users u ON u.id = v.assigned_staff_id
        ORDER BY v.created_at DESC
        LIMIT ?
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'i', $limit);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'id' => $row['id'],
            'record_number' => $row['record_number'],
            'status' => $row['status'],
            'created_at' => $row['created_at'],
            'patient_name' => $row['patient_name'] ?? 'Unknown',
            'staff_name' => $row['staff_name']
        ];
    }
    return $data;
}
?>