<?php
require_once '../../includes/db.php';
require_once '../../includes/auth.php';

header('Content-Type: application/json');
require_staff();

$type = $_GET['type'] ?? 'visits_by_day';
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;

// Validate dates
if (empty($start_date) || empty($end_date)) {
    // Default to last 7 days if no dates provided
    $end_date = date('Y-m-d');
    $start_date = date('Y-m-d', strtotime('-6 days'));
}

// Ensure dates are in Y-m-d format
$start_date = date('Y-m-d', strtotime($start_date));
$end_date = date('Y-m-d', strtotime($end_date));

$result = [];

switch ($type) {
    case 'visits_by_day':
        $result = getVisitsByDay($mysqli, $start_date, $end_date);
        break;
    case 'daily_summary':
        $result = getDailySummary($mysqli, $start_date, $end_date);
        break;
    case 'status_distribution':
        $result = getStatusDistribution($mysqli, $start_date, $end_date);
        break;
    case 'staff_performance':
        $result = getStaffPerformance($mysqli, $start_date, $end_date);
        break;
    case 'wait_time_trend':
        $result = getWaitTimeTrend($mysqli, $start_date, $end_date);
        break;
    case 'wait_time_stats':
        $result = getWaitTimeStats($mysqli, $start_date, $end_date);
        break;
    case 'top_medicines':
        $result = getTopMedicines($mysqli, $start_date, $end_date, $limit);
        break;
    case 'recent_visits':
        $result = getRecentVisits($mysqli, $start_date, $end_date, $limit);
        break;
    case 'top_patients':
        $result = getTopPatients($mysqli, $start_date, $end_date, $limit);
        break;
    case 'daily_breakdown':
        $result = getDailyBreakdown($mysqli, $start_date, $end_date);
        break;
    default:
        echo json_encode(['success' => false, 'error' => 'Invalid report type']);
        exit;
}

echo json_encode([
    'success' => true,
    'type' => $type,
    'start_date' => $start_date,
    'end_date' => $end_date,
    'data' => $result
]);

function getVisitsByDay($mysqli, $start_date, $end_date) {
    $query = "
        SELECT 
            DATE(created_at) as day, 
            COUNT(*) as visits, 
            COUNT(CASE WHEN status='served' THEN 1 END) as served
        FROM visits
        WHERE DATE(created_at) BETWEEN ? AND ?
        GROUP BY DATE(created_at)
        ORDER BY day ASC
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ss', $start_date, $end_date);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'day' => $row['day'],
            'visits' => intval($row['visits']),
            'served' => intval($row['served'])
        ];
    }
    return $data;
}

function getDailySummary($mysqli, $start_date, $end_date) {
    $query = "
        SELECT
            COUNT(*) as total_visits,
            COUNT(CASE WHEN status='served' THEN 1 END) as served,
            COUNT(CASE WHEN status='visited' THEN 1 END) as visited,
            COUNT(CASE WHEN status='cancelled' THEN 1 END) as cancelled,
            COUNT(CASE WHEN status='waiting' THEN 1 END) as waiting,
            COUNT(CASE WHEN status='called' THEN 1 END) as called,
            COUNT(CASE WHEN status='arrived' THEN 1 END) as arrived
        FROM visits
        WHERE DATE(created_at) BETWEEN ? AND ?
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ss', $start_date, $end_date);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    
    return [
        'total_visits' => intval($row['total_visits']),
        'served' => intval($row['served']),
        'visited' => intval($row['visited']),
        'cancelled' => intval($row['cancelled']),
        'waiting' => intval($row['waiting']),
        'called' => intval($row['called']),
        'arrived' => intval($row['arrived'])
    ];
}

function getStatusDistribution($mysqli, $start_date, $end_date) {
    $query = "
        SELECT 
            status,
            COUNT(*) as count
        FROM visits
        WHERE DATE(created_at) BETWEEN ? AND ?
        GROUP BY status
        ORDER BY count DESC
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ss', $start_date, $end_date);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'status' => $row['status'],
            'count' => intval($row['count'])
        ];
    }
    return $data;
}

function getStaffPerformance($mysqli, $start_date, $end_date) {
    $query = "
        SELECT 
            u.full_name as name,
            COUNT(v.id) as visits
        FROM users u
        LEFT JOIN visits v ON v.assigned_staff_id = u.id 
            AND DATE(v.acknowledged_at) BETWEEN ? AND ?
        WHERE u.role = 'staff' AND u.is_active = 1
        GROUP BY u.id
        ORDER BY visits DESC
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ss', $start_date, $end_date);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'name' => $row['name'],
            'visits' => intval($row['visits'])
        ];
    }
    return $data;
}

function getWaitTimeTrend($mysqli, $start_date, $end_date) {
    $query = "
        SELECT 
            DATE(served_at) as day,
            AVG(TIMESTAMPDIFF(MINUTE, created_at, served_at)) as avg_wait
        FROM visits
        WHERE served_at IS NOT NULL
            AND DATE(served_at) BETWEEN ? AND ?
        GROUP BY DATE(served_at)
        ORDER BY day ASC
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ss', $start_date, $end_date);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'day' => $row['day'],
            'avg_wait' => round(floatval($row['avg_wait']), 1)
        ];
    }
    return $data;
}

function getWaitTimeStats($mysqli, $start_date, $end_date) {
    $query = "
        SELECT
            AVG(TIMESTAMPDIFF(MINUTE, created_at, served_at)) as avg_wait,
            MIN(TIMESTAMPDIFF(MINUTE, created_at, served_at)) as min_wait,
            MAX(TIMESTAMPDIFF(MINUTE, created_at, served_at)) as max_wait
        FROM visits
        WHERE served_at IS NOT NULL
            AND DATE(served_at) BETWEEN ? AND ?
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ss', $start_date, $end_date);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    
    return [
        'avg_wait_minutes' => round(floatval($row['avg_wait'] ?? 0), 1),
        'min_wait_minutes' => intval($row['min_wait'] ?? 0),
        'max_wait_minutes' => intval($row['max_wait'] ?? 0)
    ];
}

function getTopMedicines($mysqli, $start_date, $end_date, $limit) {
    $query = "
        SELECT 
            m.name,
            SUM(mg.qty) as total_qty,
            COUNT(mg.id) as times_given
        FROM medicine_given mg
        JOIN medicines m ON m.id = mg.medicine_id
        WHERE DATE(mg.given_at) BETWEEN ? AND ?
        GROUP BY m.id
        ORDER BY total_qty DESC
        LIMIT ?
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ssi', $start_date, $end_date, $limit);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'name' => $row['name'],
            'total_qty' => intval($row['total_qty']),
            'times_given' => intval($row['times_given'])
        ];
    }
    return $data;
}

function getRecentVisits($mysqli, $start_date, $end_date, $limit) {
    $query = "
        SELECT 
            v.id,
            v.record_number,
            v.status,
            v.created_at,
            CONCAT(p.first_name, ' ', p.last_name) as patient_name,
            u.full_name as staff_name,
            TIMESTAMPDIFF(MINUTE, v.created_at, v.served_at) as wait_time_minutes
        FROM visits v
        LEFT JOIN patients p ON p.id = v.patient_id
        LEFT JOIN users u ON u.id = v.assigned_staff_id
        WHERE DATE(v.created_at) BETWEEN ? AND ?
        ORDER BY v.created_at DESC
        LIMIT ?
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ssi', $start_date, $end_date, $limit);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'id' => $row['id'],
            'record_number' => $row['record_number'],
            'status' => $row['status'],
            'created_at' => $row['created_at'],
            'patient_name' => $row['patient_name'] ?? 'Unknown',
            'staff_name' => $row['staff_name'] ?? 'Unassigned',
            'wait_time_minutes' => $row['wait_time_minutes'] ?? '-'
        ];
    }
    return $data;
}

function getTopPatients($mysqli, $start_date, $end_date, $limit) {
    $query = "
        SELECT 
            CONCAT(p.first_name, ' ', p.last_name) as full_name,
            p.phone,
            COUNT(v.id) as visit_count,
            MAX(v.created_at) as last_visit
        FROM patients p
        JOIN visits v ON v.patient_id = p.id
        WHERE DATE(v.created_at) BETWEEN ? AND ?
            AND p.deleted_at IS NULL
        GROUP BY p.id
        ORDER BY visit_count DESC
        LIMIT ?
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ssi', $start_date, $end_date, $limit);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'full_name' => $row['full_name'],
            'phone' => $row['phone'],
            'visit_count' => intval($row['visit_count']),
            'last_visit' => $row['last_visit']
        ];
    }
    return $data;
}

function getDailyBreakdown($mysqli, $start_date, $end_date) {
    $query = "
        SELECT 
            DATE(created_at) as date,
            COUNT(*) as total,
            COUNT(CASE WHEN status='served' THEN 1 END) as served,
            COUNT(CASE WHEN status='visited' THEN 1 END) as visited,
            COUNT(CASE WHEN status='cancelled' THEN 1 END) as cancelled
        FROM visits
        WHERE DATE(created_at) BETWEEN ? AND ?
        GROUP BY DATE(created_at)
        ORDER BY date DESC
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ss', $start_date, $end_date);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'date' => $row['date'],
            'total' => intval($row['total']),
            'served' => intval($row['served']),
            'visited' => intval($row['visited']),
            'cancelled' => intval($row['cancelled'])
        ];
    }
    return $data;
}
?>