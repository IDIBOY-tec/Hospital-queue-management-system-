<?php
require_once '../../includes/db.php';
require_once '../../includes/auth.php';

header('Content-Type: application/json');
require_staff();

$status = $_GET['status'] ?? 'waiting';
$allowed_statuses = ['waiting', 'called', 'arrived', 'served', 'cancelled'];

if (!in_array($status, $allowed_statuses)) {
    $status = 'waiting';
}

$query = "
    SELECT v.id, v.record_number, v.reason, v.status, v.created_at, v.last_called_at, v.called_count,
           p.id as patient_id, p.first_name, p.last_name, p.phone
    FROM visits v
    JOIN patients p ON p.id = v.patient_id
    WHERE v.status = ?
    ORDER BY v.created_at ASC
";

$stmt = mysqli_prepare($mysqli, $query);
mysqli_stmt_bind_param($stmt, 's', $status);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$visits = [];
while ($row = mysqli_fetch_assoc($result)) {
    $visits[] = $row;
}

echo json_encode([
    'success' => true,
    'status' => $status,
    'visits' => $visits
]);
