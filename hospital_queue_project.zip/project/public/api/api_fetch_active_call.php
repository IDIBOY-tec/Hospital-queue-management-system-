<?php
require_once '../../includes/db.php';

header('Content-Type: application/json');

$query = "
    SELECT v.id, v.record_number, v.last_called_at, v.called_count,
           p.first_name, p.last_name
    FROM visits v
    JOIN patients p ON p.id = v.patient_id
    WHERE v.status = 'called' AND (v.acknowledged_at IS NULL OR v.acknowledged_at = '0000-00-00 00:00:00')
    ORDER BY v.last_called_at DESC, v.created_at ASC
    LIMIT 1
";

$result = mysqli_query($mysqli, $query);

if ($row = mysqli_fetch_assoc($result)) {
    echo json_encode([
        'success' => true,
        'visit' => $row
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'No active calls'
    ]);
}
