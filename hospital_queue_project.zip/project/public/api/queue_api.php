<?php
/**
 * Queue API - Complete working version
 */

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Set JSON response header
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Correct paths
require_once '../../includes/db.php';
require_once '../../includes/auth.php';
require_once '../../includes/settings.php';

// Check if database connection exists
if (!isset($mysqli) || !$mysqli) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

// Verify authentication
if (!function_exists('is_logged_in') || !is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized. Please log in.']);
    exit;
}

$current_user_id = get_current_user_id();

// Get staff role
$user = get_user_by_id($mysqli, $current_user_id);
$is_staff = ($user && ($user['role'] === 'staff' || $user['role'] === 'admin'));
$is_admin = ($user && $user['role'] === 'admin');

if (!$is_staff) {
    echo json_encode(['success' => false, 'message' => 'Access denied. Staff privileges required.']);
    exit;
}

// Get action from GET or POST
$action = '';
if (isset($_GET['action'])) {
    $action = $_GET['action'];
} elseif (isset($_POST['action'])) {
    $action = $_POST['action'];
} else {
    // Try to get from JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    if ($input && isset($input['action'])) {
        $action = $input['action'];
    }
}

if (empty($action)) {
    echo json_encode(['success' => false, 'message' => 'No action specified']);
    exit;
}

// Language configuration
$supported_languages = [
    'en' => ['name' => 'English', 'code' => 'en-US', 'flag' => '🇬🇧'],
    'luganda' => ['name' => 'Luganda', 'code' => 'lg-UG', 'flag' => '🇺🇬'],
    'swahili' => ['name' => 'Kiswahili', 'code' => 'sw-KE', 'flag' => '🇰🇪'],
    'acholi' => ['name' => 'Acholi', 'code' => 'ach-UG', 'flag' => '🇺🇬'],
    'runyankore' => ['name' => 'Runyankore', 'code' => 'nyn-UG', 'flag' => '🇺🇬'],
    'lusoga' => ['name' => 'Lusoga', 'code' => 'xog-UG', 'flag' => '🇺🇬'],
    'ateso' => ['name' => 'Ateso', 'code' => 'teo-UG', 'flag' => '🇺🇬'],
    'lugbara' => ['name' => 'Lugbara', 'code' => 'lgg-UG', 'flag' => '🇺🇬'],
    'rukiga' => ['name' => 'Rukiga', 'code' => 'cgg-UG', 'flag' => '🇺🇬'],
    'lango' => ['name' => 'Lango', 'code' => 'lao-UG', 'flag' => '🇺🇬']
];

// Route to appropriate function
switch ($action) {
    case 'get_queue':
        getQueue($mysqli);
        break;
    case 'call_patient':
        callPatient($mysqli);
        break;
    case 'mark_arrived':
        markArrived($mysqli);
        break;
    case 'mark_visited':
        markVisited($mysqli);
        break;
    case 'mark_served':
        markServed($mysqli);
        break;
    case 'cancel_visit':
        cancelVisit($mysqli);
        break;
    case 'get_stats':
        getStats($mysqli);
        break;
    case 'get_patients':
        getPatients($mysqli);
        break;
    case 'get_patient':
        getPatient($mysqli);
        break;
    case 'create_patient':
        createPatient($mysqli);
        break;
    case 'update_patient':
        updatePatient($mysqli);
        break;
    case 'soft_delete_patient':
        softDeletePatient($mysqli);
        break;
    case 'permanent_delete_patient':
        permanentDeletePatient($mysqli);
        break;
    case 'search_patients':
        searchPatients($mysqli);
        break;
    case 'get_visits':
        getVisits($mysqli);
        break;
    case 'create_visit':
        createVisit($mysqli);
        break;
    case 'delete_visit':
        deleteVisit($mysqli);
        break;
    case 'dispense_medicine':
        dispenseMedicine($mysqli);
        break;
    case 'get_patient_medicines':
        getPatientMedicines($mysqli);
        break;
    case 'get_languages':
        getLanguages($supported_languages);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action: ' . $action]);
        break;
}

// ============ QUEUE MANAGEMENT FUNCTIONS ============

function getQueue($mysqli) {
    $status = isset($_GET['status']) ? $_GET['status'] : 'waiting';
    $valid_statuses = ['waiting', 'called', 'arrived', 'visited', 'served', 'cancelled'];
    
    if (!in_array($status, $valid_statuses)) {
        $status = 'waiting';
    }
    
    $query = "
        SELECT 
            v.id,
            v.record_number,
            v.reason,
            v.status,
            v.created_at,
            v.called_count,
            v.last_called_at,
            v.acknowledged_at,
            v.arrived_at,
            v.visited_at,
            v.served_at,
            p.id as patient_id,
            p.first_name,
            p.last_name,
            p.phone,
            p.email,
            p.dob,
            p.gender,
            p.address,
            p.blood_group,
            p.emergency_contact,
            p.preferred_language,
            p.deleted_at
        FROM visits v
        JOIN patients p ON p.id = v.patient_id
        WHERE v.status = ? AND p.deleted_at IS NULL
        ORDER BY 
            CASE 
                WHEN v.status = 'called' THEN v.last_called_at
                ELSE v.created_at
            END ASC
    ";
    
    $stmt = mysqli_prepare($mysqli, $query);
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . mysqli_error($mysqli)]);
        return;
    }
    
    mysqli_stmt_bind_param($stmt, 's', $status);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $visits = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $visits[] = [
            'id' => (int)$row['id'],
            'record_number' => $row['record_number'],
            'reason' => $row['reason'],
            'status' => $row['status'],
            'created_at' => $row['created_at'],
            'called_count' => (int)$row['called_count'],
            'last_called_at' => $row['last_called_at'],
            'acknowledged_at' => $row['acknowledged_at'],
            'arrived_at' => $row['arrived_at'],
            'visited_at' => $row['visited_at'],
            'served_at' => $row['served_at'],
            'patient' => [
                'id' => (int)$row['patient_id'],
                'first_name' => $row['first_name'],
                'last_name' => $row['last_name'],
                'full_name' => trim($row['first_name'] . ' ' . ($row['last_name'] ?? '')),
                'phone' => $row['phone'],
                'email' => $row['email'],
                'dob' => $row['dob'],
                'gender' => $row['gender'],
                'address' => $row['address'],
                'blood_group' => $row['blood_group'],
                'emergency_contact' => $row['emergency_contact'],
                'preferred_language' => $row['preferred_language'] ?? 'en'
            ]
        ];
    }
    
    echo json_encode(['success' => true, 'visits' => $visits]);
}

function callPatient($mysqli) {
    $input = getInput();
    
    $visit_id = isset($input['visit_id']) ? (int)$input['visit_id'] : 0;
    $language = isset($input['language']) ? $input['language'] : 'en';
    
    if (!$visit_id) {
        echo json_encode(['success' => false, 'message' => 'Visit ID required']);
        return;
    }
    
    $current_user_id = get_current_user_id();
    
    // Get visit details
    $query = "SELECT v.*, p.first_name, p.last_name, p.phone, p.preferred_language 
              FROM visits v 
              JOIN patients p ON p.id = v.patient_id 
              WHERE v.id = ? AND p.deleted_at IS NULL";
    
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'i', $visit_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $visit = mysqli_fetch_assoc($result);
    
    if (!$visit) {
        echo json_encode(['success' => false, 'message' => 'Visit not found']);
        return;
    }
    
    if ($visit['status'] !== 'waiting') {
        echo json_encode(['success' => false, 'message' => 'Patient is not in waiting status']);
        return;
    }
    
    // Use patient's preferred language
    $call_language = !empty($visit['preferred_language']) && $visit['preferred_language'] !== 'en' ? $visit['preferred_language'] : $language;
    
    // Update visit status
    $update_stmt = mysqli_prepare($mysqli, "
        UPDATE visits 
        SET status = 'called', 
            last_called_at = NOW(), 
            called_count = called_count + 1,
            assigned_staff_id = ?
        WHERE id = ?
    ");
    
    mysqli_stmt_bind_param($update_stmt, 'ii', $current_user_id, $visit_id);
    
    if (mysqli_stmt_execute($update_stmt)) {
        $voice_message = getVoiceMessage($visit['first_name'], $visit['last_name'], $visit['record_number'], $call_language);
        
        echo json_encode([
            'success' => true, 
            'message' => 'Patient called successfully',
            'patient' => [
                'name' => trim($visit['first_name'] . ' ' . ($visit['last_name'] ?? '')),
                'record_number' => $visit['record_number'],
                'phone' => $visit['phone'],
                'preferred_language' => $call_language
            ],
            'voice_message' => $voice_message,
            'language' => $call_language
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to call patient']);
    }
}

function markArrived($mysqli) {
    $input = getInput();
    $visit_id = isset($input['visit_id']) ? (int)$input['visit_id'] : 0;
    
    if (!$visit_id) {
        echo json_encode(['success' => false, 'message' => 'Visit ID required']);
        return;
    }
    
    // Check current status
    $check = mysqli_query($mysqli, "SELECT status FROM visits WHERE id = $visit_id");
    $visit = mysqli_fetch_assoc($check);
    
    if (!$visit) {
        echo json_encode(['success' => false, 'message' => 'Visit not found']);
        return;
    }
    
    if ($visit['status'] !== 'called') {
        echo json_encode(['success' => false, 'message' => 'Patient must be called first']);
        return;
    }
    
    $stmt = mysqli_prepare($mysqli, "UPDATE visits SET status = 'arrived', acknowledged_at = NOW(), arrived_at = NOW() WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $visit_id);
    
    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(['success' => true, 'message' => 'Patient marked as arrived']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to mark arrived']);
    }
}

function markVisited($mysqli) {
    $input = getInput();
    $visit_id = isset($input['visit_id']) ? (int)$input['visit_id'] : 0;
    
    if (!$visit_id) {
        echo json_encode(['success' => false, 'message' => 'Visit ID required']);
        return;
    }
    
    // Check current status
    $check = mysqli_query($mysqli, "SELECT status FROM visits WHERE id = $visit_id");
    $visit = mysqli_fetch_assoc($check);
    
    if (!$visit) {
        echo json_encode(['success' => false, 'message' => 'Visit not found']);
        return;
    }
    
    if ($visit['status'] !== 'arrived') {
        echo json_encode(['success' => false, 'message' => 'Patient must arrive first']);
        return;
    }
    
    $stmt = mysqli_prepare($mysqli, "UPDATE visits SET status = 'visited', visited_at = NOW() WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $visit_id);
    
    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(['success' => true, 'message' => 'Patient marked as visited']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to mark visited']);
    }
}

function markServed($mysqli) {
    $input = getInput();
    $visit_id = isset($input['visit_id']) ? (int)$input['visit_id'] : 0;
    
    if (!$visit_id) {
        echo json_encode(['success' => false, 'message' => 'Visit ID required']);
        return;
    }
    
    // Check current status
    $check = mysqli_query($mysqli, "SELECT status FROM visits WHERE id = $visit_id");
    $visit = mysqli_fetch_assoc($check);
    
    if (!$visit) {
        echo json_encode(['success' => false, 'message' => 'Visit not found']);
        return;
    }
    
    if ($visit['status'] !== 'visited') {
        echo json_encode(['success' => false, 'message' => 'Patient must be visited first']);
        return;
    }
    
    $stmt = mysqli_prepare($mysqli, "UPDATE visits SET status = 'served', served_at = NOW() WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $visit_id);
    
    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(['success' => true, 'message' => 'Patient marked as served']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to mark served']);
    }
}

function cancelVisit($mysqli) {
    $input = getInput();
    $visit_id = isset($input['visit_id']) ? (int)$input['visit_id'] : 0;
    
    if (!$visit_id) {
        echo json_encode(['success' => false, 'message' => 'Visit ID required']);
        return;
    }
    
    $stmt = mysqli_prepare($mysqli, "UPDATE visits SET status = 'cancelled', cancelled_at = NOW() WHERE id = ? AND status != 'served'");
    mysqli_stmt_bind_param($stmt, 'i', $visit_id);
    
    if (mysqli_stmt_execute($stmt) && mysqli_affected_rows($mysqli) > 0) {
        echo json_encode(['success' => true, 'message' => 'Visit cancelled successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Cannot cancel this visit']);
    }
}

function getStats($mysqli) {
    $today = date('Y-m-d');
    
    $result = mysqli_query($mysqli, "
        SELECT 
            SUM(CASE WHEN status = 'waiting' AND DATE(created_at) = '$today' THEN 1 ELSE 0 END) as waiting,
            SUM(CASE WHEN status = 'called' AND DATE(created_at) = '$today' THEN 1 ELSE 0 END) as called,
            SUM(CASE WHEN status = 'arrived' AND DATE(created_at) = '$today' THEN 1 ELSE 0 END) as arrived,
            SUM(CASE WHEN status = 'visited' AND DATE(visited_at) = '$today' THEN 1 ELSE 0 END) as visited,
            SUM(CASE WHEN status = 'served' AND DATE(served_at) = '$today' THEN 1 ELSE 0 END) as served,
            COUNT(*) as total
        FROM visits 
        WHERE DATE(created_at) = '$today'
    ");
    
    $counts = mysqli_fetch_assoc($result);
    
    $wait_result = mysqli_query($mysqli, "
        SELECT AVG(TIMESTAMPDIFF(MINUTE, created_at, served_at)) as avg_wait 
        FROM visits 
        WHERE served_at IS NOT NULL 
        AND DATE(served_at) = '$today'
    ");
    
    $wait = mysqli_fetch_assoc($wait_result);
    
    $last_result = mysqli_query($mysqli, "
        SELECT last_called_at 
        FROM visits 
        WHERE last_called_at IS NOT NULL 
        ORDER BY last_called_at DESC 
        LIMIT 1
    ");
    
    $last = mysqli_fetch_assoc($last_result);
    
    echo json_encode([
        'success' => true,
        'data' => [
            'waiting' => intval($counts['waiting'] ?? 0),
            'called' => intval($counts['called'] ?? 0),
            'arrived' => intval($counts['arrived'] ?? 0),
            'visited' => intval($counts['visited'] ?? 0),
            'served' => intval($counts['served'] ?? 0),
            'total' => intval($counts['total'] ?? 0),
            'avg_wait_minutes' => round($wait['avg_wait'] ?? 0),
            'last_called_at' => $last['last_called_at'] ?? null
        ]
    ]);
}

// ============ PATIENT FUNCTIONS ============

function getPatients($mysqli) {
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
    $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
    
    $query = "SELECT * FROM patients WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT ? OFFSET ?";
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'ii', $limit, $offset);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $patients = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $patients[] = formatPatient($row);
    }
    
    $count_result = mysqli_query($mysqli, "SELECT COUNT(*) as total FROM patients WHERE deleted_at IS NULL");
    $total = mysqli_fetch_assoc($count_result)['total'];
    
    echo json_encode(['success' => true, 'patients' => $patients, 'total' => (int)$total]);
}

function getPatient($mysqli) {
    $patient_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    
    if (!$patient_id) {
        echo json_encode(['success' => false, 'message' => 'Patient ID required']);
        return;
    }
    
    $stmt = mysqli_prepare($mysqli, "SELECT * FROM patients WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $patient_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $patient = mysqli_fetch_assoc($result);
    
    if (!$patient) {
        echo json_encode(['success' => false, 'message' => 'Patient not found']);
        return;
    }
    
    $visits_query = mysqli_query($mysqli, "
        SELECT * FROM visits WHERE patient_id = $patient_id ORDER BY created_at DESC LIMIT 10
    ");
    $visits = [];
    while ($visit = mysqli_fetch_assoc($visits_query)) {
        $visits[] = $visit;
    }
    
    echo json_encode([
        'success' => true,
        'patient' => formatPatient($patient),
        'visits' => $visits
    ]);
}

function createPatient($mysqli) {
    $input = getInput();
    
    $first_name = trim($input['first_name'] ?? '');
    $last_name = trim($input['last_name'] ?? '');
    $dob = !empty($input['dob']) ? $input['dob'] : null;
    $phone = trim($input['phone'] ?? '');
    $email = trim($input['email'] ?? '');
    $address = trim($input['address'] ?? '');
    $gender = $input['gender'] ?? '';
    $blood_group = $input['blood_group'] ?? '';
    $emergency_contact = trim($input['emergency_contact'] ?? '');
    $preferred_language = $input['preferred_language'] ?? 'en';
    
    if (!$first_name) {
        echo json_encode(['success' => false, 'message' => 'First name is required']);
        return;
    }
    
    $stmt = mysqli_prepare($mysqli, "
        INSERT INTO patients (first_name, last_name, dob, phone, email, address, gender, blood_group, emergency_contact, preferred_language, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    
    mysqli_stmt_bind_param($stmt, 'ssssssssss', $first_name, $last_name, $dob, $phone, $email, $address, $gender, $blood_group, $emergency_contact, $preferred_language);
    
    if (mysqli_stmt_execute($stmt)) {
        $patient_id = mysqli_insert_id($mysqli);
        echo json_encode([
            'success' => true,
            'message' => 'Patient created successfully',
            'patient_id' => $patient_id
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to create patient']);
    }
}

function updatePatient($mysqli) {
    $input = getInput();
    
    $patient_id = isset($input['id']) ? (int)$input['id'] : 0;
    
    if (!$patient_id) {
        echo json_encode(['success' => false, 'message' => 'Patient ID required']);
        return;
    }
    
    $first_name = trim($input['first_name'] ?? '');
    $last_name = trim($input['last_name'] ?? '');
    $dob = !empty($input['dob']) ? $input['dob'] : null;
    $phone = trim($input['phone'] ?? '');
    $email = trim($input['email'] ?? '');
    $address = trim($input['address'] ?? '');
    $gender = $input['gender'] ?? '';
    $blood_group = $input['blood_group'] ?? '';
    $emergency_contact = trim($input['emergency_contact'] ?? '');
    $preferred_language = $input['preferred_language'] ?? 'en';
    
    if (!$first_name) {
        echo json_encode(['success' => false, 'message' => 'First name is required']);
        return;
    }
    
    $stmt = mysqli_prepare($mysqli, "
        UPDATE patients 
        SET first_name = ?, last_name = ?, dob = ?, phone = ?, email = ?, 
            address = ?, gender = ?, blood_group = ?, emergency_contact = ?, preferred_language = ?
        WHERE id = ?
    ");
    
    mysqli_stmt_bind_param($stmt, 'ssssssssssi', $first_name, $last_name, $dob, $phone, $email, $address, $gender, $blood_group, $emergency_contact, $preferred_language, $patient_id);
    
    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(['success' => true, 'message' => 'Patient updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update patient']);
    }
}

function softDeletePatient($mysqli) {
    $input = getInput();
    $patient_id = isset($input['id']) ? (int)$input['id'] : 0;
    
    if (!$patient_id) {
        echo json_encode(['success' => false, 'message' => 'Patient ID required']);
        return;
    }
    
    $stmt = mysqli_prepare($mysqli, "UPDATE patients SET deleted_at = NOW() WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $patient_id);
    
    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(['success' => true, 'message' => 'Patient moved to trash']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete patient']);
    }
}

function permanentDeletePatient($mysqli) {
    $input = getInput();
    $patient_id = isset($input['id']) ? (int)$input['id'] : 0;
    
    if (!$patient_id) {
        echo json_encode(['success' => false, 'message' => 'Patient ID required']);
        return;
    }
    
    // Get patient name
    $patient_query = mysqli_query($mysqli, "SELECT first_name, last_name FROM patients WHERE id = $patient_id");
    $patient = mysqli_fetch_assoc($patient_query);
    $patient_name = trim($patient['first_name'] . ' ' . ($patient['last_name'] ?? ''));
    
    // Get counts
    $visits_count = mysqli_fetch_assoc(mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE patient_id = $patient_id"))['cnt'];
    
    if ($visits_count > 0) {
        // Delete medicine_given records
        mysqli_query($mysqli, "DELETE FROM medicine_given WHERE visit_id IN (SELECT id FROM visits WHERE patient_id = $patient_id)");
        // Delete visits
        mysqli_query($mysqli, "DELETE FROM visits WHERE patient_id = $patient_id");
    }
    
    // Delete patient
    $stmt = mysqli_prepare($mysqli, "DELETE FROM patients WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $patient_id);
    
    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(['success' => true, 'message' => "Patient deleted permanently"]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete patient']);
    }
}

function searchPatients($mysqli) {
    $query = isset($_GET['q']) ? $_GET['q'] : '';
    if (strlen($query) < 2) {
        echo json_encode(['success' => true, 'patients' => []]);
        return;
    }
    
    $search = "%$query%";
    $stmt = mysqli_prepare($mysqli, "
        SELECT * FROM patients 
        WHERE (first_name LIKE ? OR last_name LIKE ? OR phone LIKE ? OR email LIKE ?)
        AND deleted_at IS NULL
        ORDER BY created_at DESC
        LIMIT 20
    ");
    
    mysqli_stmt_bind_param($stmt, 'ssss', $search, $search, $search, $search);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $patients = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $patients[] = formatPatient($row);
    }
    
    echo json_encode(['success' => true, 'patients' => $patients]);
}

// ============ VISIT FUNCTIONS ============

function getVisits($mysqli) {
    $patient_id = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : 0;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;
    
    if ($patient_id) {
        $stmt = mysqli_prepare($mysqli, "
            SELECT v.*, p.first_name, p.last_name, p.phone 
            FROM visits v 
            JOIN patients p ON p.id = v.patient_id 
            WHERE v.patient_id = ? AND p.deleted_at IS NULL
            ORDER BY v.created_at DESC 
            LIMIT ?
        ");
        mysqli_stmt_bind_param($stmt, 'ii', $patient_id, $limit);
    } else {
        $stmt = mysqli_prepare($mysqli, "
            SELECT v.*, p.first_name, p.last_name, p.phone 
            FROM visits v 
            JOIN patients p ON p.id = v.patient_id 
            WHERE p.deleted_at IS NULL
            ORDER BY v.created_at DESC 
            LIMIT ?
        ");
        mysqli_stmt_bind_param($stmt, 'i', $limit);
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $visits = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $visits[] = $row;
    }
    
    echo json_encode(['success' => true, 'visits' => $visits]);
}

function createVisit($mysqli) {
    $input = getInput();
    
    $patient_id = isset($input['patient_id']) ? (int)$input['patient_id'] : 0;
    $reason = trim($input['reason'] ?? '');
    
    if (!$patient_id || !$reason) {
        echo json_encode(['success' => false, 'message' => 'Patient ID and reason are required']);
        return;
    }
    
    $record_number = 'VIS-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
    
    $stmt = mysqli_prepare($mysqli, "
        INSERT INTO visits (patient_id, record_number, reason, status, created_at)
        VALUES (?, ?, ?, 'waiting', NOW())
    ");
    
    mysqli_stmt_bind_param($stmt, 'iss', $patient_id, $record_number, $reason);
    
    if (mysqli_stmt_execute($stmt)) {
        $visit_id = mysqli_insert_id($mysqli);
        echo json_encode([
            'success' => true,
            'message' => 'Visit created successfully',
            'visit_id' => $visit_id,
            'record_number' => $record_number
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to create visit']);
    }
}

function deleteVisit($mysqli) {
    $input = getInput();
    $visit_id = isset($input['id']) ? (int)$input['id'] : 0;
    
    if (!$visit_id) {
        echo json_encode(['success' => false, 'message' => 'Visit ID required']);
        return;
    }
    
    // Check for medicines
    $check = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM medicine_given WHERE visit_id = $visit_id");
    $has_medicines = mysqli_fetch_assoc($check)['cnt'] > 0;
    
    if ($has_medicines) {
        echo json_encode(['success' => false, 'message' => 'Cannot delete visit with dispensed medicines']);
        return;
    }
    
    $stmt = mysqli_prepare($mysqli, "DELETE FROM visits WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $visit_id);
    
    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(['success' => true, 'message' => 'Visit deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete visit']);
    }
}

// ============ MEDICINE FUNCTIONS ============

function dispenseMedicine($mysqli) {
    $input = getInput();
    
    $visit_id = isset($input['visit_id']) ? (int)$input['visit_id'] : 0;
    $medicine_id = isset($input['medicine_id']) ? (int)$input['medicine_id'] : 0;
    $quantity = isset($input['quantity']) ? (int)$input['quantity'] : 0;
    $notes = trim($input['notes'] ?? '');
    $current_user_id = get_current_user_id();
    
    if (!$visit_id || !$medicine_id || $quantity <= 0) {
        echo json_encode(['success' => false, 'message' => 'Visit ID, Medicine ID, and quantity are required']);
        return;
    }
    
    $med_check = mysqli_query($mysqli, "SELECT quantity, name FROM medicines WHERE id = $medicine_id");
    $medicine = mysqli_fetch_assoc($med_check);
    
    if (!$medicine) {
        echo json_encode(['success' => false, 'message' => 'Medicine not found']);
        return;
    }
    
    if ($medicine['quantity'] < $quantity) {
        echo json_encode(['success' => false, 'message' => 'Insufficient stock. Available: ' . $medicine['quantity']]);
        return;
    }
    
    mysqli_begin_transaction($mysqli);
    
    try {
        $new_qty = $medicine['quantity'] - $quantity;
        $update_stock = mysqli_prepare($mysqli, "UPDATE medicines SET quantity = ? WHERE id = ?");
        mysqli_stmt_bind_param($update_stock, 'ii', $new_qty, $medicine_id);
        mysqli_stmt_execute($update_stock);
        
        $insert_given = mysqli_prepare($mysqli, "
            INSERT INTO medicine_given (visit_id, medicine_id, qty, staff_id, notes, given_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        mysqli_stmt_bind_param($insert_given, 'iiiss', $visit_id, $medicine_id, $quantity, $current_user_id, $notes);
        mysqli_stmt_execute($insert_given);
        
        mysqli_commit($mysqli);
        
        echo json_encode([
            'success' => true,
            'message' => "{$quantity} x {$medicine['name']} dispensed successfully"
        ]);
    } catch (Exception $e) {
        mysqli_rollback($mysqli);
        echo json_encode(['success' => false, 'message' => 'Failed to dispense medicine']);
    }
}

function getPatientMedicines($mysqli) {
    $visit_id = isset($_GET['visit_id']) ? (int)$_GET['visit_id'] : 0;
    
    if (!$visit_id) {
        echo json_encode(['success' => false, 'message' => 'Visit ID required']);
        return;
    }
    
    $query = mysqli_query($mysqli, "
        SELECT mg.*, m.name, m.unit, m.price, u.full_name as staff_name
        FROM medicine_given mg
        JOIN medicines m ON m.id = mg.medicine_id
        LEFT JOIN users u ON u.id = mg.staff_id
        WHERE mg.visit_id = $visit_id
        ORDER BY mg.given_at DESC
    ");
    
    $medicines = [];
    while ($row = mysqli_fetch_assoc($query)) {
        $medicines[] = $row;
    }
    
    echo json_encode(['success' => true, 'medicines' => $medicines]);
}

// ============ HELPER FUNCTIONS ============

function getInput() {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        $input = $_POST;
    }
    return $input;
}

function getVoiceMessage($first_name, $last_name, $record_number, $language) {
    $patient_name = trim($first_name . ' ' . ($last_name ?? ''));
    
    $messages = [
        'en' => "Attention please. Patient {$patient_name} with record number {$record_number}, please proceed to the service counter.",
        'luganda' => "Mukama y'awulire. Omulwadde {$patient_name} alina ennamba {$record_number}, kwatiriza okutuuka ku dduuka ly'abaami.",
        'swahili' => "Tafadhali tahadhari. Mgonjwa {$patient_name} mwenye namba {$record_number}, tafadhali njoo kwenye kaunta ya huduma.",
        'acholi' => "Winyo ma woko. Labong {$patient_name} ma namba {$record_number}, ber itim yot ma icomo i kompiyuta pa tic.",
        'runyankore' => "Mwebare okukiriza. Omurwaire {$patient_name} orikwenda nombura {$record_number}, nikushaba ogende ahakuhweera.",
        'lusoga' => "Mwebale okukkiriza. Omulwadde {$patient_name} alina ennamba {$record_number}, kwegenda ku bbali ly'obulamu.",
        'ateso' => "Akamaiso. Ekipakasi {$patient_name} ekina namba {$record_number}, ikonyo ikosi ikejao.",
        'lugbara' => "Mìri o'biti. Adri {$patient_name} drí nombà {$record_number}, ayiko a'di o'di o'biti ri.",
        'rukiga' => "Mwebare okukiriza. Omurwaire {$patient_name} orikwenda nombura {$record_number}, nikushaba ogende aha kuhweera.",
        'lango' => "Winnyo. Labong {$patient_name} ma namba {$record_number}, ber itim yot ma icomo i kompyuta pa tic."
    ];
    
    return $messages[$language] ?? $messages['en'];
}

function getLanguages($supported_languages) {
    echo json_encode(['success' => true, 'languages' => $supported_languages]);
}

function formatPatient($row) {
    return [
        'id' => (int)$row['id'],
        'first_name' => $row['first_name'],
        'last_name' => $row['last_name'],
        'full_name' => trim($row['first_name'] . ' ' . ($row['last_name'] ?? '')),
        'dob' => $row['dob'],
        'phone' => $row['phone'],
        'email' => $row['email'],
        'address' => $row['address'],
        'gender' => $row['gender'],
        'blood_group' => $row['blood_group'],
        'emergency_contact' => $row['emergency_contact'],
        'preferred_language' => $row['preferred_language'] ?? 'en',
        'deleted_at' => $row['deleted_at'],
        'created_at' => $row['created_at']
    ];
}
?>