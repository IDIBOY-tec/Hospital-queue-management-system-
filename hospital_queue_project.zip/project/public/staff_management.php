<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/settings.php';

require_admin();

$page_title = 'Staff Management - ' . ($app_name ?? 'Hospital Queue System');
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add_staff') {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $full_name = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $position = trim($_POST['position'] ?? 'Staff');

        if (!$username || !$password || !$full_name) {
            $message = 'Full Name, Username, and Password are required';
            $message_type = 'error';
        } elseif (strlen($password) < 6) {
            $message = 'Password must be at least 6 characters';
            $message_type = 'error';
        } else {
            $existing = get_user_by_username($mysqli, $username);
            if ($existing) {
                $message = 'Username already exists';
                $message_type = 'error';
            } else {
                $password_hash = hash_password($password);
                $stmt = mysqli_prepare($mysqli, "INSERT INTO users (username, password_hash, full_name, role, email, phone, position, is_active, created_at) VALUES (?, ?, ?, 'staff', ?, ?, ?, 1, NOW())");
                mysqli_stmt_bind_param($stmt, 'ssssss', $username, $password_hash, $full_name, $email, $phone, $position);

                if (mysqli_stmt_execute($stmt)) {
                    $message = 'Staff member added successfully';
                    $message_type = 'success';
                } else {
                    $message = 'Error adding staff: ' . mysqli_error($mysqli);
                    $message_type = 'error';
                }
            }
        }
    } elseif ($_POST['action'] === 'edit_staff') {
        $staff_id = intval($_POST['staff_id'] ?? 0);
        $full_name = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $position = trim($_POST['position'] ?? 'Staff');

        if ($staff_id > 0 && $full_name) {
            $stmt = mysqli_prepare($mysqli, "UPDATE users SET full_name=?, email=?, phone=?, position=? WHERE id=? AND role='staff'");
            mysqli_stmt_bind_param($stmt, 'ssssi', $full_name, $email, $phone, $position, $staff_id);
            
            if (mysqli_stmt_execute($stmt)) {
                $message = 'Staff member updated successfully';
                $message_type = 'success';
            } else {
                $message = 'Error updating staff';
                $message_type = 'error';
            }
        }
    } elseif ($_POST['action'] === 'delete_staff') {
        $staff_id = intval($_POST['staff_id'] ?? 0);
        if ($staff_id > 0 && $staff_id !== get_current_user_id()) {
            // Check if staff has handled any visits
            $check = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE assigned_staff_id = $staff_id");
            $has_visits = mysqli_fetch_assoc($check)['cnt'] > 0;
            
            if ($has_visits) {
                $message = 'Cannot delete: Staff member has handled patient visits';
                $message_type = 'error';
            } else {
                $stmt = mysqli_prepare($mysqli, "DELETE FROM users WHERE id=? AND role='staff'");
                mysqli_stmt_bind_param($stmt, 'i', $staff_id);
                if (mysqli_stmt_execute($stmt)) {
                    $message = 'Staff member deleted successfully';
                    $message_type = 'success';
                } else {
                    $message = 'Error deleting staff';
                    $message_type = 'error';
                }
            }
        } else {
            $message = 'Cannot delete your own account';
            $message_type = 'error';
        }
    } elseif ($_POST['action'] === 'toggle_staff') {
        $staff_id = intval($_POST['staff_id'] ?? 0);
        if ($staff_id > 0 && $staff_id !== get_current_user_id()) {
            $is_active = intval($_POST['is_active'] ?? 0);
            $new_active = $is_active ? 0 : 1;
            $stmt = mysqli_prepare($mysqli, "UPDATE users SET is_active=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, 'ii', $new_active, $staff_id);
            if (mysqli_stmt_execute($stmt)) {
                $status = $new_active ? 'activated' : 'deactivated';
                $message = "Staff member $status successfully";
                $message_type = 'success';
            }
        }
    }
}

// Get staff members with additional stats
$result = mysqli_query($mysqli, "
    SELECT u.*, 
           COUNT(DISTINCT v.id) as visits_handled,
           COUNT(DISTINCT mg.id) as medicines_dispensed
    FROM users u
    LEFT JOIN visits v ON v.assigned_staff_id = u.id AND DATE(v.created_at) >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    LEFT JOIN medicine_given mg ON mg.staff_id = u.id AND DATE(mg.given_at) >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    WHERE u.role = 'staff'
    GROUP BY u.id
    ORDER BY u.is_active DESC, u.created_at DESC
");
$staff_members = [];
$active_count = 0;
$inactive_count = 0;

while ($row = mysqli_fetch_assoc($result)) {
    $staff_members[] = $row;
    if ($row['is_active']) $active_count++;
    else $inactive_count++;
}

// Get total staff count
$total_staff = count($staff_members);

// Get performance metrics
$top_performer = null;
if (!empty($staff_members)) {
    usort($staff_members, function($a, $b) {
        return $b['visits_handled'] - $a['visits_handled'];
    });
    $top_performer = $staff_members[0];
}
?>
<?php include '../includes/header.php'; ?>

<div class="main-content">
    <div class="p-4 md:p-8">
        <!-- Header -->
        <div class="mb-8 fade-in-up">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h1 class="text-3xl md:text-4xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                        Staff Management
                    </h1>
                    <p class="text-gray-500 mt-2">Manage your team members and monitor their performance</p>
                </div>
                <button onclick="openAddModal()" class="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg transition-all flex items-center gap-2">
                    <i class="fas fa-plus"></i>
                    Add New Staff
                </button>
            </div>
        </div>

        <!-- Alert Message -->
        <?php if ($message): ?>
            <div class="mb-6 p-4 rounded-xl <?php echo $message_type === 'success' ? 'bg-green-50 border-l-4 border-green-500 text-green-700' : 'bg-red-50 border-l-4 border-red-500 text-red-700'; ?>">
                <div class="flex items-center gap-2">
                    <i class="fas <?php echo $message_type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                    <span><?php echo htmlspecialchars($message); ?></span>
                </div>
            </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Total Staff</p>
                        <p class="text-2xl font-bold text-blue-600 mt-1"><?php echo $total_staff; ?></p>
                    </div>
                    <div class="bg-blue-100 rounded-xl p-3">
                        <i class="fas fa-users text-blue-600 text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Active Staff</p>
                        <p class="text-2xl font-bold text-green-600 mt-1"><?php echo $active_count; ?></p>
                    </div>
                    <div class="bg-green-100 rounded-xl p-3">
                        <i class="fas fa-user-check text-green-600 text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Inactive Staff</p>
                        <p class="text-2xl font-bold text-red-600 mt-1"><?php echo $inactive_count; ?></p>
                    </div>
                    <div class="bg-red-100 rounded-xl p-3">
                        <i class="fas fa-user-slash text-red-600 text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Avg. Performance</p>
                        <p class="text-2xl font-bold text-purple-600 mt-1">
                            <?php 
                                $avg_visits = $total_staff > 0 ? round(array_sum(array_column($staff_members, 'visits_handled')) / $total_staff) : 0;
                                echo $avg_visits;
                            ?>
                        </p>
                    </div>
                    <div class="bg-purple-100 rounded-xl p-3">
                        <i class="fas fa-chart-line text-purple-600 text-xl"></i>
                    </div>
                    <p class="text-xs text-gray-400 mt-1">Visits (30 days)</p>
                </div>
            </div>
        </div>

        <!-- Staff List Table -->
        <div class="chart-card overflow-hidden">
            <div class="p-5 border-b border-gray-100 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <h3 class="font-bold text-gray-800 flex items-center gap-2">
                    <i class="fas fa-id-card text-blue-500"></i>
                    Staff Directory
                </h3>
                <div class="flex gap-2">
                    <div class="relative">
                        <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-sm"></i>
                        <input type="text" id="searchStaff" placeholder="Search by name, username, or email..." 
                               class="pl-9 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-blue-400 w-64">
                    </div>
                    <button onclick="exportToCSV()" class="px-3 py-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition text-sm">
                        <i class="fas fa-download"></i> Export
                    </button>
                </div>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full" id="staffTable">
                    <thead class="bg-gray-50 border-b border-gray-200">
                        <tr>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Staff</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Contact</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Position</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Performance</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Joined</th>
                            <th class="px-5 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php foreach ($staff_members as $staff): 
                            $is_top = $top_performer && $top_performer['id'] == $staff['id'] && $staff['visits_handled'] > 0;
                        ?>
                            <tr class="hover:bg-gray-50 transition staff-row" 
                                data-name="<?php echo strtolower(htmlspecialchars($staff['full_name'])); ?>"
                                data-username="<?php echo strtolower(htmlspecialchars($staff['username'])); ?>"
                                data-email="<?php echo strtolower(htmlspecialchars($staff['email'] ?? '')); ?>">
                                <td class="px-5 py-3">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-full bg-gradient-to-r from-blue-400 to-blue-600 flex items-center justify-center text-white font-bold">
                                            <?php echo strtoupper(substr($staff['full_name'], 0, 1)); ?>
                                        </div>
                                        <div>
                                            <div class="font-medium text-gray-800"><?php echo htmlspecialchars($staff['full_name']); ?></div>
                                            <div class="text-xs text-gray-400">@<?php echo htmlspecialchars($staff['username']); ?></div>
                                        </div>
                                        <?php if ($is_top): ?>
                                            <span class="ml-2 px-2 py-0.5 bg-yellow-100 text-yellow-700 text-xs rounded-full flex items-center gap-1">
                                                <i class="fas fa-trophy text-xs"></i> Top Performer
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="px-5 py-3">
                                    <div class="text-sm text-gray-600">
                                        <?php if ($staff['email']): ?>
                                            <div class="flex items-center gap-1 mb-1">
                                                <i class="fas fa-envelope text-gray-400 text-xs"></i>
                                                <span><?php echo htmlspecialchars($staff['email']); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        <?php if ($staff['phone']): ?>
                                            <div class="flex items-center gap-1">
                                                <i class="fas fa-phone text-gray-400 text-xs"></i>
                                                <span><?php echo htmlspecialchars($staff['phone']); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="px-5 py-3">
                                    <span class="px-2 py-1 bg-gray-100 text-gray-700 rounded-lg text-xs font-medium">
                                        <?php echo htmlspecialchars($staff['position'] ?? 'Staff'); ?>
                                    </span>
                                </td>
                                <td class="px-5 py-3">
                                    <div class="space-y-1">
                                        <div class="flex items-center justify-between text-xs">
                                            <span class="text-gray-500">Visits (30d)</span>
                                            <span class="font-semibold text-gray-700"><?php echo $staff['visits_handled']; ?></span>
                                        </div>
                                        <div class="w-full bg-gray-200 rounded-full h-1.5">
                                            <div class="bg-blue-600 h-1.5 rounded-full" style="width: <?php echo min(100, ($staff['visits_handled'] / max(1, $avg_visits)) * 100); ?>%"></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-5 py-3">
                                    <span class="px-2 py-1 rounded-full text-xs font-medium <?php echo $staff['is_active'] ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                                        <i class="fas <?php echo $staff['is_active'] ? 'fa-circle' : 'fa-circle'; ?> text-xs mr-1"></i>
                                        <?php echo $staff['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </td>
                                <td class="px-5 py-3 text-sm text-gray-500">
                                    <?php echo date('M d, Y', strtotime($staff['created_at'])); ?>
                                </td>
                                <td class="px-5 py-3">
                                    <div class="flex items-center justify-center gap-2">
                                        <button onclick="editStaff(<?php echo htmlspecialchars(json_encode($staff)); ?>)" 
                                                class="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="action" value="toggle_staff">
                                            <input type="hidden" name="staff_id" value="<?php echo $staff['id']; ?>">
                                            <input type="hidden" name="is_active" value="<?php echo $staff['is_active']; ?>">
                                            <button type="submit" class="p-1.5 text-amber-600 hover:bg-amber-50 rounded-lg transition">
                                                <i class="fas <?php echo $staff['is_active'] ? 'fa-pause-circle' : 'fa-play-circle'; ?>"></i>
                                            </button>
                                        </form>
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this staff member? This action cannot be undone.');">
                                            <input type="hidden" name="action" value="delete_staff">
                                            <input type="hidden" name="staff_id" value="<?php echo $staff['id']; ?>">
                                            <button type="submit" class="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if (empty($staff_members)): ?>
                <div class="text-center py-12 text-gray-400">
                    <i class="fas fa-users text-4xl mb-3 opacity-50"></i>
                    <p>No staff members found. Click "Add New Staff" to get started.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Add/Edit Staff Modal -->
<div id="staffModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden items-center justify-center p-4" style="display: none;">
    <div class="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6 border-b border-gray-100 flex justify-between items-center">
            <h3 class="text-xl font-bold text-gray-800" id="modalTitle">Add New Staff Member</h3>
            <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-times text-xl"></i>
            </button>
        </div>
        <form method="POST" id="staffForm" class="p-6 space-y-4">
            <input type="hidden" name="action" id="formAction" value="add_staff">
            <input type="hidden" name="staff_id" id="staffId">
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                <input type="text" name="full_name" id="fullName" required 
                       class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            </div>
            
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Username *</label>
                    <input type="text" name="username" id="username" required 
                           class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Position</label>
                    <input type="text" name="position" id="position" value="Staff"
                           class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
            </div>
            
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input type="email" name="email" id="email"
                           class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                    <input type="tel" name="phone" id="phone"
                           class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
            </div>
            
            <div id="passwordFields">
                <label class="block text-sm font-medium text-gray-700 mb-1">Password *</label>
                <input type="password" name="password" id="password" 
                       class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                <p class="text-xs text-gray-400 mt-1">Minimum 6 characters</p>
            </div>
            
            <div class="flex gap-3 pt-4">
                <button type="submit" class="flex-1 bg-gradient-to-r from-blue-600 to-blue-700 text-white py-2.5 rounded-xl hover:shadow-lg transition font-semibold">
                    <i class="fas fa-save mr-2"></i> Save Staff Member
                </button>
                <button type="button" onclick="closeModal()" class="flex-1 bg-gray-100 text-gray-700 py-2.5 rounded-xl hover:bg-gray-200 transition">
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Search functionality
document.getElementById('searchStaff')?.addEventListener('keyup', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('.staff-row');
    
    rows.forEach(row => {
        const name = row.getAttribute('data-name');
        const username = row.getAttribute('data-username');
        const email = row.getAttribute('data-email');
        
        if (name?.includes(searchTerm) || username?.includes(searchTerm) || email?.includes(searchTerm)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});

// Modal functions
function openAddModal() {
    document.getElementById('modalTitle').textContent = 'Add New Staff Member';
    document.getElementById('formAction').value = 'add_staff';
    document.getElementById('staffId').value = '';
    document.getElementById('fullName').value = '';
    document.getElementById('username').value = '';
    document.getElementById('position').value = 'Staff';
    document.getElementById('email').value = '';
    document.getElementById('phone').value = '';
    document.getElementById('password').value = '';
    document.getElementById('password').required = true;
    document.getElementById('passwordFields').style.display = 'block';
    document.getElementById('staffModal').style.display = 'flex';
}

function editStaff(staff) {
    document.getElementById('modalTitle').textContent = 'Edit Staff Member';
    document.getElementById('formAction').value = 'edit_staff';
    document.getElementById('staffId').value = staff.id;
    document.getElementById('fullName').value = staff.full_name;
    document.getElementById('username').value = staff.username;
    document.getElementById('position').value = staff.position || 'Staff';
    document.getElementById('email').value = staff.email || '';
    document.getElementById('phone').value = staff.phone || '';
    document.getElementById('password').required = false;
    document.getElementById('passwordFields').style.display = 'none';
    document.getElementById('staffModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('staffModal').style.display = 'none';
}

// Export to CSV
function exportToCSV() {
    const rows = document.querySelectorAll('#staffTable tbody tr');
    let csv = [['Full Name', 'Username', 'Email', 'Phone', 'Position', 'Status', 'Visits (30d)', 'Joined Date']];
    
    rows.forEach(row => {
        if (row.style.display !== 'none') {
            const cells = row.querySelectorAll('td');
            if (cells.length >= 7) {
                const name = cells[0].querySelector('.font-medium')?.innerText || '';
                const username = cells[0].querySelector('.text-xs')?.innerText.replace('@', '') || '';
                const contact = cells[1].innerText.trim().split('\n').map(l => l.trim()).filter(l => l);
                const email = contact.find(l => l.includes('@')) || '';
                const phone = contact.find(l => l.match(/[\d\-+()]/)) || '';
                const position = cells[2].innerText.trim();
                const status = cells[4].innerText.trim();
                const visits = cells[3].querySelector('.flex.items-center.justify-between span:last-child')?.innerText || '0';
                const joined = cells[5].innerText.trim();
                
                csv.push([name, username, email, phone, position, status, visits, joined]);
            }
        }
    });
    
    const csvContent = csv.map(row => row.map(cell => `"${cell.replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'staff_export.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('staffModal');
    if (event.target === modal) closeModal();
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    // Add password strength indicator for new staff
    const passwordInput = document.getElementById('password');
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            const strength = this.value.length;
            if (strength >= 6 && strength < 8) {
                this.style.borderColor = '#f59e0b';
            } else if (strength >= 8) {
                this.style.borderColor = '#10b981';
            } else {
                this.style.borderColor = '#ef4444';
            }
        });
    }
});
</script>

<?php include '../includes/footer.php'; ?>