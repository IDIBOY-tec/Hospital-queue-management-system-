<?php

// Main router / redirect
require_once '../includes/auth.php';

if (is_logged_in()) {
    if (is_admin()) {
        header('Location: /admin_dashboard.php');
    } else {
        header('Location: /staff_dashboard.php');
    }
    exit;
} else {
    header('Location: /login.php');
    exit;
}

