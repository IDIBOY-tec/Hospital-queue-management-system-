<?php
/**
 * register_admin.php
 * 
 * Professional Admin Registration Page
 * Features: Full-page background image, gradient overlay, circular avatar,
 * responsive design, and advanced form validation with visual feedback.
 */

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/settings.php';

$page_title = 'Create Admin Account - ' . ($app_name ?? 'Hospital Queue System');

// Uncomment the line below if you want to restrict registration after first admin is created
/*
if (admin_exists($mysqli)) {
    header('Location: /login.php');
    exit;
}
*/

$error = '';
$success = '';
$form_data = ['full_name' => '', 'username' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');

    // Store form data for repopulation
    $form_data = ['full_name' => $full_name, 'username' => $username, 'email' => $email];

    // Validation
    $errors = [];
    if (!$username || !$password || !$full_name) {
        $errors[] = 'Full Name, Username, and Password are required.';
    }
    if ($password !== $password_confirm) {
        $errors[] = 'Passwords do not match.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    }
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }

    if (empty($errors)) {
        $existing = get_user_by_username($mysqli, $username);
        if ($existing) {
            $errors[] = 'Username already exists. Please choose a different username.';
        } else {
            $password_hash = hash_password($password);
            $stmt = mysqli_prepare($mysqli, "INSERT INTO users (username, password_hash, full_name, role, email) VALUES (?, ?, ?, 'admin', ?)");
            mysqli_stmt_bind_param($stmt, 'ssss', $username, $password_hash, $full_name, $email);

            if (mysqli_stmt_execute($stmt)) {
                $success = 'Admin account created successfully! Redirecting to login...';
                $user_id = mysqli_insert_id($mysqli);
                // Redirect after a short delay for user feedback
                header("Refresh: 2; url=/login.php");
            } else {
                $errors[] = 'Database error: Unable to create account. Please try again.';
                error_log("Admin registration failed: " . mysqli_error($mysqli));
            }
        }
    }

    if (!empty($errors)) {
        $error = implode('<br>', $errors);
    }
}

// Get colors from header.php variables (these are set in settings.php via $sidebar_bg_color etc.)
// We'll create a professional gradient using the sidebar color if available, or a default medical gradient
$primary_color = isset($sidebar_bg_color) && !empty($sidebar_bg_color) ? $sidebar_bg_color : '#2c3e50';
// Create a complementary gradient color (lighter version)
$secondary_color = adjust_brightness($primary_color, 30);
$gradient = "linear-gradient(135deg, {$primary_color} 0%, {$secondary_color} 100%)";

// Helper function to adjust color brightness (simple hex adjustment)
function adjust_brightness($hex, $percent) {
    $hex = ltrim($hex, '#');
    if (strlen($hex) == 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    $r = hexdec(substr($hex,0,2));
    $g = hexdec(substr($hex,2,2));
    $b = hexdec(substr($hex,4,2));
    $r = max(0, min(255, $r + $percent));
    $g = max(0, min(255, $g + $percent));
    $b = max(0, min(255, $b + $percent));
    return sprintf("#%02x%02x%02x", $r, $g, $b);
}
?>
<?php include 'files/login_header.php'; ?>

<!-- Custom CSS for this page -->
<style>
    /* Full-page background with image and gradient overlay */
    .register-hero {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('../images/logo.jpg') center center/cover no-repeat;
        z-index: -2;
    }
    
    .register-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: <?php echo $gradient; ?>;
        opacity: 0.88;
        z-index: -1;
    }
    
    /* Modern glass-morphism card effect */
    .glass-card {
        background: rgba(255, 255, 255, 0.96);
        backdrop-filter: blur(2px);
        border-radius: 2rem;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .glass-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.3);
    }
    
    /* Circular avatar with icon */
    .avatar-circle {
        width: 100px;
        height: 100px;
        background: <?php echo $primary_color; ?>;
        margin: 0 auto 1.5rem;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.2);
        border: 4px solid white;
        transition: all 0.3s ease;
    }
    
    .avatar-circle svg {
        width: 55px;
        height: 55px;
        stroke: white;
        fill: white;
    }
    
    /* Form input styling */
    .form-input {
        width: 100%;
        padding: 0.875rem 1rem;
        border: 1.5px solid #e2e8f0;
        border-radius: 1rem;
        transition: all 0.2s ease;
        background-color: #f8fafc;
        font-size: 0.95rem;
    }
    
    .form-input:focus {
        outline: none;
        border-color: <?php echo $primary_color; ?>;
        box-shadow: 0 0 0 3px rgba(<?php echo hexdec(substr($primary_color,1,2)); ?>, <?php echo hexdec(substr($primary_color,3,2)); ?>, <?php echo hexdec(substr($primary_color,5,2)); ?>, 0.1);
        background-color: white;
    }
    
    .form-label {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: 600;
        color: #1e293b;
        font-size: 0.9rem;
        letter-spacing: 0.025em;
    }
    
    .btn-primary {
        background: <?php echo $gradient; ?>;
        color: white;
        font-weight: 700;
        padding: 0.875rem 1.5rem;
        border-radius: 1.5rem;
        transition: all 0.2s ease;
        border: none;
        cursor: pointer;
        width: 100%;
        font-size: 1rem;
        letter-spacing: 0.025em;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }
    
    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.2);
        filter: brightness(1.05);
    }
    
    .btn-primary:active {
        transform: translateY(0);
    }
    
    /* Alert styling */
    .alert-error {
        background-color: #fee2e2;
        border-left: 4px solid #dc2626;
        color: #991b1b;
        padding: 1rem;
        border-radius: 1rem;
        margin-bottom: 1.5rem;
        font-size: 0.9rem;
    }
    
    .alert-success {
        background-color: #e0f2fe;
        border-left: 4px solid #0284c7;
        color: #075985;
        padding: 1rem;
        border-radius: 1rem;
        margin-bottom: 1.5rem;
        font-size: 0.9rem;
    }
    
    /* Responsive adjustments */
    @media (max-width: 640px) {
        .glass-card {
            margin: 1rem;
            padding: 1.5rem !important;
        }
        
        .avatar-circle {
            width: 80px;
            height: 80px;
        }
        
        .avatar-circle svg {
            width: 40px;
            height: 40px;
        }
        
        .form-input {
            padding: 0.75rem;
            font-size: 0.9rem;
        }
        
        h1 {
            font-size: 1.75rem !important;
        }
    }
    
    /* Password strength indicator (optional) */
    .password-strength {
        height: 4px;
        margin-top: 0.5rem;
        border-radius: 2px;
        transition: all 0.2s;
    }
    
    /* Animation for success */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in-up {
        animation: fadeInUp 0.5s ease-out;
    }
</style>

<!-- Background layers -->
<div class="register-hero"></div>
<div class="register-overlay"></div>

<!-- Main content - centered with flex -->
<div class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 relative z-10">
    <div class="w-full max-w-md fade-in-up">
        <div class="glass-card p-8 md:p-10">
            <!-- Circular avatar with medical symbol -->
            <div class="avatar-circle">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 11v6m3-3H9" />
                </svg>
            </div>
            
            <h1 class="text-3xl font-extrabold text-center text-gray-900 mb-2">
                Create Admin Account
            </h1>
            <p class="text-center text-gray-500 mb-6 text-sm">
                Set up the primary administrator for the system
            </p>
            
            <?php if ($error): ?>
                <div class="alert-error">
                    <div class="flex items-start">
                        <svg class="w-5 h-5 mr-2 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                        </svg>
                        <div><?php echo $error; ?></div>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert-success">
                    <div class="flex items-center">
                        <svg class="w-5 h-5 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                        </svg>
                        <div><?php echo $success; ?></div>
                    </div>
                </div>
            <?php else: ?>
                <form method="POST" class="space-y-5" id="registerForm">
                    <!-- Full Name -->
                    <div>
                        <label for="full_name" class="form-label">Full Name *</label>
                        <input type="text" 
                               name="full_name" 
                               id="full_name"
                               required 
                               value="<?php echo htmlspecialchars($form_data['full_name']); ?>"
                               class="form-input"
                               placeholder="Dr. John Doe">
                    </div>
                    
                    <!-- Username -->
                    <div>
                        <label for="username" class="form-label">Username *</label>
                        <input type="text" 
                               name="username" 
                               id="username"
                               required 
                               value="<?php echo htmlspecialchars($form_data['username']); ?>"
                               class="form-input"
                               placeholder="johndoe">
                        <p class="text-xs text-gray-500 mt-1">Used for login (minimum 3 characters)</p>
                    </div>
                    
                    <!-- Email -->
                    <div>
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" 
                               name="email" 
                               id="email"
                               value="<?php echo htmlspecialchars($form_data['email']); ?>"
                               class="form-input"
                               placeholder="admin@hospital.com">
                    </div>
                    
                    <!-- Password -->
                    <div>
                        <label for="password" class="form-label">Password *</label>
                        <input type="password" 
                               name="password" 
                               id="password"
                               required 
                               class="form-input"
                               placeholder="••••••••">
                        <div class="password-strength" id="passwordStrength"></div>
                        <p class="text-xs text-gray-500 mt-1">Minimum 6 characters</p>
                    </div>
                    
                    <!-- Confirm Password -->
                    <div>
                        <label for="password_confirm" class="form-label">Confirm Password *</label>
                        <input type="password" 
                               name="password_confirm" 
                               id="password_confirm"
                               required 
                               class="form-input"
                               placeholder="••••••••">
                        <div id="passwordMatch" class="text-xs mt-1"></div>
                    </div>
                    
                    <!-- Submit Button -->
                    <button type="submit" class="btn-primary mt-2">
                        <span class="flex items-center justify-center">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                            </svg>
                            Create Admin Account
                        </span>
                    </button>
                </form>
                
                <!-- Additional info -->
                <div class="mt-6 text-center text-xs text-gray-500">
                    <p>This account will have full administrative privileges.</p>
                    <p class="mt-1">You'll be redirected to the login page after successful registration.</p>
                    
                <p class="mt-1"><a href="login.php">Back to login</a></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- JavaScript for password strength and match validation -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const passwordInput = document.getElementById('password');
        const confirmInput = document.getElementById('password_confirm');
        const strengthDiv = document.getElementById('passwordStrength');
        const matchDiv = document.getElementById('passwordMatch');
        
        // Password strength checker
        function checkStrength(password) {
            let strength = 0;
            if (password.length >= 6) strength++;
            if (password.match(/[a-z]+/)) strength++;
            if (password.match(/[A-Z]+/)) strength++;
            if (password.match(/[0-9]+/)) strength++;
            if (password.match(/[$@#&!]+/)) strength++;
            
            let strengthText = '';
            let strengthColor = '';
            let strengthWidth = '0%';
            
            switch(strength) {
                case 0:
                case 1:
                    strengthText = 'Weak';
                    strengthColor = '#ef4444';
                    strengthWidth = '25%';
                    break;
                case 2:
                    strengthText = 'Fair';
                    strengthColor = '#f59e0b';
                    strengthWidth = '50%';
                    break;
                case 3:
                    strengthText = 'Good';
                    strengthColor = '#10b981';
                    strengthWidth = '75%';
                    break;
                case 4:
                case 5:
                    strengthText = 'Strong';
                    strengthColor = '#059669';
                    strengthWidth = '100%';
                    break;
            }
            
            if (password.length === 0) {
                strengthDiv.style.display = 'none';
                return;
            }
            
            strengthDiv.style.display = 'block';
            strengthDiv.style.background = strengthColor;
            strengthDiv.style.width = strengthWidth;
            strengthDiv.innerHTML = `<span style="color: ${strengthColor}; font-size: 10px; display: block; margin-top: 4px;">${strengthText}</span>`;
        }
        
        // Check password match
        function checkMatch() {
            const password = passwordInput.value;
            const confirm = confirmInput.value;
            
            if (confirm.length === 0) {
                matchDiv.innerHTML = '';
                return;
            }
            
            if (password === confirm) {
                matchDiv.innerHTML = '<span class="text-green-600">✓ Passwords match</span>';
            } else {
                matchDiv.innerHTML = '<span class="text-red-500">✗ Passwords do not match</span>';
            }
        }
        
        passwordInput.addEventListener('input', function() {
            checkStrength(this.value);
            if (confirmInput.value.length > 0) checkMatch();
        });
        
        confirmInput.addEventListener('input', checkMatch);
        
        // Form submission validation enhancement
        const form = document.getElementById('registerForm');
        form.addEventListener('submit', function(e) {
            const password = passwordInput.value;
            const confirm = confirmInput.value;
            
            if (password !== confirm) {
                e.preventDefault();
                matchDiv.innerHTML = '<span class="text-red-500 font-medium">✗ Passwords do not match. Please correct.</span>';
                confirmInput.focus();
                return false;
            }
            
            if (password.length < 6) {
                e.preventDefault();
                alert('Password must be at least 6 characters long.');
                passwordInput.focus();
                return false;
            }
            
            return true;
        });
    });
</script>

<?php include '../includes/footer.php'; ?>