<?php
// Header template - include at top of each page after auth/settings checks
if (!isset($page_title)) $page_title = 'Hospital Queue System';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Language" content="en">
    <meta name="google" content="notranslate">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title>
    
    <link rel="icon" type="image/jpeg" href="images/logo.jpg">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Chart.js - Make sure this loads before any chart scripts -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    
    <!-- Additional library for better chart performance -->
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0/dist/chartjs-plugin-datalabels.min.js"></script>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        :root {
            --site-font: <?php echo htmlspecialchars($font_family ?? 'Inter, system-ui, -apple-system, sans-serif'); ?>;
            --sidebar-bg: <?php echo htmlspecialchars($sidebar_bg_color ?? '#0f172a'); ?>;
            --sidebar-hover: <?php 
                $color = $sidebar_bg_color ?? '#0f172a';
                $r = hexdec(substr($color, 1, 2));
                $g = hexdec(substr($color, 3, 2));
                $b = hexdec(substr($color, 5, 2));
                echo sprintf("#%02x%02x%02x", max(0, $r+20), max(0, $g+20), max(0, $b+20));
            ?>;
            --sidebar-active: <?php 
                echo sprintf("#%02x%02x%02x", min(255, $r+40), min(255, $g+40), min(255, $b+40));
            ?>;
        }
        
        body {
            font-family: var(--site-font);
            background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%);
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        /* ========== SIDEBAR STYLES ========== */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 280px;
            height: 100vh;
            background: var(--sidebar-bg);
            color: #e2e8f0;
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 1000;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
            overflow-x: hidden;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
        }
        
        /* Custom scrollbar for sidebar */
        .sidebar::-webkit-scrollbar {
            width: 5px;
        }
        
        .sidebar::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.05);
        }
        
        .sidebar::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
        }
        
        /* Sidebar Header */
        .sidebar-header {
            padding: 1.75rem 1.5rem;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 0.5rem;
        }
        
        .sidebar-logo {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 1rem;
            border: 3px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }
        
        .sidebar-title {
            font-size: 1.1rem;
            font-weight: 600;
            word-break: break-word;
            line-height: 1.3;
            color: white;
        }
        
        .sidebar-subtitle {
            font-size: 0.7rem;
            opacity: 0.6;
            margin-top: 0.25rem;
        }
        
        /* Navigation Section */
        .sidebar-nav {
            flex: 1;
            padding: 1rem 0.75rem;
            overflow-y: auto;
        }
        
        .nav-section {
            margin-bottom: 1.5rem;
        }
        
        .nav-section-title {
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: rgba(255, 255, 255, 0.4);
            padding: 0.5rem 1rem;
            margin-bottom: 0.5rem;
        }
        
        .sidebar-nav a {
            display: flex;
            align-items: center;
            gap: 0.875rem;
            padding: 0.75rem 1rem;
            margin-bottom: 0.25rem;
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            border-radius: 0.75rem;
            transition: all 0.2s ease;
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .sidebar-nav a i {
            width: 1.5rem;
            font-size: 1.1rem;
            text-align: center;
        }
        
        .sidebar-nav a:hover {
            background: var(--sidebar-hover);
            color: white;
            transform: translateX(5px);
        }
        
        .sidebar-nav a.active {
            background: var(--sidebar-active);
            color: white;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        
        /* Sidebar Footer */
        .sidebar-footer {
            padding: 1rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            margin-top: auto;
        }
        
        .sidebar-footer a {
            display: flex;
            align-items: center;
            gap: 0.875rem;
            padding: 0.75rem 1rem;
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            border-radius: 0.75rem;
            transition: all 0.2s ease;
        }
        
        .sidebar-footer a:hover {
            background: rgba(239, 68, 68, 0.2);
            color: #f87171;
        }
        
        /* Main Content */
        .main-content {
            margin-left: 280px;
            min-height: 100vh;
            transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        /* Mobile Menu Button */
        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 1rem;
            left: 1rem;
            z-index: 1100;
            background: var(--sidebar-bg);
            color: white;
            border: none;
            border-radius: 0.75rem;
            padding: 0.75rem;
            cursor: pointer;
            font-size: 1.25rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            transition: all 0.2s;
        }
        
        .mobile-menu-btn:hover {
            transform: scale(1.05);
        }
        
        /* Sidebar Overlay for Mobile */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.6);
            z-index: 999;
            backdrop-filter: blur(4px);
            transition: opacity 0.3s;
        }
        
        /* Responsive Design */
        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            .sidebar-overlay.active {
                display: block;
            }
        }
        
        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .fade-in-up {
            animation: fadeInUp 0.6s ease-out;
        }
        
        /* Card Styles */
        .stat-card {
            background: white;
            border-radius: 1.25rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 30px -12px rgba(0, 0, 0, 0.15);
        }
        
        /* Chart Card */
        .chart-card {
            background: white;
            border-radius: 1.25rem;
            transition: all 0.3s;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .chart-card:hover {
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
        }
        
        /* AI Insight Card */
        .ai-insight {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 1rem;
            transition: all 0.3s;
        }
        
        .ai-insight:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 30px -10px rgba(102, 126, 234, 0.4);
        }
        
        /* Loading Spinner */
        .spinner {
            border: 3px solid rgba(0, 0, 0, 0.1);
            border-radius: 50%;
            border-top: 3px solid #667eea;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Badge Styles */
        .badge-success {
            background: #10b981;
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 2rem;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .badge-warning {
            background: #f59e0b;
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 2rem;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .badge-danger {
            background: #ef4444;
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 2rem;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .badge-info {
            background: #3b82f6;
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 2rem;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
        
        /* Ensure canvas elements have proper dimensions */
        canvas {
            max-width: 100%;
            height: auto;
        }
        
        /* Chart container to maintain aspect ratio */
        .chart-container {
            position: relative;
            width: 100%;
            min-height: 300px;
        }
    </style>

    <script>
        // Global chart store to prevent memory leaks
        window.charts = {};
        
        // Helper function to safely destroy existing chart
        function destroyChart(chartId) {
            if (window.charts[chartId]) {
                window.charts[chartId].destroy();
                window.charts[chartId] = null;
            }
        }
        
        // Helper function to create chart with error handling
        function createChart(canvasId, type, data, options = {}) {
            const canvas = document.getElementById(canvasId);
            if (!canvas) {
                console.warn(`Canvas element with id '${canvasId}' not found`);
                return null;
            }
            
            try {
                destroyChart(canvasId);
                const ctx = canvas.getContext('2d');
                window.charts[canvasId] = new Chart(ctx, {
                    type: type,
                    data: data,
                    options: {
                        responsive: true,
                        maintainAspectRatio: true,
                        ...options
                    }
                });
                return window.charts[canvasId];
            } catch (error) {
                console.error(`Error creating chart '${canvasId}':`, error);
                return null;
            }
        }
        
        // Sidebar toggle functions
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            if (sidebar) sidebar.classList.toggle('open');
            if (overlay) overlay.classList.toggle('active');
        }
        
        function closeSidebar() {
            if (window.innerWidth <= 1024) {
                const sidebar = document.getElementById('sidebar');
                const overlay = document.getElementById('sidebar-overlay');
                if (sidebar) sidebar.classList.remove('open');
                if (overlay) overlay.classList.remove('active');
            }
        }
        
        // Wait for DOM and Chart.js to be ready
        document.addEventListener('DOMContentLoaded', function() {
            // Check if Chart.js loaded properly
            if (typeof Chart === 'undefined') {
                console.error('Chart.js failed to load. Please check your internet connection.');
                // Show error message on page
                const errorDiv = document.createElement('div');
                errorDiv.className = 'fixed top-4 right-4 bg-red-500 text-white px-4 py-2 rounded shadow-lg z-50';
                errorDiv.innerHTML = '<i class="fas fa-exclamation-circle mr-2"></i>Chart.js failed to load. Charts will not display.';
                document.body.appendChild(errorDiv);
                setTimeout(() => errorDiv.remove(), 5000);
            } else {
                console.log('Chart.js loaded successfully, version:', Chart.version);
            }
            
            // Sidebar overlay click handler
            const overlay = document.getElementById('sidebar-overlay');
            if (overlay) {
                overlay.addEventListener('click', closeSidebar);
            }
            
            // Set active class based on current URL
            const currentPath = window.location.pathname;
            const navLinks = document.querySelectorAll('.sidebar-nav a');
            navLinks.forEach(link => {
                const href = link.getAttribute('href');
                if (href && currentPath === href) {
                    link.classList.add('active');
                } else if (href && currentPath.includes(href) && href !== '/' && href !== '/admin_dashboard.php') {
                    link.classList.add('active');
                } else if (currentPath === '/' || currentPath === '/admin_dashboard.php') {
                    if (href === '/admin_dashboard.php') link.classList.add('active');
                }
            });
            
            // Handle window resize - preserve chart responsiveness
            let resizeTimeout;
            window.addEventListener('resize', function() {
                clearTimeout(resizeTimeout);
                resizeTimeout = setTimeout(function() {
                    // Update all charts on resize
                    Object.values(window.charts).forEach(chart => {
                        if (chart && chart.resize) chart.resize();
                    });
                }, 250);
            });
            
            // Handle window resize for sidebar
            window.addEventListener('resize', function() {
                if (window.innerWidth > 1024) {
                    const sidebar = document.getElementById('sidebar');
                    const overlay = document.getElementById('sidebar-overlay');
                    if (sidebar) sidebar.classList.remove('open');
                    if (overlay) overlay.classList.remove('active');
                }
            });
            
            // Dispatch event to notify that header is ready and Chart.js is loaded
            const event = new CustomEvent('headerReady', { detail: { chartJsLoaded: typeof Chart !== 'undefined' } });
            document.dispatchEvent(event);
        });
        
        // Fallback for when Chart.js takes longer to load
        if (typeof Chart === 'undefined') {
            window.addEventListener('load', function() {
                if (typeof Chart !== 'undefined') {
                    console.log('Chart.js loaded after window load');
                    const event = new CustomEvent('headerReady', { detail: { chartJsLoaded: true } });
                    document.dispatchEvent(event);
                }
            });
        }
    </script>
</head>
<body>

<!-- Mobile Menu Button -->
<button class="mobile-menu-btn" onclick="toggleSidebar()">
    <i class="fas fa-bars"></i>
</button>

<!-- Sidebar Overlay -->
<div id="sidebar-overlay" class="sidebar-overlay"></div>