<?php
/**
 * login.php
 * 
 * Professional Login Page
 * Features: Full-page background image, gradient overlay, circular lock icon,
 * responsive design, modern glass-morphism card, and smooth animations.
 */

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/settings.php';

$page_title = 'Login - ' . ($app_name ?? 'Hospital Queue System');
$login_error = '';
$username_value = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $username_value = htmlspecialchars($username);

    if ($username && $password) {
        $user = get_user_by_username($mysqli, $username);

        if ($user && $user['is_active'] && verify_password($password, $user['password_hash'])) {
            login_user($user['id'], $user['username'], $user['role']);

            $stmt = mysqli_prepare($mysqli, "UPDATE users SET last_login = NOW() WHERE id = ?");
            mysqli_stmt_bind_param($stmt, 'i', $user['id']);
            mysqli_stmt_execute($stmt);

            header('Location: /index.php');
            exit;
        } else {
            $login_error = 'Invalid username or password. Please try again.';
        }
    } else {
        $login_error = 'Please enter both username and password.';
    }
}

$admin_exists = admin_exists($mysqli);

// Get colors from settings for gradient (same as register_admin.php)
$primary_color = isset($sidebar_bg_color) && !empty($sidebar_bg_color) ? $sidebar_bg_color : '#2c3e50';
$secondary_color = adjust_brightness($primary_color, 30);
$gradient = "linear-gradient(135deg, {$primary_color} 0%, {$secondary_color} 100%)";

// Helper function to adjust color brightness
function adjust_brightness($hex, $percent) {
    $hex = ltrim($hex, '#');
    if (strlen($hex) == 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    $r = hexdec(substr($hex,0,2));
    $g = hexdec(substr($hex,2,2));
    $b = hexdec(substr($hex,4,2));
    $r = max(0, min(255, $r + $percent));
    $g = max(0, min(255, $g + $percent));
    $b = max(0, min(255, $b + $percent));
    return sprintf("#%02x%02x%02x", $r, $g, $b);
}
?>
<?php include 'files/login_header.php'; ?>

<!-- Custom CSS for this page (matching register_admin.php style) -->
<style>
    /* Full-page background with image and gradient overlay */
    .login-hero {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('../images/logo.jpg') center center/cover no-repeat;
        z-index: -2;
    }
    
    .login-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: <?php echo $gradient; ?>;
        opacity: 0.88;
        z-index: -1;
    }
    
    /* Modern glass-morphism card effect */
    .glass-card {
        background: rgba(255, 255, 255, 0.96);
        backdrop-filter: blur(2px);
        border-radius: 2rem;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .glass-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.3);
    }
    
    /* Circular lock icon */
    .avatar-circle {
        width: 100px;
        height: 100px;
        background: <?php echo $primary_color; ?>;
        margin: 0 auto 1.5rem;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.2);
        border: 4px solid white;
        transition: all 0.3s ease;
    }
    
    .avatar-circle svg {
        width: 55px;
        height: 55px;
        stroke: white;
        fill: white;
    }
    
    /* Form input styling */
    .form-input {
        width: 100%;
        padding: 0.875rem 1rem;
        border: 1.5px solid #e2e8f0;
        border-radius: 1rem;
        transition: all 0.2s ease;
        background-color: #f8fafc;
        font-size: 0.95rem;
    }
    
    .form-input:focus {
        outline: none;
        border-color: <?php echo $primary_color; ?>;
        box-shadow: 0 0 0 3px rgba(<?php echo hexdec(substr($primary_color,1,2)); ?>, <?php echo hexdec(substr($primary_color,3,2)); ?>, <?php echo hexdec(substr($primary_color,5,2)); ?>, 0.1);
        background-color: white;
    }
    
    .form-label {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: 600;
        color: #1e293b;
        font-size: 0.9rem;
        letter-spacing: 0.025em;
    }
    
    .btn-login {
        background: <?php echo $gradient; ?>;
        color: white;
        font-weight: 700;
        padding: 0.875rem 1.5rem;
        border-radius: 1.5rem;
        transition: all 0.2s ease;
        border: none;
        cursor: pointer;
        width: 100%;
        font-size: 1rem;
        letter-spacing: 0.025em;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }
    
    .btn-login:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.2);
        filter: brightness(1.05);
    }
    
    .btn-login:active {
        transform: translateY(0);
    }
    
    .btn-register {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        color: white;
        font-weight: 600;
        padding: 0.75rem 1.25rem;
        border-radius: 1.5rem;
        transition: all 0.2s ease;
        border: none;
        cursor: pointer;
        width: 100%;
        font-size: 0.9rem;
        letter-spacing: 0.025em;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
    }
    
    .btn-register:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 12px -3px rgba(0, 0, 0, 0.15);
        filter: brightness(1.05);
    }
    
    /* Alert styling */
    .alert-error {
        background-color: #fee2e2;
        border-left: 4px solid #dc2626;
        color: #991b1b;
        padding: 1rem;
        border-radius: 1rem;
        margin-bottom: 1.5rem;
        font-size: 0.9rem;
    }
    
    /* Responsive adjustments */
    @media (max-width: 640px) {
        .glass-card {
            margin: 1rem;
            padding: 1.5rem !important;
        }
        
        .avatar-circle {
            width: 80px;
            height: 80px;
        }
        
        .avatar-circle svg {
            width: 40px;
            height: 40px;
        }
        
        .form-input {
            padding: 0.75rem;
            font-size: 0.9rem;
        }
        
        h1 {
            font-size: 1.75rem !important;
        }
    }
    
    /* Animation */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in-up {
        animation: fadeInUp 0.5s ease-out;
    }
    
    /* Remember me checkbox styling */
    .checkbox-custom {
        width: 1rem;
        height: 1rem;
        border: 1.5px solid #cbd5e1;
        border-radius: 0.25rem;
        cursor: pointer;
        accent-color: <?php echo $primary_color; ?>;
    }
    
    .checkbox-label {
        font-size: 0.875rem;
        color: #4b5563;
        cursor: pointer;
    }
    
    /* Divider */
    .divider {
        display: flex;
        align-items: center;
        text-align: center;
        color: #9ca3af;
        font-size: 0.75rem;
        margin: 1.5rem 0;
    }
    
    .divider::before,
    .divider::after {
        content: '';
        flex: 1;
        border-bottom: 1px solid #e5e7eb;
    }
    
    .divider::before {
        margin-right: 1rem;
    }
    
    .divider::after {
        margin-left: 1rem;
    }
</style>

<!-- Background layers -->
<div class="login-hero"></div>
<div class="login-overlay"></div>

<!-- Main content - centered with flex -->
<div class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 relative z-10">
    <div class="w-full max-w-md fade-in-up">
        <div class="glass-card p-8 md:p-10">
            <!-- Circular lock icon -->
            <div class="avatar-circle">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6-4h12a2 2 0 012 2v6a2 2 0 01-2 2H6a2 2 0 01-2-2v-6a2 2 0 012-2zm10-4V8a4 4 0 00-8 0v3h8z" />
                </svg>
            </div>
            
            <h1 class="text-3xl font-extrabold text-center text-gray-900 mb-2">
                <?php echo htmlspecialchars($app_name ?? 'Hospital Queue System'); ?>
            </h1>
            <p class="text-center text-gray-500 mb-6 text-sm">
                Queue Management System
            </p>
            
            <?php if ($login_error): ?>
                <div class="alert-error">
                    <div class="flex items-start">
                        <svg class="w-5 h-5 mr-2 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                        </svg>
                        <div><?php echo htmlspecialchars($login_error); ?></div>
                    </div>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="space-y-5" id="loginForm">
                <!-- Username Field -->
                <div>
                    <label for="username" class="form-label">
                        <span class="flex items-center gap-2">
                            <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                            Username
                        </span>
                    </label>
                    <input type="text" 
                           name="username" 
                           id="username"
                           required 
                           class="form-input"
                           placeholder="Enter your username"
                           value="<?php echo $username_value; ?>"
                           autofocus>
                </div>
                
                <!-- Password Field -->
                <div>
                    <label for="password" class="form-label">
                        <span class="flex items-center gap-2">
                            <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6-4h12a2 2 0 012 2v6a2 2 0 01-2 2H6a2 2 0 01-2-2v-6a2 2 0 012-2zm10-4V8a4 4 0 00-8 0v3h8z" />
                            </svg>
                            Password
                        </span>
                    </label>
                    <input type="password" 
                           name="password" 
                           id="password"
                           required 
                           class="form-input"
                           placeholder="••••••••">
                </div>
                
                <!-- Remember Me & Forgot Password Row -->
                <div class="flex items-center justify-between">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="remember_me" id="remember_me" class="checkbox-custom">
                        <span class="checkbox-label">Remember me</span>
                    </label>
                    <a href="#" class="text-sm text-gray-500 hover:text-gray-700 transition-colors">
                        Forgot password?
                    </a>
                </div>
                
                <!-- Login Button -->
                <button type="submit" class="btn-login mt-2">
                    <span class="flex items-center justify-center gap-2">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                        </svg>
                        Sign In
                    </span>
                </button>
            </form>
            
            <!-- Divider -->
            <div class="divider">
                <span>New to the system?</span>
            </div>
            
            <!-- Admin Registration Button -->
            <div>
                <a href="/register_admin.php" class="btn-register">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                    </svg>
                    Create Admin Account
                </a>
            </div>
            
            <!-- Additional Info -->
            <div class="mt-6 text-center text-xs text-gray-400">
                <p>Secure login • Role-based access control</p>
                <?php if (!$admin_exists): ?>
                    <p class="mt-1 text-amber-600">⚠️ No admin account exists. Please register first.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for enhanced UX -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Remember me functionality (store username in localStorage)
        const rememberCheckbox = document.getElementById('remember_me');
        const usernameInput = document.getElementById('username');
        
        // Check if there's a stored username
        const storedUsername = localStorage.getItem('saved_username');
        if (storedUsername) {
            usernameInput.value = storedUsername;
            if (rememberCheckbox) rememberCheckbox.checked = true;
        }
        
        // Save username when form is submitted with remember me checked
        const loginForm = document.getElementById('loginForm');
        loginForm.addEventListener('submit', function(e) {
            if (rememberCheckbox && rememberCheckbox.checked) {
                localStorage.setItem('saved_username', usernameInput.value);
            } else {
                localStorage.removeItem('saved_username');
            }
        });
        
        // Auto-focus on username field
        usernameInput.focus();
        
        // Optional: Add Enter key submission enhancement
        const passwordInput = document.getElementById('password');
        passwordInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                loginForm.dispatchEvent(new Event('submit'));
            }
        });
        
        // Simple password visibility toggle (optional enhancement)
        // This adds an eye icon to toggle password visibility
        const passwordField = document.getElementById('password');
        const togglePassword = document.createElement('button');
        togglePassword.type = 'button';
        togglePassword.innerHTML = `
            <svg class="w-5 h-5 text-gray-400 hover:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
            </svg>
        `;
        togglePassword.className = 'absolute right-3 top-1/2 transform -translate-y-1/2 focus:outline-none';
        togglePassword.style.background = 'transparent';
        togglePassword.style.border = 'none';
        togglePassword.style.cursor = 'pointer';
        
        const passwordContainer = passwordField.parentElement;
        passwordContainer.style.position = 'relative';
        passwordField.style.paddingRight = '2.5rem';
        passwordContainer.appendChild(togglePassword);
        
        let passwordVisible = false;
        togglePassword.addEventListener('click', function() {
            passwordVisible = !passwordVisible;
            passwordField.type = passwordVisible ? 'text' : 'password';
            togglePassword.innerHTML = passwordVisible ? `
                <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.542-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.542 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                </svg>
            ` : `
                <svg class="w-5 h-5 text-gray-400 hover:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
            `;
        });
    });
</script>

<?php include '../includes/footer.php'; ?>