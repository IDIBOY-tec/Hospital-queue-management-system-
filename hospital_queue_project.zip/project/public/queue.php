<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/settings.php';

require_staff();

$page_title = 'Queue Management - ' . ($app_name ?? 'Hospital Queue System');

// Get queue statistics - FIXED COUNTS
$today = date('Y-m-d');

// Waiting count (patients with status waiting created today)
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE status = 'waiting' AND DATE(created_at) = '$today'");
$waiting_count = mysqli_fetch_assoc($result)['cnt'] ?? 0;

// Called count (patients with status called created today)
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE status = 'called' AND DATE(created_at) = '$today'");
$called_count = mysqli_fetch_assoc($result)['cnt'] ?? 0;

// Arrived count (patients with status arrived created today)
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE status = 'arrived' AND DATE(created_at) = '$today'");
$arrived_count = mysqli_fetch_assoc($result)['cnt'] ?? 0;

// Visited count (patients with status visited and visited_at is today)
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE status = 'visited' AND DATE(visited_at) = '$today'");
$visited_count = mysqli_fetch_assoc($result)['cnt'] ?? 0;

// Served count (patients with status served and served_at is today)
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE status = 'served' AND DATE(served_at) = '$today'");
$served_count = mysqli_fetch_assoc($result)['cnt'] ?? 0;

// Total today
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE DATE(created_at) = '$today'");
$total_today = mysqli_fetch_assoc($result)['cnt'] ?? 0;

// Get medicines for dispensing
$medicines = [];
$med_result = mysqli_query($mysqli, "SELECT id, name, quantity, unit FROM medicines WHERE quantity > 0 ORDER BY name");
while ($med = mysqli_fetch_assoc($med_result)) {
    $medicines[] = $med;
}
?>
<?php include '../includes/header.php'; ?>

<div class="main-content">
    <div class="p-4 md:p-8">
        <!-- Header -->
        <div class="mb-8 fade-in-up">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h1 class="text-3xl md:text-4xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                        Patient Queue Management
                    </h1>
                    <p class="text-gray-500 mt-2">Manage patient flow with multi-language voice announcements</p>
                </div>
                <div class="flex flex-wrap gap-3">
                    <button onclick="openPatientModal()" class="bg-gradient-to-r from-emerald-600 to-emerald-700 text-white px-5 py-2.5 rounded-xl font-medium hover:shadow-lg transition-all flex items-center gap-2">
                        <i class="fas fa-plus"></i> New Patient
                    </button>
                    <button onclick="openSearchModal()" class="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-5 py-2.5 rounded-xl font-medium hover:shadow-lg transition-all flex items-center gap-2">
                        <i class="fas fa-search"></i> Search
                    </button>
                    <select id="voiceLanguageSelect" class="bg-white border border-gray-300 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-400">
                        <option value="en">🇬🇧 English</option>
                        <option value="luganda">🇺🇬 Luganda</option>
                        <option value="swahili">🇰🇪 Kiswahili</option>
                        <option value="acholi">🇺🇬 Acholi</option>
                        <option value="runyankore">🇺🇬 Runyankore</option>
                        <option value="lusoga">🇺🇬 Lusoga</option>
                        <option value="ateso">🇺🇬 Ateso</option>
                        <option value="lugbara">🇺🇬 Lugbara</option>
                        <option value="rukiga">🇺🇬 Rukiga</option>
                        <option value="lango">🇺🇬 Lango</option>
                    </select>
                    <button id="btnVoiceToggle" class="bg-gradient-to-r from-green-600 to-green-700 text-white px-5 py-2.5 rounded-xl font-medium hover:shadow-lg transition-all flex items-center gap-2">
                        <i class="fas fa-volume-up"></i>
                        <span>Voice: ON</span>
                    </button>
                    <button onclick="refreshPage()" class="bg-gray-100 text-gray-700 px-5 py-2.5 rounded-xl font-medium hover:bg-gray-200 transition-all flex items-center gap-2">
                        <i class="fas fa-sync-alt"></i> Refresh
                    </button>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
            <div class="stat-card p-4 cursor-pointer" onclick="showTab('waiting')">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-xs font-medium">Waiting</p>
                        <p class="text-2xl font-bold text-blue-600 mt-1" id="waitingStat"><?php echo $waiting_count; ?></p>
                    </div>
                    <div class="bg-blue-100 rounded-xl p-2"><i class="fas fa-hourglass-half text-blue-600"></i></div>
                </div>
            </div>
            <div class="stat-card p-4 cursor-pointer" onclick="showTab('called')">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-xs font-medium">Called</p>
                        <p class="text-2xl font-bold text-yellow-600 mt-1" id="calledStat"><?php echo $called_count; ?></p>
                    </div>
                    <div class="bg-yellow-100 rounded-xl p-2"><i class="fas fa-bell text-yellow-600"></i></div>
                </div>
            </div>
            <div class="stat-card p-4 cursor-pointer" onclick="showTab('arrived')">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-xs font-medium">Arrived</p>
                        <p class="text-2xl font-bold text-green-600 mt-1" id="arrivedStat"><?php echo $arrived_count; ?></p>
                    </div>
                    <div class="bg-green-100 rounded-xl p-2"><i class="fas fa-check-circle text-green-600"></i></div>
                </div>
            </div>
            <div class="stat-card p-4 cursor-pointer" onclick="showTab('visited')">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-xs font-medium">Visited</p>
                        <p class="text-2xl font-bold text-purple-600 mt-1" id="visitedStat"><?php echo $visited_count; ?></p>
                    </div>
                    <div class="bg-purple-100 rounded-xl p-2"><i class="fas fa-stethoscope text-purple-600"></i></div>
                </div>
            </div>
            <div class="stat-card p-4 cursor-pointer" onclick="showTab('served')">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-xs font-medium">Served</p>
                        <p class="text-2xl font-bold text-indigo-600 mt-1" id="servedStat"><?php echo $served_count; ?></p>
                    </div>
                    <div class="bg-indigo-100 rounded-xl p-2"><i class="fas fa-check-double text-indigo-600"></i></div>
                </div>
            </div>
            <div class="stat-card p-4">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-xs font-medium">Today Total</p>
                        <p class="text-2xl font-bold text-gray-600 mt-1" id="totalStat"><?php echo $total_today; ?></p>
                    </div>
                    <div class="bg-gray-100 rounded-xl p-2"><i class="fas fa-calendar-day text-gray-600"></i></div>
                </div>
            </div>
        </div>

        <!-- Tab Navigation -->
        <div class="mb-6">
            <div class="flex flex-wrap gap-2 border-b border-gray-200">
                <button onclick="showTab('waiting')" class="tab-btn px-5 py-3 rounded-t-lg font-medium transition-all bg-blue-600 text-white" data-tab="waiting">
                    <i class="fas fa-hourglass-half mr-2"></i> Waiting
                    <span class="ml-2 px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs" id="waitingBadge"><?php echo $waiting_count; ?></span>
                </button>
                <button onclick="showTab('called')" class="tab-btn px-5 py-3 rounded-t-lg font-medium transition-all" data-tab="called">
                    <i class="fas fa-bell mr-2"></i> Called
                    <span class="ml-2 px-2 py-0.5 bg-yellow-100 text-yellow-700 rounded-full text-xs" id="calledBadge"><?php echo $called_count; ?></span>
                </button>
                <button onclick="showTab('arrived')" class="tab-btn px-5 py-3 rounded-t-lg font-medium transition-all" data-tab="arrived">
                    <i class="fas fa-check-circle mr-2"></i> Arrived
                    <span class="ml-2 px-2 py-0.5 bg-green-100 text-green-700 rounded-full text-xs" id="arrivedBadge"><?php echo $arrived_count; ?></span>
                </button>
                <button onclick="showTab('visited')" class="tab-btn px-5 py-3 rounded-t-lg font-medium transition-all" data-tab="visited">
                    <i class="fas fa-stethoscope mr-2"></i> Visited
                    <span class="ml-2 px-2 py-0.5 bg-purple-100 text-purple-700 rounded-full text-xs" id="visitedBadge"><?php echo $visited_count; ?></span>
                </button>
                <button onclick="showTab('served')" class="tab-btn px-5 py-3 rounded-t-lg font-medium transition-all" data-tab="served">
                    <i class="fas fa-check-double mr-2"></i> Served
                    <span class="ml-2 px-2 py-0.5 bg-indigo-100 text-indigo-700 rounded-full text-xs" id="servedBadge"><?php echo $served_count; ?></span>
                </button>
            </div>
        </div>

        <!-- Queue Table -->
        <div class="chart-card overflow-hidden">
            <div class="p-5 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <div class="bg-blue-600 rounded-xl p-2"><i class="fas fa-list-ul text-white text-lg"></i></div>
                        <div>
                            <h3 class="text-xl font-bold text-gray-800" id="queueTitle">Waiting Patients</h3>
                            <p class="text-sm text-gray-500" id="queueSubtitle">Patients waiting to be called</p>
                        </div>
                    </div>
                    <div class="relative">
                        <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-sm"></i>
                        <input type="text" id="searchQueue" placeholder="Search by name or record #..." class="pl-9 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-blue-400 w-64">
                    </div>
                </div>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50 border-b border-gray-200">
                        <tr>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Record #</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Patient Name</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Contact</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Reason</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Language</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Arrived</th>
                            <th class="px-5 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="queueTable">
                        <tr><td colspan="7" class="px-5 py-8 text-center text-gray-400"><div class="spinner mx-auto mb-3"></div>Loading queue...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Quick Stats Footer -->
        <div class="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl p-4">
                <div class="flex items-center gap-3">
                    <div class="bg-blue-600 rounded-lg p-2"><i class="fas fa-chart-line text-white"></i></div>
                    <div><p class="text-xs text-blue-600 font-medium">Average Wait Time</p><p class="text-xl font-bold text-blue-800" id="avgWaitTime">-- min</p></div>
                </div>
            </div>
            <div class="bg-gradient-to-r from-green-50 to-green-100 rounded-xl p-4">
                <div class="flex items-center gap-3">
                    <div class="bg-green-600 rounded-lg p-2"><i class="fas fa-check-circle text-white"></i></div>
                    <div><p class="text-xs text-green-600 font-medium">Completion Rate</p><p class="text-xl font-bold text-green-800" id="completionRate">--%</p></div>
                </div>
            </div>
            <div class="bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl p-4">
                <div class="flex items-center gap-3">
                    <div class="bg-purple-600 rounded-lg p-2"><i class="fas fa-clock text-white"></i></div>
                    <div><p class="text-xs text-purple-600 font-medium">Last Called</p><p class="text-xl font-bold text-purple-800" id="lastCalled">--:--</p></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- All modals remain the same -->
<!-- Patient Modal -->
<div id="patientModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden items-center justify-center p-4" style="display: none;">
    <div class="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6 border-b border-gray-100 flex justify-between items-center sticky top-0 bg-white">
            <h3 class="text-xl font-bold text-gray-800" id="patientModalTitle">Add New Patient</h3>
            <button onclick="closePatientModal()" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times text-xl"></i></button>
        </div>
        <form id="patientForm" class="p-6 space-y-4">
            <input type="hidden" id="patientId" name="patient_id" value="">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><label class="block text-sm font-medium text-gray-700 mb-1">First Name *</label><input type="text" id="firstName" name="first_name" required class="w-full px-4 py-2 border rounded-xl focus:ring-2 focus:ring-blue-500"></div>
                <div><label class="block text-sm font-medium text-gray-700 mb-1">Last Name</label><input type="text" id="lastName" name="last_name" class="w-full px-4 py-2 border rounded-xl focus:ring-2 focus:ring-blue-500"></div>
                <div><label class="block text-sm font-medium text-gray-700 mb-1">Date of Birth</label><input type="date" id="dob" name="dob" class="w-full px-4 py-2 border rounded-xl focus:ring-2 focus:ring-blue-500"></div>
                <div><label class="block text-sm font-medium text-gray-700 mb-1">Gender</label><select id="gender" name="gender" class="w-full px-4 py-2 border rounded-xl"><option value="">Select</option><option value="Male">Male</option><option value="Female">Female</option><option value="Other">Other</option></select></div>
                <div><label class="block text-sm font-medium text-gray-700 mb-1">Phone</label><input type="tel" id="phone" name="phone" class="w-full px-4 py-2 border rounded-xl focus:ring-2 focus:ring-blue-500"></div>
                <div><label class="block text-sm font-medium text-gray-700 mb-1">Email</label><input type="email" id="email" name="email" class="w-full px-4 py-2 border rounded-xl focus:ring-2 focus:ring-blue-500"></div>
                <div><label class="block text-sm font-medium text-gray-700 mb-1">Blood Group</label><select id="bloodGroup" name="blood_group" class="w-full px-4 py-2 border rounded-xl"><option value="">Select</option><option>A+</option><option>A-</option><option>B+</option><option>B-</option><option>AB+</option><option>AB-</option><option>O+</option><option>O-</option></select></div>
                <div><label class="block text-sm font-medium text-gray-700 mb-1">Emergency Contact</label><input type="tel" id="emergencyContact" name="emergency_contact" class="w-full px-4 py-2 border rounded-xl focus:ring-2 focus:ring-blue-500"></div>
                <div><label class="block text-sm font-medium text-gray-700 mb-1">Preferred Language</label><select id="preferredLanguage" name="preferred_language" class="w-full px-4 py-2 border rounded-xl"><option value="en">🇬🇧 English</option><option value="luganda">🇺🇬 Luganda</option><option value="swahili">🇰🇪 Kiswahili</option><option value="acholi">🇺🇬 Acholi</option><option value="runyankore">🇺🇬 Runyankore</option><option value="lusoga">🇺🇬 Lusoga</option><option value="ateso">🇺🇬 Ateso</option><option value="lugbara">🇺🇬 Lugbara</option><option value="rukiga">🇺🇬 Rukiga</option><option value="lango">🇺🇬 Lango</option></select></div>
                <div class="md:col-span-2"><label class="block text-sm font-medium text-gray-700 mb-1">Address</label><textarea id="address" name="address" rows="2" class="w-full px-4 py-2 border rounded-xl"></textarea></div>
                <div class="md:col-span-2"><label class="block text-sm font-medium text-gray-700 mb-1">Visit Reason *</label><textarea id="visitReason" name="reason" rows="2" required class="w-full px-4 py-2 border rounded-xl"></textarea></div>
            </div>
            <div class="flex gap-3 pt-4">
                <button type="submit" class="flex-1 bg-blue-600 text-white py-2.5 rounded-xl hover:bg-blue-700 transition font-semibold">Save Patient & Add to Queue</button>
                <button type="button" onclick="closePatientModal()" class="flex-1 bg-gray-100 text-gray-700 py-2.5 rounded-xl hover:bg-gray-200 transition">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- Search Patients Modal -->
<div id="searchModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden items-center justify-center p-4" style="display: none;">
    <div class="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6 border-b border-gray-100 flex justify-between items-center sticky top-0 bg-white">
            <h3 class="text-xl font-bold text-gray-800">Search Patients</h3>
            <button onclick="closeSearchModal()" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times text-xl"></i></button>
        </div>
        <div class="p-6">
            <div class="relative mb-6">
                <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <input type="text" id="searchInput" placeholder="Search by name, phone, or email..." class="w-full pl-10 pr-4 py-3 border rounded-xl focus:ring-2 focus:ring-blue-500">
            </div>
            <div id="searchResults" class="space-y-2 max-h-96 overflow-y-auto"></div>
        </div>
    </div>
</div>

<!-- Dispense Medicine Modal -->
<div id="dispenseModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden items-center justify-center p-4" style="display: none;">
    <div class="bg-white rounded-2xl max-w-md w-full">
        <div class="p-6 border-b border-gray-100 flex justify-between items-center">
            <h3 class="text-xl font-bold text-gray-800">Dispense Medicine</h3>
            <button onclick="closeDispenseModal()" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times text-xl"></i></button>
        </div>
        <form id="dispenseForm" class="p-6 space-y-4">
            <input type="hidden" id="dispenseVisitId" name="visit_id">
            <div><label class="block text-sm font-medium text-gray-700 mb-1">Medicine</label><select id="medicineSelect" name="medicine_id" required class="w-full px-4 py-2 border rounded-xl"><?php foreach ($medicines as $med): ?><option value="<?php echo $med['id']; ?>" data-stock="<?php echo $med['quantity']; ?>"><?php echo htmlspecialchars($med['name']); ?> (Stock: <?php echo $med['quantity']; ?> <?php echo $med['unit']; ?>)</option><?php endforeach; ?></select></div>
            <div><label class="block text-sm font-medium text-gray-700 mb-1">Quantity</label><input type="number" id="dispenseQty" name="quantity" min="1" required class="w-full px-4 py-2 border rounded-xl"></div>
            <div><label class="block text-sm font-medium text-gray-700 mb-1">Notes</label><textarea name="notes" rows="2" class="w-full px-4 py-2 border rounded-xl" placeholder="Prescription notes, dosage instructions..."></textarea></div>
            <div class="flex gap-3"><button type="submit" class="flex-1 bg-green-600 text-white py-2.5 rounded-xl hover:bg-green-700 transition">Dispense</button><button type="button" onclick="closeDispenseModal()" class="flex-1 bg-gray-100 text-gray-700 py-2.5 rounded-xl hover:bg-gray-200 transition">Cancel</button></div>
        </form>
    </div>
</div>

<!-- View Patient Modal -->
<div id="viewPatientModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden items-center justify-center p-4" style="display: none;">
    <div class="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6 border-b border-gray-100 flex justify-between items-center sticky top-0 bg-white">
            <h3 class="text-xl font-bold text-gray-800">Patient Details</h3>
            <button onclick="closeViewModal()" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times text-xl"></i></button>
        </div>
        <div id="viewPatientContent" class="p-6"></div>
    </div>
</div>

<!-- Hard Delete Confirmation Modal -->
<div id="hardDeleteModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden items-center justify-center p-4" style="display: none;">
    <div class="bg-white rounded-2xl max-w-md w-full">
        <div class="p-6 border-b border-gray-100 flex justify-between items-center">
            <h3 class="text-xl font-bold text-gray-800">⚠️ Permanent Deletion</h3>
            <button onclick="closeHardDeleteModal()" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times text-xl"></i></button>
        </div>
        <div class="p-6 space-y-4">
            <p class="text-gray-700">Are you sure you want to permanently delete this patient?</p>
            <div id="deleteDetails" class="bg-red-50 p-3 rounded-lg text-sm text-red-700"></div>
            <div class="flex gap-3 pt-2">
                <button id="confirmDeleteBtn" class="flex-1 bg-red-600 text-white py-2.5 rounded-xl hover:bg-red-700 transition">Yes, Delete Permanently</button>
                <button onclick="closeHardDeleteModal()" class="flex-1 bg-gray-100 text-gray-700 py-2.5 rounded-xl hover:bg-gray-200 transition">Cancel</button>
            </div>
        </div>
    </div>
</div>

<script>
let currentTab = 'waiting';
let refreshInterval;
let voiceEnabled = true;
let selectedLanguage = 'en';
let speechSynthesis = window.speechSynthesis;
const API_URL = '/api/queue_api.php';

// Language mapping
const languageFlags = {
    'en': '🇬🇧', 'luganda': '🇺🇬', 'swahili': '🇰🇪', 'acholi': '🇺🇬',
    'runyankore': '🇺🇬', 'lusoga': '🇺🇬', 'ateso': '🇺🇬', 'lugbara': '🇺🇬',
    'rukiga': '🇺🇬', 'lango': '🇺🇬'
};

const languageNames = {
    'en': 'English', 'luganda': 'Luganda', 'swahili': 'Kiswahili', 'acholi': 'Acholi',
    'runyankore': 'Runyankore', 'lusoga': 'Lusoga', 'ateso': 'Ateso', 'lugbara': 'Lugbara',
    'rukiga': 'Rukiga', 'lango': 'Lango'
};

// Tab functions
function showTab(tab) {
    currentTab = tab;
    
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('bg-blue-600', 'text-white');
        btn.classList.add('text-gray-600', 'hover:text-gray-800', 'bg-transparent');
    });
    
    const activeBtn = document.querySelector(`.tab-btn[data-tab="${tab}"]`);
    if (activeBtn) {
        activeBtn.classList.remove('text-gray-600', 'hover:text-gray-800', 'bg-transparent');
        activeBtn.classList.add('bg-blue-600', 'text-white');
    }
    
    const titles = {
        waiting: { title: 'Waiting Patients', subtitle: 'Patients waiting to be called' },
        called: { title: 'Called Patients', subtitle: 'Patients have been called and awaiting arrival' },
        arrived: { title: 'Arrived Patients', subtitle: 'Patients who have arrived' },
        visited: { title: 'Visited Patients', subtitle: 'Patients who have completed consultation' },
        served: { title: 'Served Patients', subtitle: 'Patients who have received service' }
    };
    
    document.getElementById('queueTitle').textContent = titles[tab].title;
    document.getElementById('queueSubtitle').textContent = titles[tab].subtitle;
    loadQueue();
}

// Voice function
function speakPatientName(patientName, recordNumber, language = null) {
    if (!voiceEnabled) return;
    const lang = language || selectedLanguage;
    
    if (speechSynthesis.speaking) speechSynthesis.cancel();
    
    const messages = {
        'en': `Attention please. Patient ${patientName} with record number ${recordNumber}, please proceed to the service counter.`,
        'luganda': `Mukama y'awulire. Omulwadde ${patientName} alina ennamba ${recordNumber}, kwatiriza okutuuka ku dduuka ly'abaami.`,
        'swahili': `Tafadhali tahadhari. Mgonjwa ${patientName} mwenye namba ${recordNumber}, tafadhali njoo kwenye kaunta ya huduma.`,
        'acholi': `Winyo ma woko. Labong ${patientName} ma namba ${recordNumber}, ber itim yot ma icomo i kompiyuta pa tic.`,
        'runyankore': `Mwebare okukiriza. Omurwaire ${patientName} orikwenda nombura ${recordNumber}, nikushaba ogende ahakuhweera.`,
        'lusoga': `Mwebale okukkiriza. Omulwadde ${patientName} alina ennamba ${recordNumber}, kwegenda ku bbali ly'obulamu.`,
        'ateso': `Akamaiso. Ekipakasi ${patientName} ekina namba ${recordNumber}, ikonyo ikosi ikejao.`,
        'lugbara': `Mìri o'biti. Adri ${patientName} drí nombà ${recordNumber}, ayiko a'di o'di o'biti ri.`,
        'rukiga': `Mwebare okukiriza. Omurwaire ${patientName} orikwenda nombura ${recordNumber}, nikushaba ogende aha kuhweera.`,
        'lango': `Winnyo. Labong ${patientName} ma namba ${recordNumber}, ber itim yot ma icomo i kompyuta pa tic.`
    };
    
    const message = messages[lang] || messages['en'];
    const utterance = new SpeechSynthesisUtterance(message);
    utterance.lang = lang === 'en' ? 'en-US' : lang;
    utterance.rate = 0.85;
    utterance.pitch = 1;
    speechSynthesis.speak(utterance);
}

// Load queue data
async function loadQueue() {
    try {
        const response = await fetch(`${API_URL}?action=get_queue&status=${currentTab}`);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const data = await response.json();
        const tbody = document.getElementById('queueTable');
        
        if (!data.success || !data.visits || data.visits.length === 0) {
            tbody.innerHTML = `<tr><td colspan="7" class="px-5 py-8 text-center text-gray-400"><i class="fas fa-inbox text-3xl mb-2 opacity-50"></i><p>No patients in ${currentTab} queue</p></td></tr>`;
            return;
        }
        
        tbody.innerHTML = data.visits.map(visit => `
            <tr class="border-b hover:bg-gray-50 transition" data-name="${escapeHtml(visit.patient.full_name)}" data-record="${escapeHtml(visit.record_number)}">
                <td class="px-5 py-3"><span class="font-mono text-sm font-bold text-gray-700">#${escapeHtml(visit.record_number)}</span>${visit.called_count > 0 ? `<span class="ml-1 text-xs text-gray-400">(${visit.called_count})</span>` : ''}</td>
                <td class="px-5 py-3"><div class="font-medium text-gray-800">${escapeHtml(visit.patient.full_name)}</div><div class="text-xs text-gray-400">${escapeHtml((visit.reason || 'No reason').substring(0, 30))}</div></td>
                <td class="px-5 py-3 text-sm text-gray-600">${visit.patient.phone ? `<i class="fas fa-phone-alt text-gray-400 text-xs mr-1"></i> ${escapeHtml(visit.patient.phone)}` : '-'}</td>
                <td class="px-5 py-3 text-sm text-gray-600 max-w-xs">${escapeHtml((visit.reason || '-').substring(0, 60))}${(visit.reason || '').length > 60 ? '...' : ''}</td>
                <td class="px-5 py-3"><span class="px-2 py-1 bg-gray-100 rounded-full text-xs">${languageFlags[visit.patient.preferred_language] || '🇬🇧'} ${languageNames[visit.patient.preferred_language] || 'English'}</span></td>
                <td class="px-5 py-3 text-sm text-gray-500">${formatTime(visit.created_at)}</td>
                <td class="px-5 py-3"><div class="flex items-center justify-center gap-2 flex-wrap">${getActionButtons(visit)}</div></td>
            </tr>
        `).join('');
        
        // Reload stats after loading queue
        await loadStats();
    } catch (err) {
        console.error('Error loading queue:', err);
        document.getElementById('queueTable').innerHTML = `<tr><td colspan="7" class="px-5 py-8 text-center text-red-500"><i class="fas fa-exclamation-circle text-2xl mb-2"></i><p>Error loading queue data: ${err.message}</p></td></tr>`;
    }
}

function formatTime(dateTime) {
    if (!dateTime) return '-';
    try { return new Date(dateTime).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }); } catch(e) { return '-'; }
}

function getActionButtons(visit) {
    let buttons = '';
    
    // WAITING - Call button
    if (visit.status === 'waiting') {
        buttons += `<button onclick="callPatient(${visit.id}, '${escapeHtml(visit.patient.full_name)}', '${escapeHtml(visit.record_number)}', '${visit.patient.preferred_language}')" class="px-3 py-1.5 bg-yellow-600 text-white text-sm rounded-lg hover:bg-yellow-700 transition"><i class="fas fa-phone-alt text-xs mr-1"></i> Call</button>`;
    }
    
    // CALLED - Arrived button AND Call Again button
    if (visit.status === 'called') {
        buttons += `<button onclick="markArrived(${visit.id})" class="px-3 py-1.5 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700 transition"><i class="fas fa-check-circle text-xs mr-1"></i> Arrived</button>`;
        buttons += `<button onclick="callAgain(${visit.id}, '${escapeHtml(visit.patient.full_name)}', '${escapeHtml(visit.record_number)}', '${visit.patient.preferred_language}')" class="px-3 py-1.5 bg-yellow-600 text-white text-sm rounded-lg hover:bg-yellow-700 transition"><i class="fas fa-phone-alt text-xs mr-1"></i> Call Again</button>`;
    }
    
    // ARRIVED - Visited button and Dispense button
    if (visit.status === 'arrived') {
        buttons += `<button onclick="markVisited(${visit.id})" class="px-3 py-1.5 bg-purple-600 text-white text-sm rounded-lg hover:bg-purple-700 transition"><i class="fas fa-stethoscope text-xs mr-1"></i> Visited</button>`;
        buttons += `<button onclick="openDispenseModal(${visit.id}, '${escapeHtml(visit.patient.full_name)}')" class="px-3 py-1.5 bg-indigo-600 text-white text-sm rounded-lg hover:bg-indigo-700 transition"><i class="fas fa-capsules text-xs mr-1"></i> Dispense</button>`;
    }
    
    // VISITED - Serve button
    if (visit.status === 'visited') {
        buttons += `<button onclick="markServed(${visit.id})" class="px-3 py-1.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition"><i class="fas fa-check-double text-xs mr-1"></i> Serve</button>`;
    }
    
    // Cancel button (not for served or cancelled)
    if (visit.status !== 'served' && visit.status !== 'cancelled') {
        buttons += `<button onclick="cancelVisit(${visit.id})" class="px-3 py-1.5 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700 transition"><i class="fas fa-times text-xs mr-1"></i> Cancel</button>`;
    }
    
    // View and Edit buttons for all
    buttons += `<button onclick="viewPatient(${visit.patient.id})" class="px-3 py-1.5 bg-gray-600 text-white text-sm rounded-lg hover:bg-gray-700 transition"><i class="fas fa-eye text-xs mr-1"></i> View</button>`;
    buttons += `<button onclick="editPatient(${visit.patient.id})" class="px-3 py-1.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition"><i class="fas fa-edit text-xs mr-1"></i> Edit</button>`;
    
    return buttons;
}

function escapeHtml(text) { if (!text) return ''; const div = document.createElement('div'); div.textContent = text; return div.innerHTML; }

// Call Again function - UPDATED - NO PAGE RELOAD
async function callAgain(visitId, patientName, recordNumber, patientLanguage) {
    if (!confirm(`Call patient ${patientName} again?`)) return;
    const languageToUse = patientLanguage !== 'en' ? patientLanguage : selectedLanguage;
    speakPatientName(patientName, recordNumber, languageToUse);
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'call_patient', visit_id: visitId, language: languageToUse })
        });
        const data = await response.json();
        if (data.success) {
            showNotification('success', `${patientName} called again in ${languageNames[languageToUse] || 'English'}`);
            // Reload the queue and stats without page reload
            await loadQueue();
            await loadStats();
        } else {
            showNotification('error', data.message);
        }
    } catch(err) {
        showNotification('error', 'Network error');
    }
}

// Call Patient - UPDATED - NO PAGE RELOAD
async function callPatient(visitId, patientName, recordNumber, patientLanguage) {
    if (!confirm(`Call patient ${patientName} to the service point?`)) return;
    const languageToUse = patientLanguage !== 'en' ? patientLanguage : selectedLanguage;
    speakPatientName(patientName, recordNumber, languageToUse);
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'call_patient', visit_id: visitId, language: languageToUse })
        });
        const data = await response.json();
        if (data.success) {
            showNotification('success', `${patientName} called in ${languageNames[languageToUse] || 'English'}`);
            // Reload the queue and stats without page reload
            await loadQueue();
            await loadStats();
        } else {
            showNotification('error', data.message);
        }
    } catch(err) {
        showNotification('error', 'Network error');
    }
}

// Mark Arrived - UPDATED - NO PAGE RELOAD
async function markArrived(visitId) {
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'mark_arrived', visit_id: visitId })
        });
        const data = await response.json();
        if (data.success) {
            showNotification('success', 'Patient marked as arrived');
            // Reload the queue and stats without page reload
            await loadQueue();
            await loadStats();
        } else {
            showNotification('error', data.message);
        }
    } catch(err) {
        showNotification('error', 'Network error');
    }
}

// Mark Visited - UPDATED - NO PAGE RELOAD
async function markVisited(visitId) {
    if (!confirm('Mark this patient as visited?')) return;
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'mark_visited', visit_id: visitId })
        });
        const data = await response.json();
        if (data.success) {
            showNotification('success', 'Patient marked as visited');
            // Reload the queue and stats without page reload
            await loadQueue();
            await loadStats();
        } else {
            showNotification('error', data.message);
        }
    } catch(err) {
        showNotification('error', 'Network error');
    }
}

// Mark Served - UPDATED - NO PAGE RELOAD
async function markServed(visitId) {
    if (!confirm('Mark this patient as served?')) return;
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'mark_served', visit_id: visitId })
        });
        const data = await response.json();
        if (data.success) {
            showNotification('success', 'Patient marked as served');
            // Reload the queue and stats without page reload
            await loadQueue();
            await loadStats();
        } else {
            showNotification('error', data.message);
        }
    } catch(err) {
        showNotification('error', 'Network error');
    }
}

// Cancel Visit - UPDATED - NO PAGE RELOAD
async function cancelVisit(visitId) {
    if (!confirm('Cancel this visit? This will remove the patient from queue.')) return;
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'cancel_visit', visit_id: visitId })
        });
        const data = await response.json();
        if (data.success) {
            showNotification('success', 'Visit cancelled');
            // Reload the queue and stats without page reload
            await loadQueue();
            await loadStats();
        } else {
            showNotification('error', data.message);
        }
    } catch(err) {
        showNotification('error', 'Network error');
    }
}

// Load Stats - UPDATED with totals
async function loadStats() {
    try {
        const response = await fetch(`${API_URL}?action=get_stats`);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const data = await response.json();
        if (data.success && data.data) {
            document.getElementById('waitingStat').textContent = data.data.waiting;
            document.getElementById('calledStat').textContent = data.data.called;
            document.getElementById('arrivedStat').textContent = data.data.arrived;
            document.getElementById('visitedStat').textContent = data.data.visited;
            document.getElementById('servedStat').textContent = data.data.served;
            document.getElementById('totalStat').textContent = data.data.total;
            document.getElementById('waitingBadge').textContent = data.data.waiting;
            document.getElementById('calledBadge').textContent = data.data.called;
            document.getElementById('arrivedBadge').textContent = data.data.arrived;
            document.getElementById('visitedBadge').textContent = data.data.visited;
            document.getElementById('servedBadge').textContent = data.data.served;
            const total = data.data.total || 1;
            const rate = total > 0 ? Math.round((data.data.served / total) * 100) : 0;
            document.getElementById('completionRate').textContent = `${rate}%`;
            document.getElementById('avgWaitTime').textContent = `${data.data.avg_wait_minutes || 0} min`;
            if (data.data.last_called_at) {
                const lastCalled = new Date(data.data.last_called_at);
                document.getElementById('lastCalled').textContent = lastCalled.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
            }
        }
    } catch(err) {
        console.error('Error loading stats:', err);
    }
}

// Patient CRUD - UPDATED with no page reload
function openPatientModal(patient = null) {
    document.getElementById('patientModal').style.display = 'flex';
    if (patient) {
        document.getElementById('patientModalTitle').textContent = 'Edit Patient';
        document.getElementById('patientId').value = patient.id;
        document.getElementById('firstName').value = patient.first_name;
        document.getElementById('lastName').value = patient.last_name || '';
        document.getElementById('dob').value = patient.dob || '';
        document.getElementById('phone').value = patient.phone || '';
        document.getElementById('email').value = patient.email || '';
        document.getElementById('address').value = patient.address || '';
        document.getElementById('gender').value = patient.gender || '';
        document.getElementById('bloodGroup').value = patient.blood_group || '';
        document.getElementById('emergencyContact').value = patient.emergency_contact || '';
        document.getElementById('preferredLanguage').value = patient.preferred_language || 'en';
        document.getElementById('visitReason').value = '';
    } else {
        document.getElementById('patientModalTitle').textContent = 'Add New Patient';
        document.getElementById('patientForm').reset();
        document.getElementById('patientId').value = '';
        document.getElementById('preferredLanguage').value = 'en';
    }
}

function closePatientModal() {
    document.getElementById('patientModal').style.display = 'none';
}

async function editPatient(patientId) {
    try {
        const response = await fetch(`${API_URL}?action=get_patient&id=${patientId}`);
        const data = await response.json();
        if (data.success) {
            openPatientModal(data.patient);
        }
    } catch(err) {
        showNotification('error', 'Error loading patient data');
    }
}

document.getElementById('patientForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const patientId = document.getElementById('patientId').value;
    const patientData = {
        first_name: document.getElementById('firstName').value,
        last_name: document.getElementById('lastName').value,
        dob: document.getElementById('dob').value,
        phone: document.getElementById('phone').value,
        email: document.getElementById('email').value,
        address: document.getElementById('address').value,
        gender: document.getElementById('gender').value,
        blood_group: document.getElementById('bloodGroup').value,
        emergency_contact: document.getElementById('emergencyContact').value,
        preferred_language: document.getElementById('preferredLanguage').value
    };
    const visitReason = document.getElementById('visitReason').value;
    
    try {
        let response;
        if (patientId) {
            patientData.id = patientId;
            response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'update_patient', ...patientData })
            });
        } else {
            response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'create_patient', ...patientData })
            });
        }
        const data = await response.json();
        if (data.success) {
            if (!patientId && visitReason) {
                const visitResponse = await fetch(API_URL, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'create_visit', patient_id: data.patient_id, reason: visitReason })
                });
                const visitData = await visitResponse.json();
                if (visitData.success) {
                    showNotification('success', 'Patient registered and added to queue');
                    closePatientModal();
                    // Reload queue and stats without page reload
                    await loadQueue();
                    await loadStats();
                } else {
                    showNotification('warning', 'Patient saved but visit creation failed');
                }
            } else {
                showNotification('success', data.message);
                closePatientModal();
                // Reload queue and stats without page reload
                await loadQueue();
                await loadStats();
            }
        } else {
            showNotification('error', data.message);
        }
    } catch(err) {
        showNotification('error', 'Network error');
    }
});

async function viewPatient(patientId) {
    try {
        const response = await fetch(`${API_URL}?action=get_patient&id=${patientId}`);
        const data = await response.json();
        if (data.success) {
            const p = data.patient;
            document.getElementById('viewPatientContent').innerHTML = `
                <div class="space-y-4">
                    <div class="flex justify-between items-start">
                        <div><h4 class="text-lg font-bold">${escapeHtml(p.full_name)}</h4><p class="text-sm text-gray-500">Patient ID: #${p.id}</p></div>
                        <div class="flex gap-2">
                            <button onclick="editPatient(${p.id})" class="px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700"><i class="fas fa-edit"></i> Edit</button>
                            <button onclick="confirmHardDelete(${p.id}, '${escapeHtml(p.full_name)}')" class="px-3 py-1.5 bg-red-600 text-white rounded-lg hover:bg-red-700"><i class="fas fa-trash-alt"></i> Delete</button>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div><label class="text-xs text-gray-500">Gender</label><p>${p.gender || '-'}</p></div>
                        <div><label class="text-xs text-gray-500">Date of Birth</label><p>${p.dob || '-'}</p></div>
                        <div><label class="text-xs text-gray-500">Blood Group</label><p>${p.blood_group || '-'}</p></div>
                        <div><label class="text-xs text-gray-500">Phone</label><p>${p.phone || '-'}</p></div>
                        <div><label class="text-xs text-gray-500">Email</label><p>${p.email || '-'}</p></div>
                        <div><label class="text-xs text-gray-500">Emergency Contact</label><p>${p.emergency_contact || '-'}</p></div>
                        <div><label class="text-xs text-gray-500">Preferred Language</label><p>${languageFlags[p.preferred_language] || '🇬🇧'} ${languageNames[p.preferred_language] || 'English'}</p></div>
                        <div><label class="text-xs text-gray-500">Registered</label><p>${new Date(p.created_at).toLocaleDateString()}</p></div>
                        <div class="col-span-2"><label class="text-xs text-gray-500">Address</label><p>${p.address || '-'}</p></div>
                    </div>
                    <div class="border-t pt-4"><h4 class="font-semibold mb-2">Visit History</h4>${data.visits.length ? `<div class="space-y-2">${data.visits.map(v => `<div class="bg-gray-50 p-3 rounded-lg"><div class="flex justify-between"><span class="font-mono text-sm">${v.record_number}</span><span class="text-xs text-gray-500">${new Date(v.created_at).toLocaleString()}</span></div><p class="text-sm mt-1">${v.reason}</p><span class="text-xs px-2 py-1 rounded-full ${v.status === 'served' ? 'bg-green-100 text-green-700' : v.status === 'visited' ? 'bg-purple-100 text-purple-700' : 'bg-yellow-100 text-yellow-700'}">${v.status}</span></div>`).join('')}</div>` : '<p class="text-gray-400 text-sm">No previous visits</p>'}</div>
                </div>`;
            document.getElementById('viewPatientModal').style.display = 'flex';
        }
    } catch(err) {
        showNotification('error', 'Error loading patient details');
    }
}

function closeViewModal() {
    document.getElementById('viewPatientModal').style.display = 'none';
}

// Delete functions
let deletePatientId = null;

function confirmHardDelete(patientId, patientName) {
    deletePatientId = patientId;
    document.getElementById('deleteDetails').innerHTML = `This will permanently delete <strong>${escapeHtml(patientName)}</strong> and all associated data including visits and medicine records. This action cannot be undone.`;
    document.getElementById('hardDeleteModal').style.display = 'flex';
}

function closeHardDeleteModal() {
    document.getElementById('hardDeleteModal').style.display = 'none';
    deletePatientId = null;
}

document.getElementById('confirmDeleteBtn').addEventListener('click', async function() {
    if (!deletePatientId) return;
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'permanent_delete_patient', id: deletePatientId })
        });
        const data = await response.json();
        if (data.success) {
            showNotification('success', data.message);
            closeHardDeleteModal();
            closeViewModal();
            // Reload queue and stats without page reload
            await loadQueue();
            await loadStats();
        } else {
            showNotification('error', data.message);
        }
    } catch(err) {
        showNotification('error', 'Network error');
    }
});

// Search functions
function openSearchModal() {
    document.getElementById('searchModal').style.display = 'flex';
    document.getElementById('searchInput').value = '';
    document.getElementById('searchResults').innerHTML = '';
}

function closeSearchModal() {
    document.getElementById('searchModal').style.display = 'none';
}

document.getElementById('searchInput')?.addEventListener('input', async function(e) {
    const query = e.target.value;
    if (query.length < 2) {
        document.getElementById('searchResults').innerHTML = '';
        return;
    }
    try {
        const response = await fetch(`${API_URL}?action=search_patients&q=${encodeURIComponent(query)}`);
        const data = await response.json();
        if (data.success && data.patients.length) {
            document.getElementById('searchResults').innerHTML = data.patients.map(p => `
                <div class="bg-gray-50 p-4 rounded-lg hover:bg-gray-100 cursor-pointer" onclick="selectPatient(${p.id}, '${escapeHtml(p.full_name)}')">
                    <div class="flex justify-between items-center"><span class="font-medium">${escapeHtml(p.full_name)}</span><span class="text-sm text-gray-500">${p.phone || ''}</span></div>
                    <div class="text-sm text-gray-500 mt-1">${p.email || ''} | ${languageFlags[p.preferred_language] || '🇬🇧'} ${languageNames[p.preferred_language] || 'English'}</div>
                </div>
            `).join('');
        } else {
            document.getElementById('searchResults').innerHTML = '<div class="text-center text-gray-400 py-4">No patients found</div>';
        }
    } catch(err) {
        console.error('Search error:', err);
    }
});

async function selectPatient(patientId, patientName) {
    const reason = prompt(`Enter reason for visit for ${patientName}:`);
    if (reason) {
        try {
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'create_visit', patient_id: patientId, reason: reason })
            });
            const data = await response.json();
            if (data.success) {
                showNotification('success', `${patientName} added to queue`);
                closeSearchModal();
                // Reload queue and stats without page reload
                await loadQueue();
                await loadStats();
            } else {
                showNotification('error', data.message);
            }
        } catch(err) {
            showNotification('error', 'Network error');
        }
    }
}

// Dispense functions - UPDATED with no page reload
function openDispenseModal(visitId, patientName) {
    document.getElementById('dispenseVisitId').value = visitId;
    document.getElementById('dispenseModal').style.display = 'flex';
    const select = document.getElementById('medicineSelect');
    if (select.options.length > 0) {
        document.getElementById('dispenseQty').max = select.options[select.selectedIndex].dataset.stock;
    }
}

function closeDispenseModal() {
    document.getElementById('dispenseModal').style.display = 'none';
}

document.getElementById('medicineSelect')?.addEventListener('change', function() {
    document.getElementById('dispenseQty').max = this.options[this.selectedIndex].dataset.stock;
});

document.getElementById('dispenseForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'dispense_medicine',
                visit_id: document.getElementById('dispenseVisitId').value,
                medicine_id: document.getElementById('medicineSelect').value,
                quantity: document.getElementById('dispenseQty').value,
                notes: document.querySelector('#dispenseForm textarea').value
            })
        });
        const data = await response.json();
        if (data.success) {
            showNotification('success', data.message);
            closeDispenseModal();
            // Reload queue and stats without page reload
            await loadQueue();
            await loadStats();
        } else {
            showNotification('error', data.message);
        }
    } catch(err) {
        showNotification('error', 'Network error');
    }
});

// Notification
function showNotification(type, message) {
    const notification = document.createElement('div');
    notification.className = `fixed top-20 right-4 z-50 p-4 rounded-xl shadow-lg ${type === 'success' ? 'bg-green-500' : 'bg-red-500'} text-white`;
    notification.innerHTML = `<div class="flex items-center gap-2"><i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i><span>${escapeHtml(message)}</span></div>`;
    document.body.appendChild(notification);
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Refresh function - manual refresh
function refreshPage() {
    loadQueue();
    loadStats();
    showNotification('info', 'Data refreshed');
}

// Voice toggle and search filter
document.getElementById('voiceLanguageSelect')?.addEventListener('change', function(e) {
    selectedLanguage = e.target.value;
});

document.getElementById('btnVoiceToggle')?.addEventListener('click', function() {
    voiceEnabled = !voiceEnabled;
    if (voiceEnabled) {
        this.classList.remove('bg-gray-600');
        this.classList.add('bg-green-600');
        this.innerHTML = '<i class="fas fa-volume-up"></i> Voice: ON';
        showNotification('success', 'Voice announcements enabled');
    } else {
        this.classList.remove('bg-green-600');
        this.classList.add('bg-gray-600');
        this.innerHTML = '<i class="fas fa-volume-mute"></i> Voice: OFF';
        showNotification('info', 'Voice announcements disabled');
        if (speechSynthesis.speaking) speechSynthesis.cancel();
    }
});

document.getElementById('searchQueue')?.addEventListener('keyup', function(e) {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#queueTable tr').forEach(row => {
        if (row.cells && row.cells.length > 1) {
            const name = row.getAttribute('data-name') || '';
            const record = row.getAttribute('data-record') || '';
            row.style.display = (name.includes(term) || record.includes(term)) ? '' : 'none';
        }
    });
});

// Initialize
loadQueue();
loadStats();
refreshInterval = setInterval(() => {
    loadQueue();
    loadStats();
}, 5000);

window.addEventListener('beforeunload', () => {
    if (refreshInterval) clearInterval(refreshInterval);
    if (speechSynthesis.speaking) speechSynthesis.cancel();
});
</script>

<style>
.stat-card {
    background: white;
    border-radius: 1rem;
    box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
    transition: all 0.3s ease;
}
.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px -5px rgb(0 0 0 / 0.1);
}
.chart-card {
    background: white;
    border-radius: 1rem;
    box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
}
.spinner {
    border: 3px solid #f3f3f3;
    border-top: 3px solid #3498db;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    animation: spin 1s linear infinite;
    margin: 0 auto;
}
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
.fade-in-up {
    animation: fadeInUp 0.5s ease-out;
}
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
.tab-btn {
    transition: all 0.2s ease;
}
.tab-btn:hover {
    transform: translateY(-1px);
}
</style>

<?php include '../includes/footer.php'; ?>