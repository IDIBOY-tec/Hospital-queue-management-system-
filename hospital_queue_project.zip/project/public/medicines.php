<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/settings.php';

require_admin();

$page_title = 'Medicines Inventory - ' . ($app_name ?? 'Hospital Queue System');
$message = '';
$message_type = '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'add_medicine') {
            $name = trim($_POST['name'] ?? '');
            $batch_no = trim($_POST['batch_no'] ?? '');
            $quantity = intval($_POST['quantity'] ?? 0);
            $unit = trim($_POST['unit'] ?? 'pcs');
            $price = floatval($_POST['price'] ?? 0);
            $expiry_date = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;
            $manufacturer = trim($_POST['manufacturer'] ?? '');

            if (!$name) {
                $message = 'Medicine name is required';
                $message_type = 'error';
            } else {
                $stmt = mysqli_prepare($mysqli, "INSERT INTO medicines (name, batch_no, quantity, unit, price, expiry_date, manufacturer) VALUES (?, ?, ?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt, 'ssisdss', $name, $batch_no, $quantity, $unit, $price, $expiry_date, $manufacturer);

                if (mysqli_stmt_execute($stmt)) {
                    $message = 'Medicine added successfully';
                    $message_type = 'success';
                } else {
                    $message = 'Error adding medicine: ' . mysqli_error($mysqli);
                    $message_type = 'error';
                }
            }
        } elseif ($_POST['action'] === 'update_medicine') {
            $medicine_id = intval($_POST['medicine_id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            $batch_no = trim($_POST['batch_no'] ?? '');
            $quantity = intval($_POST['quantity'] ?? 0);
            $unit = trim($_POST['unit'] ?? 'pcs');
            $price = floatval($_POST['price'] ?? 0);
            $expiry_date = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;
            $manufacturer = trim($_POST['manufacturer'] ?? '');

            if ($medicine_id > 0 && $name) {
                $stmt = mysqli_prepare($mysqli, "UPDATE medicines SET name=?, batch_no=?, quantity=?, unit=?, price=?, expiry_date=?, manufacturer=? WHERE id=?");
                mysqli_stmt_bind_param($stmt, 'ssisdssi', $name, $batch_no, $quantity, $unit, $price, $expiry_date, $manufacturer, $medicine_id);

                if (mysqli_stmt_execute($stmt)) {
                    $message = 'Medicine updated successfully';
                    $message_type = 'success';
                } else {
                    $message = 'Error updating medicine';
                    $message_type = 'error';
                }
            }
        } elseif ($_POST['action'] === 'delete_medicine') {
            $medicine_id = intval($_POST['medicine_id'] ?? 0);

            if ($medicine_id > 0) {
                // Check if medicine has been dispensed
                $check = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM medicine_given WHERE medicine_id = $medicine_id");
                $used = mysqli_fetch_assoc($check)['cnt'];
                
                if ($used > 0) {
                    $message = "Cannot delete: Medicine has been dispensed $used time(s)";
                    $message_type = 'error';
                } else {
                    $stmt = mysqli_prepare($mysqli, "DELETE FROM medicines WHERE id=?");
                    mysqli_stmt_bind_param($stmt, 'i', $medicine_id);

                    if (mysqli_stmt_execute($stmt)) {
                        $message = 'Medicine deleted successfully';
                        $message_type = 'success';
                    } else {
                        $message = 'Error deleting medicine';
                        $message_type = 'error';
                    }
                }
            }
        } elseif ($_POST['action'] === 'adjust_stock') {
            $medicine_id = intval($_POST['medicine_id'] ?? 0);
            $adjustment = intval($_POST['adjustment'] ?? 0);
            $reason = trim($_POST['reason'] ?? '');

            if ($medicine_id > 0 && $adjustment != 0) {
                $current = mysqli_query($mysqli, "SELECT quantity FROM medicines WHERE id = $medicine_id");
                $current_qty = mysqli_fetch_assoc($current)['quantity'];
                $new_qty = $current_qty + $adjustment;
                
                if ($new_qty >= 0) {
                    $stmt = mysqli_prepare($mysqli, "UPDATE medicines SET quantity = ? WHERE id = ?");
                    mysqli_stmt_bind_param($stmt, 'ii', $new_qty, $medicine_id);
                    
                    if (mysqli_stmt_execute($stmt)) {
                        $message = "Stock adjusted: " . ($adjustment > 0 ? "+$adjustment" : $adjustment) . " units";
                        $message_type = 'success';
                    } else {
                        $message = 'Error adjusting stock';
                        $message_type = 'error';
                    }
                } else {
                    $message = 'Cannot reduce stock below zero';
                    $message_type = 'error';
                }
            }
        }
    }
}

// Get all medicines with statistics
$result = mysqli_query($mysqli, "
    SELECT m.*, 
           COALESCE(SUM(mg.qty), 0) as total_dispensed,
           COUNT(DISTINCT mg.visit_id) as times_dispensed
    FROM medicines m
    LEFT JOIN medicine_given mg ON mg.medicine_id = m.id AND mg.given_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY m.id
    ORDER BY 
        CASE WHEN m.quantity < 10 THEN 0 ELSE 1 END,
        m.name
");
$medicines = [];
$total_stock_value = 0;
$low_stock_count = 0;
$expired_count = 0;
$total_dispensed_30d = 0;

while ($row = mysqli_fetch_assoc($result)) {
    $medicines[] = $row;
    $total_stock_value += $row['quantity'] * $row['price'];
    if ($row['quantity'] < 10) $low_stock_count++;
    $total_dispensed_30d += $row['total_dispensed'];
    // Check expiry
    if ($row['expiry_date'] && $row['expiry_date'] < date('Y-m-d')) $expired_count++;
}

// Get top dispensed medicines
$top_medicines = mysqli_query($mysqli, "
    SELECT m.name, SUM(mg.qty) as total_dispensed
    FROM medicines m
    JOIN medicine_given mg ON mg.medicine_id = m.id
    WHERE mg.given_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY m.id
    ORDER BY total_dispensed DESC
    LIMIT 5
");

$top_meds_data = [];
while ($row = mysqli_fetch_assoc($top_medicines)) {
    $top_meds_data[] = $row;
}

// Get stock by category/unit
$stock_by_unit = mysqli_query($mysqli, "
    SELECT unit, SUM(quantity) as total_stock, COUNT(*) as count
    FROM medicines
    GROUP BY unit
");
?>
<?php include '../includes/header.php'; ?>

<div class="main-content">
    <div class="p-4 md:p-8">
        <!-- Header -->
        <div class="mb-8 fade-in-up">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h1 class="text-3xl md:text-4xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                        Medicines Inventory
                    </h1>
                    <p class="text-gray-500 mt-2">Manage your pharmaceutical inventory and track stock levels</p>
                </div>
                <button onclick="openAddModal()" class="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg transition-all flex items-center gap-2">
                    <i class="fas fa-plus"></i>
                    Add New Medicine
                </button>
            </div>
        </div>

        <!-- Alert Message -->
        <?php if ($message): ?>
            <div class="mb-6 p-4 rounded-xl <?php echo $message_type === 'success' ? 'bg-green-50 border-l-4 border-green-500 text-green-700' : 'bg-red-50 border-l-4 border-red-500 text-red-700'; ?>">
                <div class="flex items-center gap-2">
                    <i class="fas <?php echo $message_type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                    <span><?php echo htmlspecialchars($message); ?></span>
                </div>
            </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Total Medicines</p>
                        <p class="text-2xl font-bold text-blue-600 mt-1"><?php echo count($medicines); ?></p>
                    </div>
                    <div class="bg-blue-100 rounded-xl p-3">
                        <i class="fas fa-capsules text-blue-600 text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Total Stock Value</p>
                        <p class="text-2xl font-bold text-emerald-600 mt-1">$<?php echo number_format($total_stock_value, 2); ?></p>
                    </div>
                    <div class="bg-emerald-100 rounded-xl p-3">
                        <i class="fas fa-dollar-sign text-emerald-600 text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Low Stock Items</p>
                        <p class="text-2xl font-bold text-amber-600 mt-1"><?php echo $low_stock_count; ?></p>
                    </div>
                    <div class="bg-amber-100 rounded-xl p-3">
                        <i class="fas fa-exclamation-triangle text-amber-600 text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Expired Items</p>
                        <p class="text-2xl font-bold text-red-600 mt-1"><?php echo $expired_count; ?></p>
                    </div>
                    <div class="bg-red-100 rounded-xl p-3">
                        <i class="fas fa-calendar-times text-red-600 text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Dispensed (30d)</p>
                        <p class="text-2xl font-bold text-purple-600 mt-1"><?php echo number_format($total_dispensed_30d); ?></p>
                    </div>
                    <div class="bg-purple-100 rounded-xl p-3">
                        <i class="fas fa-chart-line text-purple-600 text-xl"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts Row -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <div class="chart-card p-5">
                <h3 class="font-bold text-gray-800 mb-4"><i class="fas fa-chart-bar text-blue-500 mr-2"></i>Top Dispensed Medicines (30 Days)</h3>
                <canvas id="topMedsChart" height="250"></canvas>
            </div>
            
            <div class="chart-card p-5">
                <h3 class="font-bold text-gray-800 mb-4"><i class="fas fa-chart-pie text-purple-500 mr-2"></i>Stock Distribution by Unit</h3>
                <canvas id="unitChart" height="250"></canvas>
            </div>
        </div>

        <!-- Low Stock Alert Banner -->
        <?php if ($low_stock_count > 0): ?>
            <div class="mb-8 bg-gradient-to-r from-amber-50 to-orange-50 border-l-4 border-amber-500 rounded-xl p-5">
                <div class="flex items-start gap-3">
                    <div class="bg-amber-500 rounded-full p-2">
                        <i class="fas fa-bell text-white text-sm"></i>
                    </div>
                    <div>
                        <h4 class="font-bold text-amber-800">Low Stock Alert</h4>
                        <p class="text-amber-700 text-sm mt-1">
                            <?php echo $low_stock_count; ?> medicine(s) are running low (less than 10 units). 
                            Please review and reorder soon.
                        </p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Medicines Table -->
        <div class="chart-card overflow-hidden">
            <div class="p-5 border-b border-gray-100 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <h3 class="font-bold text-gray-800"><i class="fas fa-table-list text-gray-500 mr-2"></i>All Medicines</h3>
                <div class="flex gap-2">
                    <div class="relative">
                        <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-sm"></i>
                        <input type="text" id="searchInput" placeholder="Search medicines..." class="pl-9 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-blue-400 w-64">
                    </div>
                    <button onclick="exportToCSV()" class="px-3 py-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition text-sm">
                        <i class="fas fa-download"></i> Export
                    </button>
                </div>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full" id="medicinesTable">
                    <thead class="bg-gray-50 border-b border-gray-200">
                        <tr>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Name</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Batch</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Quantity</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Unit</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Price</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Expiry</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Dispensed</th>
                            <th class="px-5 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php foreach ($medicines as $medicine): 
                            $is_low = $medicine['quantity'] < 10;
                            $is_expired = $medicine['expiry_date'] && $medicine['expiry_date'] < date('Y-m-d');
                            $expiry_soon = $medicine['expiry_date'] && $medicine['expiry_date'] >= date('Y-m-d') && $medicine['expiry_date'] <= date('Y-m-d', strtotime('+30 days'));
                        ?>
                            <tr class="hover:bg-gray-50 transition medicine-row" data-name="<?php echo strtolower(htmlspecialchars($medicine['name'])); ?>">
                                <td class="px-5 py-3">
                                    <div class="font-medium text-gray-800"><?php echo htmlspecialchars($medicine['name']); ?></div>
                                    <?php if ($medicine['manufacturer']): ?>
                                        <div class="text-xs text-gray-400"><?php echo htmlspecialchars($medicine['manufacturer']); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td class="px-5 py-3 text-sm text-gray-600"><?php echo htmlspecialchars($medicine['batch_no'] ?? '-'); ?></td>
                                <td class="px-5 py-3">
                                    <span class="<?php echo $is_low ? 'text-red-600 font-bold' : 'text-gray-700'; ?>">
                                        <?php echo number_format($medicine['quantity']); ?>
                                    </span>
                                    <?php if ($is_low): ?>
                                        <span class="ml-2 px-1.5 py-0.5 bg-red-100 text-red-600 text-xs rounded-full">Low</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-5 py-3 text-sm text-gray-600"><?php echo htmlspecialchars($medicine['unit']); ?></td>
                                <td class="px-5 py-3 text-sm text-gray-600">$<?php echo number_format($medicine['price'], 2); ?></td>
                                <td class="px-5 py-3">
                                    <?php if ($medicine['expiry_date']): ?>
                                        <span class="text-sm <?php echo $is_expired ? 'text-red-600 font-bold' : ($expiry_soon ? 'text-amber-600' : 'text-gray-600'); ?>">
                                            <?php echo date('M d, Y', strtotime($medicine['expiry_date'])); ?>
                                        </span>
                                        <?php if ($is_expired): ?>
                                            <span class="ml-2 px-1.5 py-0.5 bg-red-100 text-red-600 text-xs rounded-full">Expired</span>
                                        <?php elseif ($expiry_soon): ?>
                                            <span class="ml-2 px-1.5 py-0.5 bg-amber-100 text-amber-600 text-xs rounded-full">Soon</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-sm text-gray-400">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-5 py-3 text-sm text-gray-600"><?php echo number_format($medicine['total_dispensed']); ?></td>
                                <td class="px-5 py-3 text-center">
                                    <div class="flex items-center justify-center gap-2">
                                        <button onclick="editMedicine(<?php echo htmlspecialchars(json_encode($medicine)); ?>)" 
                                                class="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button onclick="adjustStock(<?php echo $medicine['id']; ?>, '<?php echo htmlspecialchars($medicine['name']); ?>', <?php echo $medicine['quantity']; ?>)" 
                                                class="p-1.5 text-amber-600 hover:bg-amber-50 rounded-lg transition">
                                            <i class="fas fa-exchange-alt"></i>
                                        </button>
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this medicine? This action cannot be undone.');">
                                            <input type="hidden" name="action" value="delete_medicine">
                                            <input type="hidden" name="medicine_id" value="<?php echo $medicine['id']; ?>">
                                            <button type="submit" class="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if (empty($medicines)): ?>
                <div class="text-center py-12 text-gray-400">
                    <i class="fas fa-capsules text-4xl mb-3 opacity-50"></i>
                    <p>No medicines found. Click "Add New Medicine" to get started.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Add/Edit Medicine Modal -->
<div id="medicineModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden items-center justify-center p-4" style="display: none;">
    <div class="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6 border-b border-gray-100 flex justify-between items-center">
            <h3 class="text-xl font-bold text-gray-800" id="modalTitle">Add New Medicine</h3>
            <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-times text-xl"></i>
            </button>
        </div>
        <form method="POST" id="medicineForm" class="p-6 space-y-4">
            <input type="hidden" name="action" id="formAction" value="add_medicine">
            <input type="hidden" name="medicine_id" id="medicineId">
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Medicine Name *</label>
                <input type="text" name="name" id="medName" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            </div>
            
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Batch Number</label>
                    <input type="text" name="batch_no" id="medBatch" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Unit</label>
                    <input type="text" name="unit" id="medUnit" value="pcs" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
            </div>
            
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Quantity</label>
                    <input type="number" name="quantity" id="medQuantity" value="0" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Price ($)</label>
                    <input type="number" step="0.01" name="price" id="medPrice" value="0.00" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
            </div>
            
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Expiry Date</label>
                    <input type="date" name="expiry_date" id="medExpiry" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Manufacturer</label>
                    <input type="text" name="manufacturer" id="medManufacturer" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
            </div>
            
            <div class="flex gap-3 pt-4">
                <button type="submit" class="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition font-semibold">
                    Save Medicine
                </button>
                <button type="button" onclick="closeModal()" class="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg hover:bg-gray-200 transition">
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Adjust Stock Modal -->
<div id="adjustModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden items-center justify-center p-4" style="display: none;">
    <div class="bg-white rounded-2xl max-w-md w-full">
        <div class="p-6 border-b border-gray-100">
            <h3 class="text-xl font-bold text-gray-800">Adjust Stock</h3>
            <p class="text-sm text-gray-500 mt-1" id="adjustMedicineName"></p>
        </div>
        <form method="POST" class="p-6 space-y-4">
            <input type="hidden" name="action" value="adjust_stock">
            <input type="hidden" name="medicine_id" id="adjustMedicineId">
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Current Stock</label>
                <input type="text" id="currentStock" readonly class="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-gray-600">
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Adjustment (+/-)</label>
                <input type="number" name="adjustment" id="adjustment" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="Enter positive or negative number">
                <p class="text-xs text-gray-400 mt-1">Use + to add stock, - to reduce stock</p>
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Reason</label>
                <input type="text" name="reason" placeholder="e.g., New shipment, damaged, etc." class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
            </div>
            
            <div class="flex gap-3 pt-2">
                <button type="submit" class="flex-1 bg-amber-600 text-white py-2 rounded-lg hover:bg-amber-700 transition font-semibold">
                    Apply Adjustment
                </button>
                <button type="button" onclick="closeAdjustModal()" class="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg hover:bg-gray-200 transition">
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Charts
let topMedsChart, unitChart;

function loadCharts() {
    // Top Medicines Chart
    const topMedsData = <?php echo json_encode($top_meds_data); ?>;
    if (topMedsData.length > 0) {
        const ctx = document.getElementById('topMedsChart');
        if (ctx) {
            if (topMedsChart) topMedsChart.destroy();
            topMedsChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: topMedsData.map(m => m.name.length > 20 ? m.name.substring(0, 20) + '...' : m.name),
                    datasets: [{
                        label: 'Units Dispensed (30 days)',
                        data: topMedsData.map(m => m.total_dispensed),
                        backgroundColor: '#3b82f6',
                        borderRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: { position: 'top' }
                    }
                }
            });
        }
    }
    
    // Unit Distribution Chart
    const unitData = <?php echo json_encode(array_map(function($row) { return ['unit' => $row['unit'], 'total_stock' => $row['total_stock']]; }, iterator_to_array($stock_by_unit))); ?>;
    if (unitData.length > 0) {
        const ctx = document.getElementById('unitChart');
        if (ctx) {
            if (unitChart) unitChart.destroy();
            unitChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: unitData.map(u => u.unit),
                    datasets: [{
                        data: unitData.map(u => u.total_stock),
                        backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec489a']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: { position: 'bottom' }
                    }
                }
            });
        }
    }
}

// Modal Functions
function openAddModal() {
    document.getElementById('modalTitle').textContent = 'Add New Medicine';
    document.getElementById('formAction').value = 'add_medicine';
    document.getElementById('medicineId').value = '';
    document.getElementById('medName').value = '';
    document.getElementById('medBatch').value = '';
    document.getElementById('medUnit').value = 'pcs';
    document.getElementById('medQuantity').value = '0';
    document.getElementById('medPrice').value = '0.00';
    document.getElementById('medExpiry').value = '';
    document.getElementById('medManufacturer').value = '';
    document.getElementById('medicineModal').style.display = 'flex';
}

function editMedicine(medicine) {
    document.getElementById('modalTitle').textContent = 'Edit Medicine';
    document.getElementById('formAction').value = 'update_medicine';
    document.getElementById('medicineId').value = medicine.id;
    document.getElementById('medName').value = medicine.name;
    document.getElementById('medBatch').value = medicine.batch_no || '';
    document.getElementById('medUnit').value = medicine.unit;
    document.getElementById('medQuantity').value = medicine.quantity;
    document.getElementById('medPrice').value = medicine.price;
    document.getElementById('medExpiry').value = medicine.expiry_date || '';
    document.getElementById('medManufacturer').value = medicine.manufacturer || '';
    document.getElementById('medicineModal').style.display = 'flex';
}

function adjustStock(id, name, current) {
    document.getElementById('adjustMedicineId').value = id;
    document.getElementById('adjustMedicineName').textContent = name;
    document.getElementById('currentStock').value = current;
    document.getElementById('adjustment').value = '';
    document.getElementById('adjustModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('medicineModal').style.display = 'none';
}

function closeAdjustModal() {
    document.getElementById('adjustModal').style.display = 'none';
}

// Search Function
document.getElementById('searchInput')?.addEventListener('keyup', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('.medicine-row');
    
    rows.forEach(row => {
        const name = row.getAttribute('data-name');
        if (name && name.includes(searchTerm)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});

// Export to CSV
function exportToCSV() {
    const rows = document.querySelectorAll('#medicinesTable tbody tr');
    let csv = [['Name', 'Batch', 'Quantity', 'Unit', 'Price', 'Expiry Date', 'Manufacturer', 'Dispensed']];
    
    rows.forEach(row => {
        if (row.style.display !== 'none') {
            const cells = row.querySelectorAll('td');
            if (cells.length >= 7) {
                csv.push([
                    cells[0].innerText.trim(),
                    cells[1].innerText.trim(),
                    cells[2].innerText.trim(),
                    cells[3].innerText.trim(),
                    cells[4].innerText.trim(),
                    cells[5].innerText.trim(),
                    cells[6].innerText.trim()
                ]);
            }
        }
    });
    
    const csvContent = csv.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'medicines_export.csv';
    a.click();
    URL.revokeObjectURL(url);
}

// Close modals when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('medicineModal');
    const adjustModal = document.getElementById('adjustModal');
    if (event.target === modal) closeModal();
    if (event.target === adjustModal) closeAdjustModal();
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    loadCharts();
    
    // Check if Chart.js is ready
    if (typeof Chart === 'undefined') {
        console.warn('Chart.js not loaded yet, retrying...');
        setTimeout(loadCharts, 1000);
    }
});
</script>

<?php include '../includes/footer.php'; ?>