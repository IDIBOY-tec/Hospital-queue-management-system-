const POLL_INTERVAL_MS = 2000;
const SPEAK_REPEAT_MS = 3000;

let speakInterval = null;
let currentVisitId = null;
let voiceEnabled = (localStorage.getItem('voiceEnabled') !== 'false');

function fetchActiveCall() {
    fetch('/api/api_fetch_active_call.php')
        .then(r => r.json())
        .then(data => {
            if (data.success && data.visit) {
                const visit = data.visit;
                if (visit.id !== currentVisitId) {
                    currentVisitId = visit.id;
                    startSpeaking(visit);
                }
            } else {
                stopSpeaking();
            }
        })
        .catch(err => console.error('fetchActiveCall error:', err));
}

function startSpeaking(visit) {
    stopSpeaking();
    if (!voiceEnabled) return;

    const text = `Patient ${visit.first_name} ${visit.last_name}. Record number ${visit.record_number}.`;
    speakText(text);
    speakInterval = setInterval(() => speakText(text), SPEAK_REPEAT_MS);
}

function stopSpeaking() {
    currentVisitId = null;
    if (speakInterval) clearInterval(speakInterval);
    if ('speechSynthesis' in window) speechSynthesis.cancel();
}

function speakText(text) {
    if (!voiceEnabled || !('speechSynthesis' in window)) return;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = 0.9;

    if ('speechSynthesis' in window) {
        speechSynthesis.cancel();
        speechSynthesis.speak(utterance);
    }
}

if (document.getElementById('btnVoiceToggle')) {
    document.getElementById('btnVoiceToggle').addEventListener('click', function() {
        voiceEnabled = !voiceEnabled;
        localStorage.setItem('voiceEnabled', voiceEnabled);

        if (voiceEnabled) {
            this.textContent = '🔊 Voice: ON';
            this.classList.add('bg-green-600');
            this.classList.remove('bg-gray-600');
            if (currentVisitId !== null) {
                fetchActiveCall();
            }
        } else {
            this.textContent = '🔇 Voice: OFF';
            this.classList.remove('bg-green-600');
            this.classList.add('bg-gray-600');
            stopSpeaking();
        }
    });

    const btn = document.getElementById('btnVoiceToggle');
    if (!voiceEnabled) {
        btn.textContent = '🔇 Voice: OFF';
        btn.classList.remove('bg-green-600');
        btn.classList.add('bg-gray-600');
    }
}

setInterval(fetchActiveCall, POLL_INTERVAL_MS);
fetchActiveCall();
