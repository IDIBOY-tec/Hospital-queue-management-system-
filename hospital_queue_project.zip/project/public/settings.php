<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/settings.php';

require_admin();

$page_title = 'Settings - ' . $app_name;
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $app_name_input = trim($_POST['app_name'] ?? $app_name);
    $font_family_input = trim($_POST['font_family'] ?? $font_family);
    $sidebar_bg_color_input = trim($_POST['sidebar_bg_color'] ?? $sidebar_bg_color);

    save_setting($mysqli, 'app_name', $app_name_input);
    save_setting($mysqli, 'font_family', $font_family_input);
    save_setting($mysqli, 'sidebar_bg_color', $sidebar_bg_color_input);

    $message = '<div class="p-3 bg-green-100 border border-green-400 text-green-700 rounded">Settings saved successfully. Please refresh to see changes.</div>';

    $font_family = $font_family_input;
    $sidebar_bg_color = $sidebar_bg_color_input;
    $app_name = $app_name_input;
}
?>
<?php include '../includes/header.php'; ?>

<div class="main-content">
    <div class="p-4 md:p-8">
        <!-- Header -->
        <div class="mb-8 fade-in-up">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h1 class="text-3xl md:text-4xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                        System Settings
                    </h1>
                    <p class="text-gray-500 mt-2">Configure your application preferences and customize the interface</p>
                </div>
                <div class="flex gap-3">
                    <button onclick="window.location.reload()" class="bg-gray-100 text-gray-700 px-5 py-2.5 rounded-xl font-medium hover:bg-gray-200 transition-all flex items-center gap-2">
                        <i class="fas fa-sync-alt"></i>
                        Refresh
                    </button>
                </div>
            </div>
        </div>

        <!-- Alert Message -->
        <?php if ($message): ?>
            <div class="mb-6 p-4 rounded-xl bg-green-50 border-l-4 border-green-500 text-green-700">
                <div class="flex items-center gap-2">
                    <i class="fas fa-check-circle text-green-500"></i>
                    <?php echo $message; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Settings Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Main Settings Form -->
            <div class="lg:col-span-2">
                <form method="POST" class="space-y-6">
                    <!-- General Settings -->
                    <div class="chart-card overflow-hidden">
                        <div class="p-5 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
                            <div class="flex items-center gap-3">
                                <div class="bg-blue-600 rounded-xl p-2">
                                    <i class="fas fa-cog text-white text-lg"></i>
                                </div>
                                <div>
                                    <h3 class="text-xl font-bold text-gray-800">General Settings</h3>
                                    <p class="text-sm text-gray-500">Basic application configuration</p>
                                </div>
                            </div>
                        </div>
                        <div class="p-5 space-y-5">
                            <!-- Application Name -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Application Name
                                </label>
                                <input type="text" name="app_name" value="<?php echo htmlspecialchars($app_name); ?>" 
                                       class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition">
                                <p class="text-xs text-gray-400 mt-1">Displayed in sidebar, header, and browser title</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Appearance Settings -->
                    <div class="chart-card overflow-hidden">
                        <div class="p-5 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
                            <div class="flex items-center gap-3">
                                <div class="bg-purple-600 rounded-xl p-2">
                                    <i class="fas fa-palette text-white text-lg"></i>
                                </div>
                                <div>
                                    <h3 class="text-xl font-bold text-gray-800">Appearance Settings</h3>
                                    <p class="text-sm text-gray-500">Customize the look and feel</p>
                                </div>
                            </div>
                        </div>
                        <div class="p-5 space-y-5">
                            <!-- Font Family -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Font Family</label>
                                <select name="font_family" id="fontSelect" class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500">
                                    <option value="Inter, system-ui, sans-serif" <?php echo ($font_family === 'Inter, system-ui, sans-serif') ? 'selected' : ''; ?>>Inter (Modern)</option>
                                    <option value="Poppins, sans-serif" <?php echo ($font_family === 'Poppins, sans-serif') ? 'selected' : ''; ?>>Poppins</option>
                                    <option value="Roboto, sans-serif" <?php echo ($font_family === 'Roboto, sans-serif') ? 'selected' : ''; ?>>Roboto</option>
                                    <option value="'Open Sans', sans-serif" <?php echo ($font_family === "'Open Sans', sans-serif") ? 'selected' : ''; ?>>Open Sans</option>
                                    <option value="Lato, sans-serif" <?php echo ($font_family === 'Lato, sans-serif') ? 'selected' : ''; ?>>Lato</option>
                                    <option value="Montserrat, sans-serif" <?php echo ($font_family === 'Montserrat, sans-serif') ? 'selected' : ''; ?>>Montserrat</option>
                                    <option value="Nunito, sans-serif" <?php echo ($font_family === 'Nunito, sans-serif') ? 'selected' : ''; ?>>Nunito</option>
                                    <option value="Calibri, 'Segoe UI', sans-serif" <?php echo ($font_family === "Calibri, 'Segoe UI', sans-serif") ? 'selected' : ''; ?>>Calibri</option>
                                    <option value="Arial, sans-serif" <?php echo ($font_family === 'Arial, sans-serif') ? 'selected' : ''; ?>>Arial</option>
                                    <option value="'Times New Roman', serif" <?php echo ($font_family === "'Times New Roman', serif") ? 'selected' : ''; ?>>Times New Roman</option>
                                    <option value="Georgia, serif" <?php echo ($font_family === 'Georgia, serif') ? 'selected' : ''; ?>>Georgia</option>
                                    <option value="'Courier New', monospace" <?php echo ($font_family === "'Courier New', monospace") ? 'selected' : ''; ?>>Courier New</option>
                                </select>
                                <p class="text-xs text-gray-400 mt-1">Choose from modern Google Fonts or classic system fonts</p>
                            </div>
                            
                            <!-- Sidebar Background Color -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Sidebar Background Color</label>
                                <div class="flex gap-3 items-center">
                                    <input type="color" name="sidebar_bg_color" id="sidebarColor" value="<?php echo htmlspecialchars($sidebar_bg_color); ?>" 
                                           class="w-16 h-12 border border-gray-300 rounded-xl cursor-pointer shadow-sm">
                                    <input type="text" id="sidebarColorText" value="<?php echo htmlspecialchars($sidebar_bg_color); ?>" 
                                           class="flex-1 px-3 py-2 border border-gray-300 rounded-xl bg-gray-50 font-mono text-sm">
                                </div>
                                <p class="text-xs text-gray-400 mt-1">Color for the left sidebar navigation</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Save Button -->
                    <div class="flex gap-3">
                        <button type="submit" class="flex-1 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold py-3 px-6 rounded-xl hover:shadow-lg transition-all flex items-center justify-center gap-2">
                            <i class="fas fa-save"></i>
                            Save Settings
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- Right Sidebar - Preview and Info -->
            <div class="space-y-6">
                <!-- Live Preview Card -->
                <div class="chart-card overflow-hidden sticky top-4">
                    <div class="p-5 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
                        <div class="flex items-center gap-3">
                            <div class="bg-indigo-600 rounded-xl p-2">
                                <i class="fas fa-eye text-white text-lg"></i>
                            </div>
                            <div>
                                <h3 class="text-xl font-bold text-gray-800">Live Preview</h3>
                                <p class="text-sm text-gray-500">See your changes in real-time</p>
                            </div>
                        </div>
                    </div>
                    <div class="p-5">
                        <div class="space-y-4">
                            <!-- Sidebar Preview -->
                            <div class="rounded-xl overflow-hidden shadow-sm">
                                <div id="sidebarPreview" style="background-color: <?php echo htmlspecialchars($sidebar_bg_color); ?>; padding: 1rem; transition: all 0.3s;">
                                    <div class="flex items-center gap-3 mb-4">
                                        <div class="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                                            <i class="fas fa-hospital-user text-white"></i>
                                        </div>
                                        <div>
                                            <p class="font-bold text-white text-sm" id="previewAppName" style="font-family: <?php echo htmlspecialchars($font_family); ?>;">
                                                <?php echo htmlspecialchars($app_name); ?>
                                            </p>
                                            <p class="text-white/60 text-xs">Queue Management</p>
                                        </div>
                                    </div>
                                    <div class="space-y-2">
                                        <div class="flex items-center gap-2 text-white/80 text-sm py-1">
                                            <i class="fas fa-tachometer-alt w-5"></i>
                                            <span style="font-family: <?php echo htmlspecialchars($font_family); ?>;">Dashboard</span>
                                        </div>
                                        <div class="flex items-center gap-2 text-white/80 text-sm py-1">
                                            <i class="fas fa-clock w-5"></i>
                                            <span style="font-family: <?php echo htmlspecialchars($font_family); ?>;">Queue</span>
                                        </div>
                                        <div class="flex items-center gap-2 text-white/80 text-sm py-1">
                                            <i class="fas fa-users w-5"></i>
                                            <span style="font-family: <?php echo htmlspecialchars($font_family); ?>;">Patients</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Content Preview -->
                            <div class="bg-gray-50 rounded-xl p-4 border border-gray-100">
                                <p class="font-semibold text-gray-800 mb-2" style="font-family: <?php echo htmlspecialchars($font_family); ?>;">
                                    Sample Content Area
                                </p>
                                <p class="text-sm text-gray-600" style="font-family: <?php echo htmlspecialchars($font_family); ?>;">
                                    This is how your content will appear with the selected font.
                                </p>
                                <div class="mt-3 flex gap-2">
                                    <button class="px-3 py-1.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition" style="font-family: <?php echo htmlspecialchars($font_family); ?>;">
                                        Sample Button
                                    </button>
                                    <button class="px-3 py-1.5 bg-gray-200 text-gray-700 text-sm rounded-lg hover:bg-gray-300 transition" style="font-family: <?php echo htmlspecialchars($font_family); ?>;">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- System Information Card -->
                <div class="chart-card overflow-hidden">
                    <div class="p-5 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
                        <div class="flex items-center gap-3">
                            <div class="bg-cyan-600 rounded-xl p-2">
                                <i class="fas fa-server text-white text-lg"></i>
                            </div>
                            <div>
                                <h3 class="text-xl font-bold text-gray-800">System Information</h3>
                                <p class="text-sm text-gray-500">Environment & statistics</p>
                            </div>
                        </div>
                    </div>
                    <div class="p-5 space-y-3">
                        <?php
                        // Get system stats
                        $total_users = mysqli_fetch_assoc(mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM users"))['cnt'];
                        $total_patients = mysqli_fetch_assoc(mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM patients"))['cnt'];
                        $total_visits = mysqli_fetch_assoc(mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits"))['cnt'];
                        $total_medicines = mysqli_fetch_assoc(mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM medicines"))['cnt'];
                        ?>
                        <div class="flex justify-between items-center py-2 border-b border-gray-100">
                            <span class="text-gray-600">PHP Version</span>
                            <span class="font-mono text-sm text-gray-800"><?php echo phpversion(); ?></span>
                        </div>
                        <div class="flex justify-between items-center py-2 border-b border-gray-100">
                            <span class="text-gray-600">MySQL Version</span>
                            <span class="font-mono text-sm text-gray-800"><?php echo mysqli_get_server_info($mysqli); ?></span>
                        </div>
                        <div class="flex justify-between items-center py-2 border-b border-gray-100">
                            <span class="text-gray-600">Total Users</span>
                            <span class="font-mono text-sm text-gray-800"><?php echo $total_users; ?></span>
                        </div>
                        <div class="flex justify-between items-center py-2 border-b border-gray-100">
                            <span class="text-gray-600">Total Patients</span>
                            <span class="font-mono text-sm text-gray-800"><?php echo $total_patients; ?></span>
                        </div>
                        <div class="flex justify-between items-center py-2 border-b border-gray-100">
                            <span class="text-gray-600">Total Visits</span>
                            <span class="font-mono text-sm text-gray-800"><?php echo $total_visits; ?></span>
                        </div>
                        <div class="flex justify-between items-center py-2">
                            <span class="text-gray-600">Medicines</span>
                            <span class="font-mono text-sm text-gray-800"><?php echo $total_medicines; ?></span>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Tips Card -->
                <div class="chart-card overflow-hidden bg-gradient-to-r from-blue-50 to-indigo-50">
                    <div class="p-5">
                        <div class="flex items-center gap-3 mb-3">
                            <div class="bg-blue-600 rounded-xl p-2">
                                <i class="fas fa-lightbulb text-white text-lg"></i>
                            </div>
                            <h3 class="text-lg font-bold text-gray-800">Quick Tips</h3>
                        </div>
                        <ul class="space-y-2 text-sm text-gray-600">
                            <li class="flex items-start gap-2">
                                <i class="fas fa-check-circle text-green-500 mt-0.5 text-xs"></i>
                                <span>Changes take effect immediately after saving</span>
                            </li>
                            <li class="flex items-start gap-2">
                                <i class="fas fa-check-circle text-green-500 mt-0.5 text-xs"></i>
                                <span>Use the color picker to customize sidebar appearance</span>
                            </li>
                            <li class="flex items-start gap-2">
                                <i class="fas fa-check-circle text-green-500 mt-0.5 text-xs"></i>
                                <span>Choose from various font options for better readability</span>
                            </li>
                            <li class="flex items-start gap-2">
                                <i class="fas fa-check-circle text-green-500 mt-0.5 text-xs"></i>
                                <span>Refresh the page after saving to see all changes</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Live preview functionality
const sidebarColor = document.getElementById('sidebarColor');
const sidebarColorText = document.getElementById('sidebarColorText');
const fontSelect = document.getElementById('fontSelect');
const appNameInput = document.querySelector('input[name="app_name"]');
const sidebarPreview = document.getElementById('sidebarPreview');
const previewAppName = document.getElementById('previewAppName');

function updatePreview() {
    // Update sidebar color preview
    if (sidebarPreview && sidebarColor) {
        sidebarPreview.style.backgroundColor = sidebarColor.value;
    }
    
    // Update app name preview
    if (previewAppName && appNameInput) {
        previewAppName.textContent = appNameInput.value || 'Hospital Queue System';
    }
    
    // Update font preview for all elements
    const selectedFont = fontSelect.value;
    const previewElements = document.querySelectorAll('#sidebarPreview, #sidebarPreview *');
    previewElements.forEach(el => {
        el.style.fontFamily = selectedFont;
    });
    
    const contentElements = document.querySelectorAll('.bg-gray-50, .bg-gray-50 *');
    contentElements.forEach(el => {
        el.style.fontFamily = selectedFont;
    });
}

// Sync color picker with text input
if (sidebarColor && sidebarColorText) {
    sidebarColor.addEventListener('input', function() {
        sidebarColorText.value = this.value;
        updatePreview();
    });
    
    sidebarColorText.addEventListener('input', function() {
        sidebarColor.value = this.value;
        updatePreview();
    });
}

// Update preview on font change
if (fontSelect) {
    fontSelect.addEventListener('change', updatePreview);
}

// Update preview on app name change
if (appNameInput) {
    appNameInput.addEventListener('input', updatePreview);
}

// Initialize preview on page load
document.addEventListener('DOMContentLoaded', function() {
    updatePreview();
});
</script>

<style>
/* Additional styles for better visual appeal */
.chart-card {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.chart-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 24px -8px rgba(0, 0, 0, 0.1);
}

#sidebarPreview {
    transition: all 0.3s ease;
}

/* Custom color picker styling */
input[type="color"] {
    cursor: pointer;
}

input[type="color"]::-webkit-color-swatch-wrapper {
    padding: 0;
}

input[type="color"]::-webkit-color-swatch {
    border: none;
    border-radius: 0.75rem;
}

/* Fade-in animation */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.fade-in-up {
    animation: fadeInUp 0.5s ease-out;
}
</style>

<?php include '../includes/footer.php'; ?>