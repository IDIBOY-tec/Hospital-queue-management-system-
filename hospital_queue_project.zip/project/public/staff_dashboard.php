<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/settings.php';

require_staff();

$page_title = 'Staff Dashboard - ' . ($app_name ?? 'Hospital Queue System');
$user = get_user_by_id($mysqli, get_current_user_id());

// Get staff-specific statistics
$today = date('Y-m-d');
$staff_id = get_current_user_id();

// Today's visits handled by this staff
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE assigned_staff_id = $staff_id AND DATE(created_at) = '$today'");
$my_today_visits = mysqli_fetch_assoc($result)['cnt'];

// Today's served by this staff
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE assigned_staff_id = $staff_id AND DATE(served_at) = '$today' AND status = 'served'");
$my_today_served = mysqli_fetch_assoc($result)['cnt'];

// Current waiting patients
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE status = 'waiting' AND DATE(created_at) = '$today'");
$waiting_count = mysqli_fetch_assoc($result)['cnt'];

// Called patients
$result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE status = 'called' AND DATE(created_at) = '$today'");
$called_count = mysqli_fetch_assoc($result)['cnt'];

// Get recent patients
$recent_patients = mysqli_query($mysqli, "
    SELECT v.*, p.first_name, p.last_name, p.phone 
    FROM visits v 
    JOIN patients p ON p.id = v.patient_id 
    WHERE v.status IN ('waiting', 'called') AND DATE(v.created_at) = '$today'
    ORDER BY v.created_at ASC 
    LIMIT 10
");

// Get staff performance for last 7 days
$performance = mysqli_query($mysqli, "
    SELECT 
        DATE(served_at) as date,
        COUNT(*) as served_count
    FROM visits 
    WHERE assigned_staff_id = $staff_id 
        AND served_at IS NOT NULL 
        AND served_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DATE(served_at)
    ORDER BY date ASC
");

$performance_data = [];
while ($row = mysqli_fetch_assoc($performance)) {
    $performance_data[$row['date']] = $row['served_count'];
}

// Get today's hourly activity
$hourly_activity = mysqli_query($mysqli, "
    SELECT 
        HOUR(created_at) as hour,
        COUNT(*) as count
    FROM visits 
    WHERE DATE(created_at) = '$today'
    GROUP BY HOUR(created_at)
    ORDER BY hour ASC
");
?>
<?php include '../includes/header.php'; ?>

<div class="main-content">
    <div class="p-4 md:p-8">
        <!-- Header with Welcome Message -->
        <div class="mb-8 fade-in-up">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h1 class="text-3xl md:text-4xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                        Welcome back, <?php echo htmlspecialchars($user['full_name'] ?? 'Staff'); ?>!
                    </h1>
                    <p class="text-gray-500 mt-2">Here's what's happening with your queue today</p>
                </div>
                <div class="flex gap-3">
                    <div class="bg-white rounded-xl px-4 py-2 shadow-sm">
                        <i class="fas fa-calendar-alt text-blue-500 mr-2"></i>
                        <span class="text-gray-600"><?php echo date('l, F j, Y'); ?></span>
                    </div>
                    <div class="bg-white rounded-xl px-4 py-2 shadow-sm">
                        <i class="fas fa-clock text-green-500 mr-2"></i>
                        <span class="text-gray-600" id="currentTime"><?php echo date('h:i A'); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
            <div class="stat-card p-5 cursor-pointer hover:shadow-xl transition-all" onclick="window.location.href='/queue.php'">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Waiting Patients</p>
                        <p class="text-3xl font-bold text-amber-600 mt-1" id="waitingCount"><?php echo $waiting_count; ?></p>
                    </div>
                    <div class="bg-amber-100 rounded-xl p-3">
                        <i class="fas fa-hourglass-half text-amber-600 text-xl"></i>
                    </div>
                </div>
                <div class="mt-2 text-xs text-gray-400">Need attention</div>
            </div>
            
            <div class="stat-card p-5 cursor-pointer hover:shadow-xl transition-all" onclick="window.location.href='/queue.php?status=called'">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Called Patients</p>
                        <p class="text-3xl font-bold text-blue-600 mt-1" id="calledCount"><?php echo $called_count; ?></p>
                    </div>
                    <div class="bg-blue-100 rounded-xl p-3">
                        <i class="fas fa-bell text-blue-600 text-xl"></i>
                    </div>
                </div>
                <div class="mt-2 text-xs text-gray-400">Awaiting arrival</div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">My Today's Visits</p>
                        <p class="text-3xl font-bold text-purple-600 mt-1"><?php echo $my_today_visits; ?></p>
                    </div>
                    <div class="bg-purple-100 rounded-xl p-3">
                        <i class="fas fa-user-md text-purple-600 text-xl"></i>
                    </div>
                </div>
                <div class="mt-2 text-xs text-gray-400">Assigned to you</div>
            </div>
            
            <div class="stat-card p-5">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Served Today</p>
                        <p class="text-3xl font-bold text-green-600 mt-1" id="servedCount"><?php echo $my_today_served; ?></p>
                    </div>
                    <div class="bg-green-100 rounded-xl p-3">
                        <i class="fas fa-check-circle text-green-600 text-xl"></i>
                    </div>
                </div>
                <div class="mt-2 text-xs text-gray-400">Completed visits</div>
            </div>
        </div>

        <!-- Quick Actions Row -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
            <div class="chart-card p-5 hover:shadow-lg transition-all cursor-pointer group" onclick="window.location.href='/patient_register.php'">
                <div class="flex items-center gap-4">
                    <div class="bg-blue-100 rounded-xl p-3 group-hover:bg-blue-200 transition">
                        <i class="fas fa-user-plus text-blue-600 text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-gray-800">Register Patient</h3>
                        <p class="text-sm text-gray-500">Add new patient to the system</p>
                    </div>
                </div>
            </div>
            
            <div class="chart-card p-5 hover:shadow-lg transition-all cursor-pointer group" onclick="window.location.href='/queue.php'">
                <div class="flex items-center gap-4">
                    <div class="bg-green-100 rounded-xl p-3 group-hover:bg-green-200 transition">
                        <i class="fas fa-clock text-green-600 text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-gray-800">Manage Queue</h3>
                        <p class="text-sm text-gray-500">Call next patient or manage waiting list</p>
                    </div>
                </div>
            </div>
            
            <div class="chart-card p-5 hover:shadow-lg transition-all cursor-pointer group" onclick="window.location.href='/medicines.php'">
                <div class="flex items-center gap-4">
                    <div class="bg-purple-100 rounded-xl p-3 group-hover:bg-purple-200 transition">
                        <i class="fas fa-capsules text-purple-600 text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-gray-800">Dispense Medicine</h3>
                        <p class="text-sm text-gray-500">View and dispense medicines</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts and Activity Section -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <!-- Visits Trend Chart -->
            <div class="chart-card p-5">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="font-bold text-gray-800 flex items-center gap-2">
                        <i class="fas fa-chart-line text-blue-500"></i>
                        My Performance (Last 7 Days)
                    </h3>
                    <span class="text-xs text-gray-400">Patients served</span>
                </div>
                <canvas id="performanceChart" height="250"></canvas>
            </div>
            
            <!-- Hourly Activity Chart -->
            <div class="chart-card p-5">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="font-bold text-gray-800 flex items-center gap-2">
                        <i class="fas fa-chart-bar text-green-500"></i>
                        Today's Hourly Activity
                    </h3>
                    <span class="text-xs text-gray-400">Patient registrations</span>
                </div>
                <canvas id="hourlyChart" height="250"></canvas>
            </div>
        </div>

        <!-- Current Queue List -->
        <div class="chart-card overflow-hidden mb-8">
            <div class="p-5 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <div class="bg-amber-600 rounded-xl p-2">
                            <i class="fas fa-list-ul text-white text-lg"></i>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold text-gray-800">Current Queue</h3>
                            <p class="text-sm text-gray-500">Patients waiting to be seen</p>
                        </div>
                    </div>
                    <button onclick="refreshQueue()" class="text-blue-600 hover:text-blue-700 text-sm">
                        <i class="fas fa-sync-alt"></i> Refresh
                    </button>
                </div>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50 border-b border-gray-200">
                        <tr>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Queue #</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Patient Name</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Contact</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Reason</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                            <th class="px-5 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Arrived</th>
                            <th class="px-5 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Action</th>
                        </tr>
                    </thead>
                    <tbody id="queueTableBody">
                        <?php if (mysqli_num_rows($recent_patients) > 0): ?>
                            <?php while ($patient = mysqli_fetch_assoc($recent_patients)): ?>
                                <tr class="border-b hover:bg-gray-50 transition">
                                    <td class="px-5 py-3">
                                        <span class="font-mono text-sm font-bold text-gray-700">#<?php echo htmlspecialchars($patient['record_number']); ?></span>
                                    </td>
                                    <td class="px-5 py-3">
                                        <div class="font-medium text-gray-800">
                                            <?php echo htmlspecialchars($patient['first_name'] . ' ' . ($patient['last_name'] ?? '')); ?>
                                        </div>
                                    </td>
                                    <td class="px-5 py-3 text-sm text-gray-600">
                                        <?php echo htmlspecialchars($patient['phone'] ?? '-'); ?>
                                    </td>
                                    <td class="px-5 py-3 text-sm text-gray-600 max-w-xs truncate">
                                        <?php echo htmlspecialchars(substr($patient['reason'], 0, 50) . (strlen($patient['reason']) > 50 ? '...' : '')); ?>
                                    </td>
                                    <td class="px-5 py-3">
                                        <span class="px-2 py-1 rounded-full text-xs font-medium <?php echo $patient['status'] === 'waiting' ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-800'; ?>">
                                            <?php echo ucfirst($patient['status']); ?>
                                        </span>
                                    </td>
                                    <td class="px-5 py-3 text-sm text-gray-500">
                                        <?php echo date('h:i A', strtotime($patient['created_at'])); ?>
                                    </td>
                                    <td class="px-5 py-3 text-center">
                                        <?php if ($patient['status'] === 'waiting'): ?>
                                            <button onclick="callPatient(<?php echo $patient['id']; ?>, '<?php echo htmlspecialchars($patient['first_name']); ?>')" 
                                                    class="px-3 py-1.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition">
                                                <i class="fas fa-phone-alt mr-1"></i> Call
                                            </button>
                                        <?php elseif ($patient['status'] === 'called'): ?>
                                            <button onclick="servePatient(<?php echo $patient['id']; ?>)" 
                                                    class="px-3 py-1.5 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700 transition">
                                                <i class="fas fa-stethoscope mr-1"></i> Serve
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-8 text-gray-400">
                                    <i class="fas fa-inbox text-3xl mb-2 opacity-50"></i>
                                    <p>No patients in queue at the moment</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Wait Time Statistics -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="chart-card p-5">
                <div class="flex items-center gap-3 mb-3">
                    <div class="bg-blue-100 rounded-lg p-2">
                        <i class="fas fa-chart-simple text-blue-600"></i>
                    </div>
                    <h3 class="font-bold text-gray-800">Average Wait Time</h3>
                </div>
                <p class="text-3xl font-bold text-blue-600" id="avgWaitTime">--</p>
                <p class="text-sm text-gray-500 mt-1">Based on today's served patients</p>
            </div>
            
            <div class="chart-card p-5">
                <div class="flex items-center gap-3 mb-3">
                    <div class="bg-green-100 rounded-lg p-2">
                        <i class="fas fa-tachometer-alt text-green-600"></i>
                    </div>
                    <h3 class="font-bold text-gray-800">Completion Rate</h3>
                </div>
                <p class="text-3xl font-bold text-green-600" id="completionRate">--</p>
                <p class="text-sm text-gray-500 mt-1">Today's served vs total</p>
            </div>
            
            <div class="chart-card p-5">
                <div class="flex items-center gap-3 mb-3">
                    <div class="bg-purple-100 rounded-lg p-2">
                        <i class="fas fa-hourglass-half text-purple-600"></i>
                    </div>
                    <h3 class="font-bold text-gray-800">Peak Hour</h3>
                </div>
                <p class="text-3xl font-bold text-purple-600" id="peakHour">--</p>
                <p class="text-sm text-gray-500 mt-1">Busiest time of day</p>
            </div>
        </div>
    </div>
</div>

<script>
let performanceChart, hourlyChart;
let refreshInterval;

// Call patient function
function callPatient(visitId, patientName) {
    if (confirm(`Call patient ${patientName}?`)) {
        fetch('/api/api_queue.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `action=call&visit_id=${visitId}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', `Patient ${patientName} has been called`);
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification('error', data.message || 'Error calling patient');
            }
        })
        .catch(err => {
            console.error('Error:', err);
            showNotification('error', 'Network error');
        });
    }
}

// Serve patient function
function servePatient(visitId) {
    if (confirm('Mark this patient as served?')) {
        fetch('/api/api_queue.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `action=serve&visit_id=${visitId}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', 'Patient marked as served');
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification('error', data.message || 'Error serving patient');
            }
        })
        .catch(err => {
            console.error('Error:', err);
            showNotification('error', 'Network error');
        });
    }
}

// Show notification
function showNotification(type, message) {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 p-4 rounded-xl shadow-lg transition-all transform translate-x-0 ${
        type === 'success' ? 'bg-green-500' : 'bg-red-500'
    } text-white`;
    notification.innerHTML = `
        <div class="flex items-center gap-2">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    document.body.appendChild(notification);
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Load performance chart
async function loadPerformanceChart() {
    try {
        const response = await fetch('/api/api_reports.php?type=staff_performance&staff_id=<?php echo $staff_id; ?>');
        const data = await response.json();
        
        if (data.success && data.data) {
            const ctx = document.getElementById('performanceChart').getContext('2d');
            if (performanceChart) performanceChart.destroy();
            
            performanceChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.data.map(d => d.date),
                    datasets: [{
                        label: 'Patients Served',
                        data: data.data.map(d => d.served),
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: { position: 'top' }
                    },
                    scales: {
                        y: { beginAtZero: true, title: { display: true, text: 'Patients Served' } }
                    }
                }
            });
        }
    } catch (err) {
        console.error('Error loading performance chart:', err);
    }
}

// Load hourly chart
async function loadHourlyChart() {
    try {
        const response = await fetch('/api/api_reports.php?type=hourly_activity');
        const data = await response.json();
        
        if (data.success && data.data) {
            const ctx = document.getElementById('hourlyChart').getContext('2d');
            if (hourlyChart) hourlyChart.destroy();
            
            const hours = data.data.map(d => {
                const hour = d.hour;
                const ampm = hour >= 12 ? 'PM' : 'AM';
                const display = hour > 12 ? hour-12 : (hour === 0 ? 12 : hour);
                return `${display}${ampm}`;
            });
            
            hourlyChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: hours,
                    datasets: [{
                        label: 'Patients Registered',
                        data: data.data.map(d => d.count),
                        backgroundColor: '#10b981',
                        borderRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        y: { beginAtZero: true, title: { display: true, text: 'Number of Patients' } }
                    }
                }
            });
        }
    } catch (err) {
        console.error('Error loading hourly chart:', err);
    }
}

// Load stats
async function loadStats() {
    try {
        const response = await fetch('/api/api_reports.php?type=daily_summary&range=today');
        const data = await response.json();
        
        if (data.success && data.data) {
            document.getElementById('waitingCount').textContent = data.data.waiting || 0;
            document.getElementById('calledCount').textContent = data.data.called || 0;
            document.getElementById('servedCount').textContent = data.data.served || 0;
            
            // Calculate completion rate
            const total = (data.data.waiting || 0) + (data.data.called || 0) + (data.data.served || 0);
            const rate = total > 0 ? Math.round((data.data.served / total) * 100) : 0;
            document.getElementById('completionRate').textContent = `${rate}%`;
            
            // Get average wait time
            const waitResponse = await fetch('/api/api_reports.php?type=avg_wait_time&range=today');
            const waitData = await waitResponse.json();
            if (waitData.success && waitData.data) {
                const avgMinutes = Math.round((waitData.data.avg_wait_seconds || 0) / 60);
                document.getElementById('avgWaitTime').textContent = `${avgMinutes} min`;
            }
            
            // Get peak hour
            const peakResponse = await fetch('/api/api_reports.php?type=peak_hour');
            const peakData = await peakResponse.json();
            if (peakData.success && peakData.data) {
                const hour = peakData.data.hour;
                const ampm = hour >= 12 ? 'PM' : 'AM';
                const display = hour > 12 ? hour-12 : (hour === 0 ? 12 : hour);
                document.getElementById('peakHour').textContent = `${display}:00 ${ampm}`;
            }
        }
    } catch (err) {
        console.error('Error loading stats:', err);
    }
}

// Refresh queue
function refreshQueue() {
    location.reload();
}

// Update current time
function updateTime() {
    const now = new Date();
    const timeString = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    const timeElement = document.getElementById('currentTime');
    if (timeElement) timeElement.textContent = timeString;
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    loadPerformanceChart();
    loadHourlyChart();
    loadStats();
    updateTime();
    
    // Auto-refresh stats every 30 seconds
    refreshInterval = setInterval(() => {
        loadStats();
        loadPerformanceChart();
        loadHourlyChart();
    }, 30000);
    
    // Update time every minute
    setInterval(updateTime, 60000);
});

// Cleanup on page unload
window.addEventListener('beforeunload', function() {
    if (refreshInterval) clearInterval(refreshInterval);
    if (performanceChart) performanceChart.destroy();
    if (hourlyChart) hourlyChart.destroy();
});
</script>

<style>
/* Additional styles for better visual appeal */
.stat-card, .chart-card {
    transition: all 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-5px);
}

/* Queue table row hover effect */
#queueTableBody tr {
    transition: background-color 0.2s ease;
}

/* Custom scrollbar for tables */
.overflow-x-auto::-webkit-scrollbar {
    height: 6px;
}

.overflow-x-auto::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}

.overflow-x-auto::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 10px;
}

.overflow-x-auto::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
}

/* Notification animation */
@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

.notification {
    animation: slideIn 0.3s ease-out;
}
</style>

<?php include '../includes/footer.php'; ?>