<?php
// Footer template - include at end of each page
?>
</body>
</html>
