<?php
// Sidebar component - include after header.php
// This file expects $app_name to be defined
?>
<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <!-- Sidebar Header with Logo and System Name -->
    <div class="sidebar-header">
        <img src="images/logo.jpg" alt="System Logo" class="sidebar-logo" onerror="this.src='https://via.placeholder.com/70?text=🏥'">
        <div class="sidebar-title"><?php echo htmlspecialchars($app_name ?? 'Hospital Queue System'); ?></div>
        <div class="sidebar-subtitle">Queue Management</div>
    </div>
    
    <!-- Navigation Links -->
    <div class="sidebar-nav">
        <div class="nav-section">
            <div class="nav-section-title">Main</div>
            <a href="/admin_dashboard.php">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="/queue.php">
                <i class="fas fa-clock"></i>
                <span>Queue Management</span>
            </a>
            <a href="/patient_register.php">
                <i class="fas fa-user-plus"></i>
                <span>Register Patient</span>
            </a>
        </div>
        
        <div class="nav-section">
            <div class="nav-section-title">Management</div>
            <a href="/staff_management.php">
                <i class="fas fa-users"></i>
                <span>Staff Management</span>
            </a>
            <a href="/medicines.php">
                <i class="fas fa-capsules"></i>
                <span>Medicines Inventory</span>
            </a>
            <a href="/reports.php">
                <i class="fas fa-chart-line"></i>
                <span>Reports & Analytics</span>
            </a>
        </div>
        
        <div class="nav-section">
            <div class="nav-section-title">System</div>
            <a href="/settings.php">
                <i class="fas fa-cog"></i>
                <span>Settings</span>
            </a>
        </div>
    </div>
    
    <!-- Sidebar Footer with Logout -->
    <div class="sidebar-footer">
        <a href="/logout.php">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </div>
</div>