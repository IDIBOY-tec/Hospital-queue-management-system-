<?php
// Database connection - procedural mysqli

$DB_HOST = 'localhost';
$DB_USER = 'altevtcj_Morgan';
$DB_PASS = 'Secret@123$$';
$DB_NAME = 'altevtcj_informationschema';

$mysqli = @mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if (!$mysqli) {
    die('Database connection failed: ' . mysqli_connect_error());
}

mysqli_set_charset($mysqli, 'utf8mb4');

// Enable error reporting for development
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
