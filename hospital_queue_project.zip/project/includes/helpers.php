<?php
// Common utility functions

function format_date($date, $format = 'M d, Y H:i') {
    if (empty($date) || $date === '0000-00-00 00:00:00') {
        return '-';
    }
    return date($format, strtotime($date));
}

function get_status_badge($status) {
    $colors = [
        'waiting' => 'bg-blue-600',
        'called' => 'bg-yellow-600',
        'arrived' => 'bg-green-600',
        'served' => 'bg-gray-600',
        'cancelled' => 'bg-red-600'
    ];
    $color = $colors[$status] ?? 'bg-gray-400';
    return '<span class="px-3 py-1 rounded text-white text-sm font-bold ' . $color . '">' . strtoupper($status) . '</span>';
}

function calculate_wait_time($created_at, $acknowledged_at) {
    if (empty($acknowledged_at) || $acknowledged_at === '0000-00-00 00:00:00') {
        return null;
    }
    $created = new DateTime($created_at);
    $acknowledged = new DateTime($acknowledged_at);
    $diff = $acknowledged->diff($created);
    return $diff->i . ' min ' . $diff->s . ' sec';
}

function generate_record_number($mysqli, $date = null) {
    if ($date === null) {
        $date = date('Ymd');
    } else {
        $date = date('Ymd', strtotime($date));
    }

    $prefix = 'REC-' . $date . '-';
    $result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM visits WHERE record_number LIKE '" . mysqli_real_escape_string($mysqli, $prefix) . "%'");
    $row = mysqli_fetch_assoc($result);
    $seq = intval($row['cnt']) + 1;
    return $prefix . sprintf('%04d', $seq);
}

function get_time_range_label($range) {
    $labels = [
        'today' => 'Today',
        'yesterday' => 'Yesterday',
        'last_7_days' => 'Last 7 Days',
        'last_30_days' => 'Last 30 Days',
        'this_month' => 'This Month',
        'last_month' => 'Last Month',
        'ytd' => 'Year to Date',
        'custom' => 'Custom Range'
    ];
    return $labels[$range] ?? 'Unknown';
}

function sanitize_input($input) {
    return trim(htmlspecialchars(stripslashes($input)));
}

function redirect($url) {
    header('Location: ' . $url);
    exit;
}

function json_response($success, $message = '', $data = []) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

function get_queue_stats($mysqli, $date = null) {
    if ($date === null) {
        $date = date('Y-m-d');
    }

    $query = "
        SELECT
            COUNT(*) as total,
            COUNT(CASE WHEN status='waiting' THEN 1 END) as waiting,
            COUNT(CASE WHEN status='called' THEN 1 END) as called,
            COUNT(CASE WHEN status='arrived' THEN 1 END) as arrived,
            COUNT(CASE WHEN status='served' THEN 1 END) as served,
            COUNT(CASE WHEN status='cancelled' THEN 1 END) as cancelled
        FROM visits
        WHERE DATE(created_at) = ?
    ";

    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 's', $date);
    mysqli_stmt_execute($stmt);
    return mysqli_stmt_get_result($stmt)->fetch_assoc();
}

function log_activity($mysqli, $user_id, $action, $details = '') {
    $query = "INSERT INTO activity_logs (user_id, action, details) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'iss', $user_id, $action, $details);
    return mysqli_stmt_execute($stmt);
}
