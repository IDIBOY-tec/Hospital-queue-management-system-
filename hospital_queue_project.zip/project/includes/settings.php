<?php
// Load site settings from database

$site_settings = [];

if (isset($mysqli)) {
    $result = mysqli_query($mysqli, "SELECT `key`, `value` FROM settings");
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $site_settings[$row['key']] = $row['value'];
        }
    }
}

// Defaults
$font_family = $site_settings['font_family'] ?? 'Inter, Arial, sans-serif';
$sidebar_bg_color = $site_settings['sidebar_bg_color'] ?? '#111827';
$sidebar_bg_type = $site_settings['sidebar_bg_type'] ?? 'color';
$app_name = $site_settings['app_name'] ?? 'Hospital Queue System';

function get_setting($key, $default = '') {
    global $site_settings;
    return $site_settings[$key] ?? $default;
}

function save_setting($mysqli, $key, $value) {
    $stmt = mysqli_prepare($mysqli, "INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?");
    mysqli_stmt_bind_param($stmt, 'sss', $key, $value, $value);
    return mysqli_stmt_execute($stmt);
}
