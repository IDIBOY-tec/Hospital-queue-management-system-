<?php
// Authentication helper functions

session_start();

function login_user($user_id, $username, $role) {
    $_SESSION['user_id'] = $user_id;
    $_SESSION['username'] = $username;
    $_SESSION['user_role'] = $role;
    $_SESSION['logged_in'] = true;
}

function is_logged_in() {
    return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
}

function is_admin() {
    return is_logged_in() && $_SESSION['user_role'] === 'admin';
}

function is_staff() {
    return is_logged_in() && ($_SESSION['user_role'] === 'staff' || $_SESSION['user_role'] === 'admin');
}

function get_current_user_id() {
    return $_SESSION['user_id'] ?? null;
}

function get_current_user_role() {
    return $_SESSION['user_role'] ?? null;
}

function logout_user() {
    session_destroy();
    setcookie('PHPSESSID', '', time() - 3600, '/');
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: /login.php');
        exit;
    }
}

function require_admin() {
    if (!is_admin()) {
        header('HTTP/1.0 403 Forbidden');
        echo 'Access denied';
        exit;
    }
}

function require_staff() {
    if (!is_staff()) {
        header('Location: /login.php');
        exit;
    }
}

function admin_exists($mysqli) {
    $result = mysqli_query($mysqli, "SELECT COUNT(*) as cnt FROM users WHERE role='admin'");
    $row = mysqli_fetch_assoc($result);
    return $row['cnt'] > 0;
}

function get_user_by_id($mysqli, $user_id) {
    $stmt = mysqli_prepare($mysqli, "SELECT id, username, full_name, role, email, is_active FROM users WHERE id=?");
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    mysqli_stmt_execute($stmt);
    return mysqli_stmt_get_result($stmt)->fetch_assoc();
}

function get_user_by_username($mysqli, $username) {
    $stmt = mysqli_prepare($mysqli, "SELECT id, username, password_hash, full_name, role, is_active FROM users WHERE username=?");
    mysqli_stmt_bind_param($stmt, 's', $username);
    mysqli_stmt_execute($stmt);
    return mysqli_stmt_get_result($stmt)->fetch_assoc();
}

function hash_password($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

function verify_password($password, $hash) {
    return password_verify($password, $hash);
}
